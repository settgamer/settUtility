#region Helper Functions

#region Show-Menu
# Descrição: Exibe um menu interativo no console com opções numeradas.
#            Retorna um hashtable mapeando os números das opções para suas chaves originais.
function Show-Menu {
    param (
        [string]$Title,
        [System.Collections.IDictionary]$Options,
        [string]$ReturnOption = "Voltar"
    )
    Clear-Host
    Write-Host "=== $Title ===`n" -ForegroundColor Cyan
    $menuItems = @{}
    $i = 1
    foreach ($key in $Options.Keys | Sort-Object) {
        $menuItems[$i] = $key
        Write-Host "$i) $($Options[$key].Name)" -ForegroundColor White
        $i++
    }
    Write-Host "`n0) $ReturnOption" -ForegroundColor White
    return $menuItems
}
#endregion

#region Invoke-WingetAction
# Descrição: Executa uma ação (instalar ou desinstalar) para um programa usando o Winget ou a Microsoft Store.
#            Fornece feedback visual sobre o status da operação.
function Invoke-WingetAction {
    param (
        [Parameter(Mandatory=$true)]
        [ValidateSet("install", "uninstall")]
        [string]$Action,
        [Parameter(Mandatory=$true)]
        [string]$Id,
        [Parameter(Mandatory=$true)]
        [string]$DisplayName,
        [ValidateSet("winget", "msstore")]
        [string]$Source = "winget"
    )
    $actionVerb = @{ install = "Instalando"; uninstall = "Removendo" }[$Action]
    $actionPast = @{ install = "instalado"; uninstall = "removido" }[$Action]
    Write-Host "[INFO] $actionVerb $DisplayName..." -ForegroundColor Yellow
    # Parâmetros base para o comando winget
    $params = @($Action, "--id=$Id", "--silent")
    # Adiciona parâmetros específicos da fonte (Winget ou Microsoft Store)
    if ($Source -eq "msstore") {
        if ($Action -eq "install") {
            $params += "--source", "msstore", "--accept-package-agreements"
        }
    } else { # winget
        if ($Action -eq "install") {
            $params += "--accept-source-agreements", "--accept-package-agreements"
        }
    }
    # Códigos de saída comuns do winget que indicam que o programa já está instalado
    $AlreadyInstalledCodes = @(-1978335189, -1978335215)
    try {
        # Inicia o processo winget e espera sua conclusão
        $process = Start-Process winget -ArgumentList $params -Wait -NoNewWindow -PassThru
        if ($process.ExitCode -eq 0) {
            Write-Host "[SUCESSO] $DisplayName $actionPast com sucesso!" -ForegroundColor Green
        } elseif ($AlreadyInstalledCodes -contains $process.ExitCode) {
            Write-Host "[INFO] $DisplayName ja estava instalado!" -ForegroundColor Green
        } else {
            Write-Host "[ERRO] Erro ao $actionVerb $DisplayName (Codigo: $($process.ExitCode))" -ForegroundColor Red
        }
    } catch {
        Write-Host "[ERRO] Falha critica ao executar winget para $DisplayName." -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
    Start-Sleep -Seconds 2
}
#endregion

#region Handle-AppSelection
# Descrição: Gerencia a seleção de aplicativos dentro de uma categoria para instalação ou remoção.
#            Inclui tratamento especial para o Firemin, abrindo seu site de download.
function Handle-AppSelection {
    param (
        [Parameter(Mandatory=$true)]
        [string]$CategoryName,
        [Parameter(Mandatory=$true)]
        [hashtable]$Apps,
        [Parameter(Mandatory=$true)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $actionTitle = @{
        install = "Instalar"
        uninstall = "Remover"
    }[$Action]
    while ($true) {
        $title = "$CategoryName - $actionTitle"
        $appMenuItems = Show-Menu -Title $title -Options $Apps
        $choice = Read-Host "Escolha uma opcao"
        if ($choice -eq '0') { break }
        if ($appMenuItems.ContainsKey([int]$choice)) {
            $appKey = $appMenuItems[[int]$choice]
            $app = $Apps[$appKey]
            if ($appKey -eq 'Firemin' -and $Action -eq 'install') {
                Write-Host "[INFO] Abrindo pagina de download do Firemin..." -ForegroundColor Cyan
                Write-Host "[INFO] Voce sera redirecionado para https://rizonesoft.com/downloads/firemin/" -ForegroundColor White
                Start-Sleep -Seconds 2
                Start-Process 'https://rizonesoft.com/downloads/firemin/'
                Write-Host "[SUCESSO] Pagina do Firemin aberta no navegador!" -ForegroundColor Green
                Start-Sleep -Seconds 3
                continue
            }
            if ($appKey -eq 'br.gamersclub.launcher' -and $Action -eq 'install') {
                Write-Host "[INFO] Abrindo pagina de download do GamersClub..." -ForegroundColor Cyan
                Write-Host "[INFO] Voce sera redirecionado para https://acupdate.gamersclub.com.br/download" -ForegroundColor White
                Start-Sleep -Seconds 2
                Start-Process 'https://acupdate.gamersclub.com.br/download'
                Write-Host "[SUCESSO] Pagina do GamersClub aberta no navegador!" -ForegroundColor Green
                Start-Sleep -Seconds 3
                continue
            }
            if ($appKey -eq 'AirLiveDrive' -and $Action -eq 'install') {
                Write-Host "[INFO] Abrindo pagina de download do Air Live Drive..." -ForegroundColor Cyan
                Write-Host "[INFO] Voce sera redirecionado para https://www.airlivedrive.com/en/" -ForegroundColor White
                Start-Sleep -Seconds 2
                Start-Process 'https://www.airlivedrive.com/en/'
                Write-Host "[SUCESSO] Pagina do Air Live Drive aberta no navegador!" -ForegroundColor Green
                Start-Sleep -Seconds 3
                continue
            }
            if ($Action -eq "uninstall") {
                $confirm = Read-Host "Tem certeza que deseja remover $($app.Name)? (Y/N)"
                if ($confirm -notmatch '^[Yy]$') { continue }
            }
            $source = if ($app.Source) { $app.Source } else { "winget" }
            Invoke-WingetAction -Action $Action -Id $appKey -DisplayName $app.Name -Source $source
            if ($Action -eq "install" -and $app.SetupLinks) {
                Write-Host "[INFO] Abrindo links de configuracao/setup para $($app.Name)..." -ForegroundColor Magenta
                Start-Sleep -Seconds 1
                foreach ($link in $app.SetupLinks) {
                    Write-Host " -> Abrindo $link" -ForegroundColor White
                    Start-Process $link
                }
                Start-Sleep -Seconds 2
            }
        } else {
            Write-Host "[ERRO] Opcao invalida!" -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
}
#endregion

#region Open-OOAppBuster
# Descrição: Abre o programa O&O AppBuster localizado na pasta Programs
function Open-OOAppBuster {
    Clear-Host
    Write-Host "=== O&O AppBuster ===" -ForegroundColor Cyan
    Write-Host "`n[INFO] Abrindo O&O AppBuster..." -ForegroundColor Yellow

    # Usa $PSScriptRoot - funciona em qualquer lugar que o script estiver
    $appBusterPath = Join-Path $PSScriptRoot "Programs\OOAPB.exe"

    if (Test-Path $appBusterPath) {
        Start-Process $appBusterPath
        Write-Host "[SUCESSO] O&O AppBuster aberto com sucesso!" -ForegroundColor Green
    } else {
        Write-Host "[ERRO] OOAPB.exe nao encontrado em: $appBusterPath" -ForegroundColor Red
        Write-Host "[INFO] Coloque o arquivo na pasta: Programs" -ForegroundColor Yellow
    }
    Start-Sleep -Seconds 2
}
#endregion

#region Open-WindowsDebloat
# Descrição: Abre o programa Windows Debloat localizado na pasta Programs
function Open-WindowsDebloat {
    Clear-Host
    Write-Host "=== Windows Debloat ===" -ForegroundColor Cyan
    Write-Host "`n[INFO] Abrindo Windows Debloat..." -ForegroundColor Yellow

    # Usa $PSScriptRoot - funciona em qualquer lugar que o script estiver
    $appBusterPath = Join-Path $PSScriptRoot "Programs\WindowsDebloat.exe"

    if (Test-Path $appBusterPath) {
        Start-Process $appBusterPath
        Write-Host "[SUCESSO] WindowsDebloat aberto com sucesso!" -ForegroundColor Green
    } else {
        Write-Host "[ERRO] WindowsDebloat.exe nao encontrado em: $appBusterPath" -ForegroundColor Red
        Write-Host "[INFO] Coloque o arquivo na pasta: Programs" -ForegroundColor Yellow
    }
    Start-Sleep -Seconds 2
}
#endregion


#region Remove-WindowsAI
# Descrição: Executa o script remoto para remover componentes de IA do Windows
function Remove-WindowsAI {
    Clear-Host
    Write-Host "=== Remover Windows AI ===" -ForegroundColor Cyan
    Write-Host "`n[AVISO] Este script vai remover componentes de IA do Windows." -ForegroundColor Yellow
    Write-Host "[INFO] O processo pode demorar alguns minutos..." -ForegroundColor Yellow

    $confirm = Read-Host "`nDeseja continuar? (Y/N)"
    if ($confirm -notmatch '^[Yy]$') {
        Write-Host "[INFO] Operacao cancelada." -ForegroundColor Yellow
        Start-Sleep -Seconds 2
        return
    }

    try {
        Write-Host "`n[INFO] Baixando e executando script de remocao..." -ForegroundColor Cyan
        & ([scriptblock]::Create((irm "https://raw.githubusercontent.com/zoicware/RemoveWindowsAI/main/RemoveWindowsAi.ps1")))
        Write-Host "`n[SUCESSO] Script executado!" -ForegroundColor Green
    } catch {
        Write-Host "`n[ERRO] Falha ao executar o script de remocao." -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }

    Write-Host "`n`nPressione qualquer tecla para voltar ao menu..." -ForegroundColor Cyan
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
#endregion

#region Update-AllPrograms
# Descrição: Verifica e permite ao usuário atualizar todos os programas instalados via Winget.
function Update-AllPrograms {
    Clear-Host
    Write-Host "=== Atualizar Programas ===" -ForegroundColor Cyan
    Write-Host "`n Verificando programas com atualizacoes disponiveis..." -ForegroundColor Yellow
    try {
        winget upgrade # Lista as atualizações disponíveis
    } catch {
        Write-Host "[ERRO] Nao foi possivel verificar as atualizacoes." -ForegroundColor Red
        Start-Sleep -Seconds 2
        return
    }
    $confirm = Read-Host "`nDeseja atualizar todos os programas? (Y/N)"
    if ($confirm -match '^[Yy]$') {
        Write-Host "`n Atualizando todos os programas..." -ForegroundColor Yellow
        # Executa a atualização de todos os programas silenciosamente
        Start-Process winget -ArgumentList "upgrade", "--all", "--silent", "--accept-source-agreements", "--accept-package-agreements" -Wait -NoNewWindow
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[SUCESSO] Atualizacao de todos os programas concluida com sucesso!" -ForegroundColor Green
        } else {
            Write-Host "[ERRO] Erro ao atualizar todos os programas (Codigo de saida: $LASTEXITCODE)" -ForegroundColor Red
        }
    } else {
        Write-Host "[INFO] Operacao de atualizacao cancelada."
    }
    Start-Sleep -Seconds 2
}
#endregion

#endregion Helper Functions

#region Menu and App Definitions
# Descrição: Define as categorias de aplicativos e os aplicativos dentro de cada categoria.
#            Cada aplicativo pode ter um nome, link da loja, fonte (winget/msstore),
#            e links de configuração/setup adicionais.
$categories = @{
    'GPU | CPU' = @{ Name='CPU | CPU'; Apps=@{
        'Guru3D.Afterburner' = @{ Name='MSI Afterburner' }
        'AMD.RyzenMaster' = @{ Name='Ryzen Master' }
        'Rem0o.FanControl' = @{ Name='FanControl' }
    }}
    'Utils' = @{ Name='Utilitarios'; Apps=@{
        '9N7JSXC1SJK6' = @{ Name = 'Blip Transfer'; StoreLink='https://apps.microsoft.com/detail/9N7JSXC1SJK6' }
        'DuongDieuPhap.ImageGlass' = @{ Name='Image Glass'}
        'GitHub.cli' = @{ Name='Github' }
        'Microsoft.VisualStudioCode' = @{ Name = 'Visual Studio Code'}
        'OpenJS.NodeJS.LTS' = @{ Name='NodeJS' }
        'Python.Python' = @{ Name = 'Python'}
        'Skillbrains.Lightshot' = @{ Name='Lightshot' }
        'Spotify.Spotify' = @{ Name='Spotify'}
        'Spicetify.Spicetify' = @{ Name='Spicetify'}
        'Firemin' = @{ Name = 'Firemin'; SetupLinks = @('https://rizonesoft.com/downloads/firemin/') }
        'AirLiveDrive' = @{ Name = 'Air Live Drive'; SetupLinks = @('https://www.airlivedrive.com/en/') }
    }}
    'Desktop' = @{ Name='Desktop'; Apps=@{
        'RamenSoftware.Windhawk' = @{ Name='WindHawk' }
        '9NBLGGH516XP' = @{ Name='EarTrumpet'; Source='msstore'; StoreLink='https://apps.microsoft.com/detail/9NBLGGH516XP' }
        '9NTM2QC6QWS7' = @{ Name='Lively Wallpaper'; Source='msstore'; StoreLink='https://apps.microsoft.com/detail/9NTM2QC6QWS7' }
        '9PF4KZ2VN4W9' = @{ Name='Translucent TB'; Source='msstore'; StoreLink='https://apps.microsoft.com/detail/9PF4KZ2VN4W9' }
        '9P67C2D4T9FB' = @{ Name='Seelen UI'; Source='msstore'; StoreLink='https://apps.microsoft.com/detail/9P67C2D4T9FB' }
        'Flow-Launcher.Flow-Launcher' = @{ Name='Flow Launcher' }
        'Rainmeter.Rainmeter' = @{ Name='RainMeter'; SetupLinks = @( 'https://www.droptopfour.com/', 'https://github.com/creewick/MontereyRainmeter/releases')}
    }}
    'Communication' = @{ Name='Comunicacao'; Apps=@{
        'TeamSpeakSystems.TeamSpeak' = @{ Name='TeamSpeak' }
        'Vencord.Vencord' = @{ Name='Vencord'; SetupLinks = @('https://github.com/Vencord/Installer/releases/latest/download/VencordInstaller.exe')}
    }}
    'Games' = @{ Name='Jogos'; Apps=@{
        'FACEITLTD.FACEITClient' = @{ Name='FACEIT' }
        'br.gamersclub.launcher' = @{ Name='GamersClub Launcher' ; SetupLinks = @( 'https://acupdate.gamersclub.com.br/download') }
    }}
}

# Define as ações principais disponíveis no menu inicial do script.
$mainMenuActions = @{
    'Install' = @{ Name = 'Instalar Programas' }
    'Uninstall' = @{ Name = 'Remover Programas' }
    'Update' = @{ Name = 'Atualizar Todos os Programas' }
}

# Define as opções do submenu de remoção
$uninstallMenuActions = @{
    'OOAppBuster' = @{ Name = 'Abrir O&O AppBuster' }
    'WindowsDebloat' = @{ Name = 'Abrir Windows Debloat' }
    'RemoveAI' = @{ Name = 'Remover AI' }
    'Categories' = @{ Name = 'Remover por Categoria' }
}
#endregion

#region Main Loop
# Descrição: O loop principal do script que exibe o menu principal e gerencia a navegação
#            entre as diferentes ações (instalar, remover, atualizar).
while ($true) {
    $mainMenuItems = Show-Menu -Title "Menu Principal" -Options $mainMenuActions -ReturnOption "Sair"
    $mainChoice = Read-Host "Escolha uma opcao"
    if ($mainChoice -eq '0') { break } # Sai do script se '0' for escolhido
    # Valida a escolha do usuário no menu principal
    if (-not $mainMenuItems.ContainsKey([int]$mainChoice)) {
        Write-Host "[ERRO] Opcao invalida!" -ForegroundColor Red
        Start-Sleep 1
        continue # Volta para o início do loop
    }
    $actionKey = $mainMenuItems[[int]$mainChoice]
    # Executa a ação selecionada pelo usuário
    switch ($actionKey) {
        'Update' {
            Update-AllPrograms # Chama a função para atualizar todos os programas
        }
        'Install' {
            # Exibe o menu de categorias para instalação
            $categoryMenuItems = Show-Menu -Title "Instalar - Selecione a Categoria" -Options $categories
            $categoryChoice = Read-Host "Escolha uma opcao"
            if ($categoryChoice -eq '0') { continue } # Volta para o menu principal
            # Se uma categoria válida for escolhida, chama a função para selecionar o aplicativo
            if ($categoryMenuItems.ContainsKey([int]$categoryChoice)) {
                $categoryKey = $categoryMenuItems[[int]$categoryChoice]
                Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'install'
            }
        }
        'Uninstall' {
            # Exibe o submenu de remoção
            while ($true) {
                $uninstallMenuItems = Show-Menu -Title "Remover Programas" -Options $uninstallMenuActions
                $uninstallChoice = Read-Host "Escolha uma opcao"
                if ($uninstallChoice -eq '0') { break } # Volta para o menu principal

                if ($uninstallMenuItems.ContainsKey([int]$uninstallChoice)) {
                    $uninstallKey = $uninstallMenuItems[[int]$uninstallChoice]

                    switch ($uninstallKey) {
                        'OOAppBuster' {
                            Open-OOAppBuster
                        }
                        'WindowsDebloat' {
                            Open-WindowsDebloat
                        }
                        'RemoveAI' {
                            Remove-WindowsAI
                        }
                        'Categories' {
                            # Exibe o menu de categorias para remoção
                            $categoryMenuItems = Show-Menu -Title "Remover - Selecione a Categoria" -Options $categories
                            $categoryChoice = Read-Host "Escolha uma opcao"
                            if ($categoryChoice -eq '0') { continue } # Volta para o submenu
                            # Se uma categoria válida for escolhida, chama a função para selecionar o aplicativo
                            if ($categoryMenuItems.ContainsKey([int]$categoryChoice)) {
                                $categoryKey = $categoryMenuItems[[int]$categoryChoice]
                                Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'uninstall'
                            }
                        }
                    }
                } else {
                    Write-Host "[ERRO] Opcao invalida!" -ForegroundColor Red
                    Start-Sleep 1
                }
            }
        }
    }
}
#endregion
