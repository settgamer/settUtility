Windhawk Pluggins

- Better file sizes in Explorer details
- Taskbar Background Helper
- Taskbar height and icon size
- Taskbar Labels for Windows 11
- Windows 11 Start Menu Styler
- Windows 11 Taskbar Styler
- Taskbar tray system icon tweaks
