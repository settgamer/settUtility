﻿# Verifica se está rodando como Administrador
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Warning "Este script precisa ser executado como Administrador!"
    Write-Host "Pressione qualquer tecla para sair..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

# Variáveis globais
$BackupPath = "$env:USERPROFILE\Desktop\NetworkOptimizer_Backup.json"
$global:ChangesLog = [System.Collections.ArrayList]::new()

# Função para escrever no log (otimizada com StringBuilder)
$global:LogBuilder = [System.Text.StringBuilder]::new()

function Write-Log {
    param(
        [string]$Message,
        [string]$Type = "INFO"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Type] $Message"
    [void]$global:LogBuilder.AppendLine($logEntry)

    switch ($Type) {
        "SUCCESS" { Write-Host $Message -ForegroundColor Green }
        "ERROR" { Write-Host $Message -ForegroundColor Red }
        "WARNING" { Write-Host $Message -ForegroundColor Yellow }
        default { Write-Host $Message -ForegroundColor White }
    }
}

# Função para criar backup das configurações atuais
function Backup-AdapterSettings {
    param([string]$AdapterName)

    Write-Log "Criando backup das configurações de: $AdapterName" "INFO"

    try {
        $currentSettings = Get-NetAdapterAdvancedProperty -Name $AdapterName -ErrorAction Stop

        $backupData = @{
            Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            AdapterName = $AdapterName
            Settings = @($currentSettings | ForEach-Object {
                @{
                    DisplayName = $_.DisplayName
                    RegistryKeyword = $_.RegistryKeyword
                    DisplayValue = $_.DisplayValue
                    RegistryValue = $_.RegistryValue
                }
            })
        }

        # Carrega backups existentes ou cria novo array
        $allBackups = @()
        if (Test-Path $BackupPath) {
            $existingBackups = Get-Content $BackupPath -Raw | ConvertFrom-Json
            if ($existingBackups -is [PSCustomObject]) {
                $allBackups = @($existingBackups)
            } else {
                $allBackups = @($existingBackups)
            }
        }

        # Adiciona novo backup ao array
        $allBackups = $allBackups + $backupData

        # Salva todos os backups
        $allBackups | ConvertTo-Json -Depth 10 -Compress | Set-Content $BackupPath -Force

        Write-Log "✓ Backup criado com sucesso em: $BackupPath" "SUCCESS"
        return $true
    }
    catch {
        Write-Log "✗ Erro ao criar backup: $_" "ERROR"
        return $false
    }
}

# Função para aplicar configuração com log (otimizada)
function Set-NetworkProperty {
    param(
        [string]$AdapterName,
        [string[]]$PropertyNames,
        [string]$Value,
        [hashtable]$PropertyCache
    )

    foreach ($propName in $PropertyNames) {
        if ($PropertyCache.ContainsKey($propName)) {
            $property = $PropertyCache[$propName]

            try {
                $oldValue = $property.DisplayValue
                Set-NetAdapterAdvancedProperty -Name $AdapterName -RegistryKeyword $property.RegistryKeyword -RegistryValue ([string[]]$Value) -ErrorAction Stop -WarningAction SilentlyContinue

                $newProperty = Get-NetAdapterAdvancedProperty -Name $AdapterName -RegistryKeyword $property.RegistryKeyword -ErrorAction SilentlyContinue
                if ($newProperty.DisplayValue -eq $Value) {
                    [void]$global:ChangesLog.Add(@{
                        Property = $propName
                        OldValue = $oldValue
                        NewValue = $Value
                        Status = "SUCCESS"
                    })
                    Write-Log "  ✓ $propName : $oldValue → $Value" "SUCCESS"
                }
                return
            } catch {
                try {
                    Set-NetAdapterAdvancedProperty -Name $AdapterName -DisplayName $propName -DisplayValue $Value -ErrorAction Stop -WarningAction SilentlyContinue
                    $newProperty = Get-NetAdapterAdvancedProperty -Name $AdapterName -DisplayName $propName -ErrorAction SilentlyContinue
                    if ($newProperty.DisplayValue -eq $Value) {
                        [void]$global:ChangesLog.Add(@{
                            Property = $propName
                            OldValue = $oldValue
                            NewValue = $Value
                            Status = "SUCCESS"
                        })
                        Write-Log "  ✓ $propName : $oldValue → $Value" "SUCCESS"
                    }
                    return
                } catch {
                    # Ignora erro
                }
            }
        }
    }
}

# Função para criar cache de propriedades (melhora performance)
function Get-PropertyCache {
    param([string]$AdapterName)

    $cache = @{}
    try {
        $properties = Get-NetAdapterAdvancedProperty -Name $AdapterName -ErrorAction Stop
        foreach ($prop in $properties) {
            $cache[$prop.DisplayName] = $prop
        }
    } catch {
        Write-Log "⚠ Erro ao criar cache de propriedades" "WARNING"
    }
    return $cache
}

# Função para reverter para configurações padrão
function Restore-DefaultSettings {
    param([string]$AdapterName)

    Clear-Host
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "REVERTENDO PARA CONFIGURAÇÕES PADRÃO" -ForegroundColor Cyan
    Write-Host "Adaptador: $AdapterName" -ForegroundColor Yellow
    Write-Host "========================================`n" -ForegroundColor Cyan

    $global:ChangesLog.Clear()

    try {
        $allProperties = Get-NetAdapterAdvancedProperty -Name $AdapterName -ErrorAction Stop
        $total = $allProperties.Count
        $count = 0

        foreach ($property in $allProperties) {
            $count++
            Write-Progress -Activity "Revertendo configurações para padrão" -Status "Processando $($property.DisplayName)..." -PercentComplete (($count / $total) * 100)

            try {
                $oldValue = $property.DisplayValue
                $defaultValue = $null

                if ($property.DefaultRegistryValue) {
                    $defaultValue = $property.DefaultRegistryValue
                } elseif ($property.DefaultDisplayValue) {
                    $defaultValue = $property.DefaultDisplayValue
                } else {
                    $defaultValues = @("Auto", "Auto Negotiation", "Default", "Enabled", "Not Configured")
                    $validValues = $property.ValidDisplayValues

                    foreach ($testValue in $defaultValues) {
                        if ($validValues -contains $testValue) {
                            $defaultValue = $testValue
                            break
                        }
                    }
                }

                if ($defaultValue) {
                    Set-NetAdapterAdvancedProperty -Name $AdapterName -RegistryKeyword $property.RegistryKeyword -RegistryValue ([string[]]$defaultValue) -ErrorAction Stop -WarningAction SilentlyContinue

                    $newProperty = Get-NetAdapterAdvancedProperty -Name $AdapterName -RegistryKeyword $property.RegistryKeyword -ErrorAction SilentlyContinue

                    if ($newProperty.DisplayValue -ne $oldValue) {
                        [void]$global:ChangesLog.Add(@{
                            Property = $property.DisplayName
                            OldValue = $oldValue
                            NewValue = $newProperty.DisplayValue
                            Status = "SUCCESS"
                        })
                    }
                }
            } catch {
                # Silencioso
            }
        }

        Write-Progress -Activity "Revertendo configurações" -Completed
        Export-ChangeLog -IsDefaultRestore $true

    } catch {
        Write-Host "`n✗ Erro durante reversão: $_" -ForegroundColor Red
    }
}

# Função para restaurar de backup
function Restore-FromBackup {
    param([string]$AdapterName)

    Clear-Host

    if (-not (Test-Path $BackupPath)) {
        Write-Host "`n✗ Nenhum arquivo de backup encontrado!" -ForegroundColor Red
        return
    }

    try {
        $allBackups = Get-Content $BackupPath -Raw | ConvertFrom-Json
        $adapterBackups = @($allBackups | Where-Object { $_.AdapterName -eq $AdapterName })

        if ($adapterBackups.Count -eq 0) {
            Write-Host "`n✗ Nenhum backup encontrado para este adaptador!" -ForegroundColor Red
            return
        }

        Write-Host "`nBackups disponíveis para $AdapterName :" -ForegroundColor Yellow
        for ($i = 0; $i -lt $adapterBackups.Count; $i++) {
            Write-Host "  [$($i+1)] Backup de $($adapterBackups[$i].Timestamp)" -ForegroundColor Cyan
        }

        $backupChoice = Read-Host "`nEscolha o backup para restaurar (número)"
        $selectedBackup = $adapterBackups[$backupChoice - 1]

        if (-not $selectedBackup) {
            Write-Host "`n✗ Backup inválido!" -ForegroundColor Red
            return
        }

        Clear-Host
        Write-Host "`n========================================" -ForegroundColor Cyan
        Write-Host "RESTAURANDO BACKUP" -ForegroundColor Cyan
        Write-Host "Data: $($selectedBackup.Timestamp)" -ForegroundColor Yellow
        Write-Host "========================================`n" -ForegroundColor Cyan

        $global:ChangesLog.Clear()

        $total = $selectedBackup.Settings.Count
        $count = 0

        foreach ($setting in $selectedBackup.Settings) {
            $count++
            Write-Progress -Activity "Restaurando backup" -Status "Processando $($setting.DisplayName)..." -PercentComplete (($count / $total) * 100)

            try {
                $currentProperty = Get-NetAdapterAdvancedProperty -Name $AdapterName -DisplayName $setting.DisplayName -ErrorAction SilentlyContinue
                if ($currentProperty) {
                    $oldValue = $currentProperty.DisplayValue
                    Set-NetAdapterAdvancedProperty -Name $AdapterName -RegistryKeyword $setting.RegistryKeyword -RegistryValue $setting.RegistryValue -ErrorAction Stop -WarningAction SilentlyContinue

                    [void]$global:ChangesLog.Add(@{
                        Property = $setting.DisplayName
                        OldValue = $oldValue
                        NewValue = $setting.DisplayValue
                        Status = "SUCCESS"
                    })
                }
            } catch {
                # Silencioso
            }
        }

        Write-Progress -Activity "Restaurando backup" -Completed
        Export-ChangeLog -IsBackupRestore $true

    } catch {
        Write-Host "`n✗ Erro ao restaurar backup: $_" -ForegroundColor Red
    }
}

# Função para exportar log de mudanças
function Export-ChangeLog {
    param(
        [bool]$IsBackupRestore = $false,
        [bool]$IsDefaultRestore = $false
    )

    if ($global:ChangesLog.Count -eq 0) {
        Write-Host "`n⚠ Nenhuma alteração foi registrada." -ForegroundColor Yellow
        Write-Host "   As configurações já estavam nos valores padrão." -ForegroundColor Gray
        return
    }

    Write-Host ""
    Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "                     RESUMO DAS ALTERAÇÕES" -ForegroundColor Cyan
    Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ("Total de propriedades alteradas: " + $global:ChangesLog.Count) -ForegroundColor Yellow
    Write-Host ""

    foreach ($change in $global:ChangesLog) {
        $prop = $change.Property.PadRight(35)
        $old  = $change.OldValue.PadRight(15)
        $new  = $change.NewValue.PadRight(15)

        if ($old.Trim() -ne $new.Trim()) {
            Write-Host ("• " + $prop + " " + $old + " → " + $new) -ForegroundColor Green
        } else {
            Write-Host ("• " + $prop + " " + $old + " → " + $new) -ForegroundColor DarkGray
        }
    }

    Write-Host ""
    Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Cyan

    if ($IsBackupRestore) {
        Write-Host "✅  Backup restaurado com sucesso!" -ForegroundColor Green
    } elseif ($IsDefaultRestore) {
        Write-Host "✅  Configurações revertidas para padrão com sucesso!" -ForegroundColor Green
    }
}

# Função para aplicar configurações de Ethernet
function Apply-EthernetSettings {
    param([string]$AdapterName)

    Clear-Host
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "APLICANDO CONFIGURAÇÕES DE ETHERNET" -ForegroundColor Cyan
    Write-Host "Adaptador: $AdapterName" -ForegroundColor Yellow
    Write-Host "========================================`n" -ForegroundColor Cyan

    $createBackup = Read-Host "Deseja criar um backup antes de aplicar? (S/N)"
    if ($createBackup -match '^[Ss]$') {
        Write-Host ""
        Backup-AdapterSettings -AdapterName $AdapterName
        Write-Host ""
    }

    $global:LogBuilder.Clear()
    Write-Log "`n========== OTIMIZAÇÃO DE ETHERNET ==========" "INFO"
    Write-Log "Adaptador: $AdapterName" "INFO"
    Write-Log "Data/Hora: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" "INFO"

    $global:ChangesLog.Clear()

    Write-Host "Carregando propriedades do adaptador..." -ForegroundColor Yellow
    $propertyCache = Get-PropertyCache -AdapterName $AdapterName
    Write-Host "✓ Cache criado com $($propertyCache.Count) propriedades`n" -ForegroundColor Green

    $configs = @(
        @{Names=@("Flow Control"); Value="Disabled"},
        @{Names=@("Jumbo Packet", "Jumbo Frame"); Value="Disabled"},
        @{Names=@("Energy Efficient Ethernet", "Energy-Efficient Ethernet", "EEE"); Value="Disabled"},
        @{Names=@("Power Saving Mode"); Value="Disabled"},
        @{Names=@("Auto Disable Gigabit"); Value="Disabled"},
        @{Names=@("Wake on Magic Packet"); Value="Disabled"},
        @{Names=@("Wake on pattern match", "Wake on Pattern Match"); Value="Disabled"},
        @{Names=@("Shutdown Wake-On-Lan", "Shutdown Wake-On-LAN"); Value="Disabled"},
        @{Names=@("NS Offload"); Value="Enabled"},
        @{Names=@("ARP Offload"); Value="Enabled"},
        @{Names=@("Receive Buffers"); Value="1024"},
        @{Names=@("Transmit Buffers"); Value="1024"},
        @{Names=@("Large Send Offload V2 (IPv4)", "Large Send Offload v2 (IPv4)"); Value="Disabled"},
        @{Names=@("Large Send Offload V2 (IPv6)", "Large Send Offload v2 (IPv6)"); Value="Disabled"},
        @{Names=@("Large Receive Offload (IPv4)"); Value="Disabled"},
        @{Names=@("Large Receive Offload (IPv6)"); Value="Disabled"},
        @{Names=@("IPv4 Checksum Offload"); Value="Enabled"},
        @{Names=@("TCP Checksum Offload (IPv4)"); Value="Enabled"},
        @{Names=@("TCP Checksum Offload (IPv6)"); Value="Enabled"},
        @{Names=@("UDP Checksum Offload (IPv4)"); Value="Enabled"},
        @{Names=@("UDP Checksum Offload (IPv6)"); Value="Enabled"},
        @{Names=@("Gigabit Lite"); Value="Disabled"},
        @{Names=@("Interrupt Moderation"); Value="Enabled"},
        @{Names=@("Adaptive Inter-Frame Spacing"); Value="Disabled"},
        @{Names=@("Receive Side Scaling"); Value="Enabled"},
        @{Names=@("Log Link State Event"); Value="Disabled"},
        @{Names=@("Speed &amp; Duplex", "Speed and Duplex"); Value="Auto Negotiation"},
        @{Names=@("Green Ethernet"); Value="Disabled"},
        @{Names=@("DMA Coalescing"); Value="Disabled"},
        @{Names=@("Enable PME"); Value="Disabled"},
        @{Names=@("Priority &amp; VLAN", "Priority and VLAN"); Value="Disabled"},
        @{Names=@("PTP Hardware Timestamp"); Value="Disabled"},
        @{Names=@("Reduce Speed On Power Down"); Value="Disabled"},
        @{Names=@("Software Timestamp"); Value="Disabled"},
        @{Names=@("Wait for Link"); Value="Disabled"},
        @{Names=@("Wake on Link Settings"); Value="Disabled"}
    )

    $total = $configs.Count
    $count = 0

    foreach ($config in $configs) {
        Set-NetworkProperty -AdapterName $AdapterName -PropertyNames $config.Names -Value $config.Value -PropertyCache $propertyCache
        $count++
        Write-Progress -Activity "Aplicando configurações Ethernet" -Status "Processando..." -PercentComplete (($count / $total) * 100)
    }

    Write-Progress -Activity "Aplicando configurações Ethernet" -Completed
    Write-Host "`n✓ Configurações de Ethernet aplicadas com sucesso!" -ForegroundColor Green
    Write-Log "`n✓ Otimização de Ethernet concluída!" "SUCCESS"

    Export-ChangeLog
}

# Função para aplicar configurações de Wi-Fi
function Apply-WiFiSettings {
    param([string]$AdapterName)

    Clear-Host
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "APLICANDO CONFIGURAÇÕES DE WI-FI" -ForegroundColor Cyan
    Write-Host "Adaptador: $AdapterName" -ForegroundColor Yellow
    Write-Host "========================================`n" -ForegroundColor Cyan

    $createBackup = Read-Host "Deseja criar um backup antes de aplicar? (S/N)"
    if ($createBackup -match '^[Ss]$') {
        Write-Host ""
        Backup-AdapterSettings -AdapterName $AdapterName
        Write-Host ""
    }

    $global:LogBuilder.Clear()
    Write-Log "`n========== OTIMIZAÇÃO DE WI-FI ==========" "INFO"
    Write-Log "Adaptador: $AdapterName" "INFO"
    Write-Log "Data/Hora: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" "INFO"

    $global:ChangesLog.Clear()

    Write-Host "Carregando propriedades do adaptador..." -ForegroundColor Yellow
    $propertyCache = Get-PropertyCache -AdapterName $AdapterName
    Write-Host "✓ Cache criado com $($propertyCache.Count) propriedades`n" -ForegroundColor Green

    $configs = @(
        @{Names=@("20/40 MHz Coexistence", "20/40 Coexistence"); Value="Enabled"},
        @{Names=@("40 MHz Intolerant", "Fat Channel Intolerant"); Value="Disabled"},
        @{Names=@("802.11n Preamble"); Value="Auto"},
        @{Names=@("Afterburner"); Value="Disabled"},
        @{Names=@("Antenna Diversity"); Value="Auto"},
        @{Names=@("Bandwidth Capability"); Value="Auto"},
        @{Names=@("Beamforming"); Value="Enabled"},
        @{Names=@("Bluetooth Collaboration", "Bluetooth Coexistence"); Value="Enabled"},
        @{Names=@("Channel Width", "Channel Width for 2.4GHz", "Channel Width for 5GHz"); Value="Auto"},
        @{Names=@("Fat Channel Intolerant"); Value="Disabled"},
        @{Names=@("Fragmentation Threshold"); Value="2346"},
        @{Names=@("Global BG Scan blocking"); Value="Always"},
        @{Names=@("GTK rekeying for WoWLAN"); Value="Enabled"},
        @{Names=@("HT Mode"); Value="Enabled"},
        @{Names=@("Intel Throughput Enhancement", "Throughput Enhancement"); Value="Enabled"},
        @{Names=@("MIMO Power Save Mode"); Value="No SMPS"},
        @{Names=@("Minimum Power Consumption"); Value="Disabled"},
        @{Names=@("Mixed Mode Protection"); Value="CTS-to-self Enabled"},
        @{Names=@("NS Offload"); Value="Disabled"},
        @{Names=@("Packet Coalescing"); Value="Disabled"},
        @{Names=@("Power Output", "Transmit Power"); Value="Highest"},
        @{Names=@("Preferred Band"); Value="Prefer 5GHz band"},
        @{Names=@("Priority &amp; VLAN", "Priority and VLAN"); Value="Disabled"},
        @{Names=@("Roaming Aggressiveness", "Roaming Decision"); Value="Medium"},
        @{Names=@("Roam Tendency"); Value="Moderate"},
        @{Names=@("RTS Threshold"); Value="2347"},
        @{Names=@("Short GI", "Short Guard Interval"); Value="Enabled"},
        @{Names=@("Throughput Booster"); Value="Enabled"},
        @{Names=@("U-APSD support", "WMM Power Save Mode", "U-APSD"); Value="Disabled"},
        @{Names=@("WiFi Rekeying Offload", "GTK Rekeying Offload"); Value="Enabled"},
        @{Names=@("Wireless Mode"); Value="Auto"},
        @{Names=@("WMM", "WME"); Value="Disabled"},
        @{Names=@("Xpress Technology"); Value="Disabled"}
    )

    $total = $configs.Count
    $count = 0

    foreach ($config in $configs) {
        Set-NetworkProperty -AdapterName $AdapterName -PropertyNames $config.Names -Value $config.Value -PropertyCache $propertyCache
        $count++
        Write-Progress -Activity "Aplicando configurações Wi-Fi" -Status "Processando..." -PercentComplete (($count / $total) * 100)
    }

    Write-Progress -Activity "Aplicando configurações Wi-Fi" -Completed
    Write-Host "`n✓ Configurações de Wi-Fi aplicadas com sucesso!" -ForegroundColor Green
    Write-Log "`n✓ Otimização de Wi-Fi concluída!" "SUCCESS"

    Export-ChangeLog
}

# Função para listar adaptadores
function Get-AdaptersByType {
    param([string]$Type)

    Write-Host "`nDetectando adaptadores de rede..." -ForegroundColor Yellow

    try {
        $allAdapters = Get-NetAdapter -ErrorAction Stop
        $filtered = @()

        if ($Type -eq "Ethernet") {
            foreach ($adapter in $allAdapters) {
                if (($adapter.Status -eq "Up") -and
                    ($adapter.InterfaceDescription -notlike "*Wireless*") -and
                    ($adapter.InterfaceDescription -notlike "*Wi-Fi*") -and
                    ($adapter.InterfaceDescription -notlike "*802.11*") -and
                    ($adapter.Name -notlike "*Wi-Fi*")) {
                    $filtered += $adapter
                }
            }

            if ($filtered.Count -eq 0) {
                $filtered = @($allAdapters | Where-Object { 
                    $_.Status -eq "Up" -and 
                    $_.InterfaceDescription -notlike "*Wireless*" -and 
                    $_.InterfaceDescription -notlike "*Wi-Fi*" 
                })
            }
        } else {
            $filtered = @($allAdapters | Where-Object {
                ($_.Status -eq "Up") -and (
                    ($_.InterfaceDescription -like "*Wireless*") -or
                    ($_.InterfaceDescription -like "*Wi-Fi*") -or
                    ($_.InterfaceDescription -like "*802.11*") -or
                    ($_.Name -like "*Wi-Fi*")
                )
            })
        }

        return $filtered
    }
    catch {
        Write-Host "ERRO ao detectar adaptadores: $_" -ForegroundColor Red
        return @()
    }
}

# Menu Principal
function Show-Menu {
    Clear-Host
    Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║      OTIMIZADOR DE ADAPTADORES DE REDE - by SETT       ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  OTIMIZAR:" -ForegroundColor Yellow
    Write-Host "  [1] Adaptador ETHERNET" -ForegroundColor White
    Write-Host "  [2] Adaptador WI-FI" -ForegroundColor White
    Write-Host ""
    Write-Host "  REVERTER:" -ForegroundColor Yellow
    Write-Host "  [3] Ethernet para PADRÃO (Default/Auto)" -ForegroundColor White
    Write-Host "  [4] Wi-Fi para PADRÃO (Default/Auto)" -ForegroundColor White
    Write-Host ""
    Write-Host "  RESTAURAR BACKUP:" -ForegroundColor Yellow
    Write-Host "  [5] Restaurar Ethernet de Backup" -ForegroundColor White
    Write-Host "  [6] Restaurar Wi-Fi de Backup" -ForegroundColor White
    Write-Host ""
    Write-Host "  [7] Sair" -ForegroundColor Red
    Write-Host ""
    Write-Host "════════════════════════════════════════════════════════" -ForegroundColor Cyan
}

# Loop principal
do {
    Show-Menu
    $choice = Read-Host "`nEscolha uma opção"

    switch ($choice) {
        "1" {
            Clear-Host
            $ethernetAdapters = Get-AdaptersByType -Type "Ethernet"

            if ($ethernetAdapters.Count -eq 0) {
                Write-Host "`n✗ Nenhum adaptador Ethernet ativo encontrado!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            Write-Host "`nAdaptadores Ethernet encontrados:" -ForegroundColor Green
            $ethernetAdapters = @($ethernetAdapters)

            for ($i = 0; $i -lt $ethernetAdapters.Count; $i++) {
                $adapter = $ethernetAdapters[$i]
                Write-Host "  [$($i+1)] $($adapter.Name) - $($adapter.InterfaceDescription)" -ForegroundColor Yellow
            }

            $adapterChoice = Read-Host "`nEscolha o adaptador (número)"

            if ([string]::IsNullOrWhiteSpace($adapterChoice)) {
                Write-Host "`n✗ Nenhuma opção selecionada!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            $index = [int]$adapterChoice - 1

            if ($index -ge 0 -and $index -lt $ethernetAdapters.Count) {
                $selectedAdapter = $ethernetAdapters[$index]
                Apply-EthernetSettings -AdapterName $selectedAdapter.Name
            } else {
                Write-Host "`n✗ Adaptador inválido!" -ForegroundColor Red
            }

            Write-Host "`nPressione qualquer tecla para voltar ao menu..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "2" {
            Clear-Host
            $wifiAdapters = Get-AdaptersByType -Type "WiFi"

            if ($wifiAdapters.Count -eq 0) {
                Write-Host "`n✗ Nenhum adaptador Wi-Fi ativo encontrado!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            Write-Host "`nAdaptadores Wi-Fi encontrados:" -ForegroundColor Green
            $wifiAdapters = @($wifiAdapters)

            for ($i = 0; $i -lt $wifiAdapters.Count; $i++) {
                $adapter = $wifiAdapters[$i]
                Write-Host "  [$($i+1)] $($adapter.Name) - $($adapter.InterfaceDescription)" -ForegroundColor Yellow
            }

            $adapterChoice = Read-Host "`nEscolha o adaptador (número)"

            if ([string]::IsNullOrWhiteSpace($adapterChoice)) {
                Write-Host "`n✗ Nenhuma opção selecionada!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            $index = [int]$adapterChoice - 1

            if ($index -ge 0 -and $index -lt $wifiAdapters.Count) {
                $selectedAdapter = $wifiAdapters[$index]
                Apply-WiFiSettings -AdapterName $selectedAdapter.Name
            } else {
                Write-Host "`n✗ Adaptador inválido!" -ForegroundColor Red
            }

            Write-Host "`nPressione qualquer tecla para voltar ao menu..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "3" {
            Clear-Host
            $ethernetAdapters = Get-AdaptersByType -Type "Ethernet"

            if ($ethernetAdapters.Count -eq 0) {
                Write-Host "`n✗ Nenhum adaptador Ethernet ativo encontrado!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            Write-Host "`nAdaptadores Ethernet encontrados:" -ForegroundColor Green
            $ethernetAdapters = @($ethernetAdapters)

            for ($i = 0; $i -lt $ethernetAdapters.Count; $i++) {
                $adapter = $ethernetAdapters[$i]
                Write-Host "  [$($i+1)] $($adapter.Name) - $($adapter.InterfaceDescription)" -ForegroundColor Yellow
            }

            $adapterChoice = Read-Host "`nEscolha o adaptador (número)"
            $index = [int]$adapterChoice - 1

            if ($index -ge 0 -and $index -lt $ethernetAdapters.Count) {
                $selectedAdapter = $ethernetAdapters[$index]
                $global:LogBuilder.Clear()
                Restore-DefaultSettings -AdapterName $selectedAdapter.Name
            } else {
                Write-Host "`n✗ Adaptador inválido!" -ForegroundColor Red
            }

            Write-Host "`nPressione qualquer tecla para voltar ao menu..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "4" {
            Clear-Host
            $wifiAdapters = Get-AdaptersByType -Type "WiFi"

            if ($wifiAdapters.Count -eq 0) {
                Write-Host "`n✗ Nenhum adaptador Wi-Fi ativo encontrado!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            Write-Host "`nAdaptadores Wi-Fi encontrados:" -ForegroundColor Green
            $wifiAdapters = @($wifiAdapters)

            for ($i = 0; $i -lt $wifiAdapters.Count; $i++) {
                $adapter = $wifiAdapters[$i]
                Write-Host "  [$($i+1)] $($adapter.Name) - $($adapter.InterfaceDescription)" -ForegroundColor Yellow
            }

            $adapterChoice = Read-Host "`nEscolha o adaptador (número)"
            $index = [int]$adapterChoice - 1

            if ($index -ge 0 -and $index -lt $wifiAdapters.Count) {
                $selectedAdapter = $wifiAdapters[$index]
                $global:LogBuilder.Clear()
                Restore-DefaultSettings -AdapterName $selectedAdapter.Name
            } else {
                Write-Host "`n✗ Adaptador inválido!" -ForegroundColor Red
            }

            Write-Host "`nPressione qualquer tecla para voltar ao menu..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "5" {
            Clear-Host
            $ethernetAdapters = Get-AdaptersByType -Type "Ethernet"

            if ($ethernetAdapters.Count -eq 0) {
                Write-Host "`n✗ Nenhum adaptador Ethernet ativo encontrado!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            Write-Host "`nAdaptadores Ethernet encontrados:" -ForegroundColor Green
            $ethernetAdapters = @($ethernetAdapters)

            for ($i = 0; $i -lt $ethernetAdapters.Count; $i++) {
                $adapter = $ethernetAdapters[$i]
                Write-Host "  [$($i+1)] $($adapter.Name) - $($adapter.InterfaceDescription)" -ForegroundColor Yellow
            }

            $adapterChoice = Read-Host "`nEscolha o adaptador (número)"
            $index = [int]$adapterChoice - 1

            if ($index -ge 0 -and $index -lt $ethernetAdapters.Count) {
                $selectedAdapter = $ethernetAdapters[$index]
                $global:LogBuilder.Clear()
                Restore-FromBackup -AdapterName $selectedAdapter.Name
            } else {
                Write-Host "`n✗ Adaptador inválido!" -ForegroundColor Red
            }

            Write-Host "`nPressione qualquer tecla para voltar ao menu..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "6" {
            Clear-Host
            $wifiAdapters = Get-AdaptersByType -Type "WiFi"

            if ($wifiAdapters.Count -eq 0) {
                Write-Host "`n✗ Nenhum adaptador Wi-Fi ativo encontrado!" -ForegroundColor Red
                Write-Host "`nPressione qualquer tecla para voltar ao menu..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                continue
            }

            Write-Host "`nAdaptadores Wi-Fi encontrados:" -ForegroundColor Green
            $wifiAdapters = @($wifiAdapters)

            for ($i = 0; $i -lt $wifiAdapters.Count; $i++) {
                $adapter = $wifiAdapters[$i]
                Write-Host "  [$($i+1)] $($adapter.Name) - $($adapter.InterfaceDescription)" -ForegroundColor Yellow
            }

            $adapterChoice = Read-Host "`nEscolha o adaptador (número)"
            $index = [int]$adapterChoice - 1

            if ($index -ge 0 -and $index -lt $wifiAdapters.Count) {
                $selectedAdapter = $wifiAdapters[$index]
                $global:LogBuilder.Clear()
                Restore-FromBackup -AdapterName $selectedAdapter.Name
            } else {
                Write-Host "`n✗ Adaptador inválido!" -ForegroundColor Red
            }

            Write-Host "`nPressione qualquer tecla para voltar ao menu..."
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        }
        "7" {
            Write-Host "`nSaindo..." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
            Stop-Process -Id $PID 
        }
        default {
            Write-Host "`n✗ Opção inválida!" -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }
} while ($choice -ne "7")
