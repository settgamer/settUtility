﻿#Requires -RunAsAdministrator

$Host.UI.RawUI.BackgroundColor = "Black"
Clear-Host

function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-Host "  ╔════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║     LIMPEZA DE CACHE E TEMPORARIOS        ║" -ForegroundColor Yellow
    Write-Host "  ╚════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  [1] Delete Update Cache" -ForegroundColor Green
    Write-Host "  [2] Delete Temporary Files" -ForegroundColor Green
    Write-Host "  [3] Delete Log Files" -ForegroundColor Green
    Write-Host "  [4] Clean Cache (Menu Completo)" -ForegroundColor Green
    Write-Host "  [5] Clean Temp" -ForegroundColor Green
    Write-Host "  [6] Limpeza Avancada do Sistema" -ForegroundColor Magenta
    Write-Host "  [7] Device Cleanup" -ForegroundColor Cyan
    Write-Host "  [0] Sair" -ForegroundColor Red
    Write-Host ""
}

# === FUNCAO AUXILIAR: Limpar Diretorio COM PROGRESSO (SEM TRAVAR) ===
function Remove-DirectoryContent {
    param([string]$Path, [string]$Description)

    if (-not (Test-Path $Path)) {
        Write-Host "  ⚠️ $Description nao encontrado" -ForegroundColor DarkYellow
        return
    }

    Write-Host "  🔄 Limpando: $Description" -ForegroundColor Cyan

    $items = Get-ChildItem -Path $Path -Force -ErrorAction SilentlyContinue

    if ($items.Count -eq 0) {
        Write-Host "  ✔ Nada para limpar em $Description" -ForegroundColor Green
        return
    }

    $total = $items.Count
    $i = 0

    foreach ($item in $items) {
        $i++
        $percent = [math]::Round(($i / $total) * 100)

        Write-Progress -Activity "Limpando $Description" -Status "$i de $total" -PercentComplete $percent

        try {
            Remove-Item $item.FullName -Recurse -Force -ErrorAction SilentlyContinue
        } catch {
            # Ignora erros de arquivos em uso
        }
    }

    Write-Progress -Activity "Limpando $Description" -Completed
    Write-Host "  ✅ $Description limpo!" -ForegroundColor Green
}

# === OPCAO 1: Delete Update Cache ===
function Invoke-DeleteUpdateCache {
    Clear-Host
    Write-Host "`n  🔄 Delete Update Cache..." -ForegroundColor Yellow
    Write-Host ""

    Write-Progress -Activity "Delete Update Cache" -Status "Parando servicos..." -PercentComplete 20
    net stop wuauserv | Out-Null
    net stop UsoSvc | Out-Null

    Write-Progress -Activity "Delete Update Cache" -Status "Removendo cache..." -PercentComplete 50
    Remove-Item -Path "C:\Windows\SoftwareDistribution\Download\*" -Recurse -Force -ErrorAction SilentlyContinue

    Write-Progress -Activity "Delete Update Cache" -Status "Iniciando servicos..." -PercentComplete 80
    net start wuauserv | Out-Null
    net start UsoSvc | Out-Null

    Write-Progress -Activity "Delete Update Cache" -Completed
    Write-Host "  ✅ Update Cache deletado" -ForegroundColor Green
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

# === OPCAO 2: Delete Temporary Files ===
function Invoke-DeleteTemporaryFiles {
    Clear-Host
    Write-Host "`n  🗑️ Delete Temporary Files..." -ForegroundColor Yellow
    Write-Host ""

    Remove-DirectoryContent -Path $env:TEMP -Description "User TEMP"
    Remove-DirectoryContent -Path "C:\Windows\Temp" -Description "Windows TEMP"

    Write-Host ""
    Read-Host "  Pressione ENTER"
}

# === OPCAO 3: Delete Log Files ===
function Invoke-DeleteLogFiles {
    Clear-Host
    Write-Host "`n  📋 Delete Log Files..." -ForegroundColor Yellow
    Write-Host ""

    Write-Progress -Activity "Delete Log Files" -Status "Procurando arquivos .log..." -PercentComplete 50
    Set-Location C:\
    Remove-Item -Path "*.log" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Progress -Activity "Delete Log Files" -Completed

    Write-Host "  ✅ Log Files deletados" -ForegroundColor Green
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

# === OPCAO 4: Clean Cache (Menu Completo) ===
function Show-CleanCacheMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "  ╔════════════════════════════════════════════╗" -ForegroundColor Cyan
        Write-Host "  ║           CLEAN CACHE MENU                ║" -ForegroundColor Yellow
        Write-Host "  ╚════════════════════════════════════════════╝" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  [1] Temporary Files" -ForegroundColor Green
        Write-Host "  [2] Browser Cache" -ForegroundColor Green
        Write-Host "  [3] Windows Update Cache" -ForegroundColor Green
        Write-Host "  [4] Prefetch Files" -ForegroundColor Green
        Write-Host "  [5] Windows Store Cache" -ForegroundColor Green
        Write-Host "  [6] Windows Log Files" -ForegroundColor Green
        Write-Host "  [7] Memory Dump Files" -ForegroundColor Green
        Write-Host "  [8] Delivery Optimization" -ForegroundColor Green
        Write-Host "  [9] DirectX Shader Cache" -ForegroundColor Green
        Write-Host "  [0] Voltar" -ForegroundColor Red
        Write-Host ""

        $choice = Read-Host "  Escolha"

        switch ($choice) {
            "1" { Clear-TempFiles }
            "2" { Show-BrowserCacheMenu }
            "3" { Clear-UpdateCache }
            "4" { Clear-PrefetchFiles }
            "5" { Clear-StoreCache }
            "6" { Clear-LogFiles }
            "7" { Clear-MemoryDump }
            "8" { Clear-DeliveryOptimization }
            "9" { Clear-ShaderCache }
            "0" { return }
            default { 
                Write-Host "  ❌ Invalido" -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

function Show-BrowserCacheMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "  ╔════════════════════════════════════════════╗" -ForegroundColor Cyan
        Write-Host "  ║        BROWSER CACHE MENU                 ║" -ForegroundColor Yellow
        Write-Host "  ╚════════════════════════════════════════════╝" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  [1] Google Chrome" -ForegroundColor Green
        Write-Host "  [2] Mozilla Firefox" -ForegroundColor Green
        Write-Host "  [3] Opera GX" -ForegroundColor Green
        Write-Host "  [4] Brave" -ForegroundColor Green
        Write-Host "  [0] Voltar" -ForegroundColor Red
        Write-Host ""

        $choice = Read-Host "  Escolha"

        switch ($choice) {
            "1" { Clear-BrowserCache -Browser "Chrome" -Path "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache" }
            "2" { Clear-FirefoxCache }
            "3" { Clear-BrowserCache -Browser "Opera GX" -Path "$env:APPDATA\Opera Software\Opera GX Stable\Cache" }
            "4" { Clear-BrowserCache -Browser "Brave" -Path "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache" }
            "0" { return }
            default { 
                Write-Host "  ❌ Invalido" -ForegroundColor Red
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

function Clear-TempFiles {
    Clear-Host
    Write-Host "`n  🗑️ Limpando Temporary Files..." -ForegroundColor Yellow
    Write-Host ""
    Remove-DirectoryContent -Path $env:TEMP -Description "Temporary Files"
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-BrowserCache {
    param([string]$Browser, [string]$Path)

    Clear-Host
    Write-Host "`n  🌐 Limpando $Browser Cache..." -ForegroundColor Yellow
    Write-Host ""
    Remove-DirectoryContent -Path $Path -Description "$Browser Cache"
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-FirefoxCache {
    Clear-Host
    Write-Host "`n  🌐 Limpando Firefox Cache..." -ForegroundColor Yellow
    Write-Host ""

    $firefoxPath = "C:\Program Files\Mozilla Firefox\firefox.exe"
    if (Test-Path $firefoxPath) {
        Write-Progress -Activity "Limpando Firefox Cache" -Status "Executando limpeza..." -PercentComplete 50
        Start-Process -FilePath $firefoxPath -ArgumentList '-P "default" -no-remote -safe-mode -jsconsole -clearcache' -Wait -WindowStyle Hidden
        Write-Progress -Activity "Limpando Firefox Cache" -Completed
        Write-Host "  ✅ Firefox Cache limpo" -ForegroundColor Green
    } else {
        Write-Host "  ⚠️ Firefox nao encontrado" -ForegroundColor DarkYellow
    }

    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-UpdateCache {
    Clear-Host
    Write-Host "`n  🔄 Limpando Windows Update Cache..." -ForegroundColor Yellow
    Write-Host ""

    Write-Progress -Activity "Windows Update Cache" -Status "Parando servico..." -PercentComplete 30
    net stop wuauserv | Out-Null

    Remove-DirectoryContent -Path "$env:windir\SoftwareDistribution\Download" -Description "Update Cache"

    Write-Progress -Activity "Windows Update Cache" -Status "Iniciando servico..." -PercentComplete 80
    net start wuauserv | Out-Null
    Write-Progress -Activity "Windows Update Cache" -Completed

    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-PrefetchFiles {
    Clear-Host
    Write-Host "`n  ⚡ Limpando Prefetch Files..." -ForegroundColor Yellow
    Write-Host ""
    Remove-DirectoryContent -Path "$env:windir\Prefetch" -Description "Prefetch Files"
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-StoreCache {
    Clear-Host
    Write-Host "`n  🏪 Limpando Windows Store Cache..." -ForegroundColor Yellow
    Write-Host ""

    Write-Progress -Activity "Windows Store Cache" -Status "Resetando..." -PercentComplete 50
    Start-Process "wsreset.exe" -WindowStyle Hidden
    Write-Progress -Activity "Windows Store Cache" -Completed

    Write-Host "  ✅ Store Cache resetado" -ForegroundColor Green
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-LogFiles {
    Clear-Host
    Write-Host "`n  📋 Limpando Log Files..." -ForegroundColor Yellow
    Write-Host ""
    Remove-DirectoryContent -Path "$env:windir\Logs" -Description "Log Files"
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-MemoryDump {
    Clear-Host
    Write-Host "`n  💾 Limpando Memory Dump Files..." -ForegroundColor Yellow
    Write-Host ""
    Remove-DirectoryContent -Path "$env:windir\Minidump" -Description "Memory Dump Files"
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-DeliveryOptimization {
    Clear-Host
    Write-Host "`n  📦 Limpando Delivery Optimization..." -ForegroundColor Yellow
    Write-Host ""

    Write-Progress -Activity "Delivery Optimization" -Status "Parando servico..." -PercentComplete 30
    net stop dosvc | Out-Null

    Remove-DirectoryContent -Path "$env:windir\SoftwareDistribution\DeliveryOptimization" -Description "Delivery Optimization"

    Write-Progress -Activity "Delivery Optimization" -Status "Iniciando servico..." -PercentComplete 80
    net start dosvc | Out-Null
    Write-Progress -Activity "Delivery Optimization" -Completed

    Write-Host ""
    Read-Host "  Pressione ENTER"
}

function Clear-ShaderCache {
    Clear-Host
    Write-Host "`n  🎮 Limpando DirectX Shader Cache..." -ForegroundColor Yellow
    Write-Host ""
    Remove-DirectoryContent -Path "$env:LOCALAPPDATA\D3DSCache" -Description "Shader Cache"
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

# === OPCAO 5: Clean Temp ===
function Invoke-CleanTempAndOpen {
    Clear-Host
    Write-Host "`n  🗂️ Clean Temp" -ForegroundColor Yellow
    Write-Host ""

    Remove-DirectoryContent -Path "C:\Windows\Temp" -Description "Windows Temp"
    Remove-DirectoryContent -Path "$env:LOCALAPPDATA\Temp" -Description "User Temp"

    Write-Host ""
    Write-Host "  📂 Abrindo pastas..." -ForegroundColor Cyan
    Start-Process "explorer.exe" -ArgumentList "C:\Windows\Temp"
    Start-Process "explorer.exe" -ArgumentList "$env:LOCALAPPDATA\Temp"

    Write-Host ""
    Read-Host "  Pressione ENTER"
}

# === OPCAO 6: Limpeza Avancada do Sistema ===
function Invoke-CleanSystem {
    Clear-Host
    Write-Host ""
    Write-Host "  === INICIANDO LIMPEZA AVANCADA DO SISTEMA ===" -ForegroundColor Cyan
    Write-Host ""

    $paths = @(
        "C:\Windows\Prefetch",
        "C:\Windows\Spool\Printers",
        "C:\Windows\History",
        "C:\Windows\Cookies",
        "C:\Windows\Tmp"
    )

    $files = @(
        "C:\WIN386.SWP",
        "C:\Windows\ff*.tmp"
    )

    # === ETAPA 1 ===
    Write-Host "  [ETAPA 1/3] Limpando arquivos extras..." -ForegroundColor Yellow
    Write-Host ""

    $i = 0
    foreach ($item in $paths) {
        $i++
        $percent = [math]::Round(($i / $paths.Count) * 100)
        Write-Progress -Activity "Limpando diretorios extras" -Status $item -PercentComplete $percent

        if (Test-Path $item) {
            try {
                Remove-Item -Path "$item\*" -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host "  ✅ Limpo: $item" -ForegroundColor Green
            } catch {
                Write-Host "  ❌ Erro ao limpar: $item" -ForegroundColor Red
            }
        } else {
            Write-Host "  ⚠️ Diretorio nao encontrado: $item" -ForegroundColor DarkYellow
        }
        Start-Sleep -Milliseconds 100
    }

    foreach ($file in $files) {
        if (Test-Path $file) {
            try {
                Remove-Item $file -Force -ErrorAction SilentlyContinue
                Write-Host "  ✅ Arquivo removido: $file" -ForegroundColor Green
            } catch {
                Write-Host "  ❌ Erro ao remover: $file" -ForegroundColor Red
            }
        }
    }
    Write-Progress -Activity "Limpando diretorios extras" -Completed

    # === ETAPA 2 ===
    Write-Host ""
    Write-Host "  [ETAPA 2/3] Limpando TEMP..." -ForegroundColor Yellow
    Write-Host ""

    Remove-DirectoryContent -Path $env:TEMP -Description "User TEMP"
    Remove-DirectoryContent -Path "C:\Windows\Temp" -Description "Windows TEMP"

    # === ETAPA 3 ===
    Write-Host ""
    Write-Host "  [ETAPA 3/3] Limpando Logs de Eventos..." -ForegroundColor Yellow
    Write-Host ""

    $logs = wevtutil el
    $count = $logs.Count
    $i = 0

    foreach ($log in $logs) {
        $i++
        $percent = [math]::Round(($i / $count) * 100)
        Write-Progress -Activity "Limpando Logs de Eventos" -Status "$i de $count" -PercentComplete $percent
        try {
            wevtutil cl "$log" 2>$null
        } catch {}
    }
    Write-Progress -Activity "Limpando Logs de Eventos" -Completed

    Write-Host ""
    Write-Host "  === LIMPEZA CONCLUIDA COM SUCESSO ===" -ForegroundColor Cyan
    Write-Host ""
    Read-Host "  Pressione ENTER"
}

# === OPCAO 7: Device Cleanup ===
function Invoke-DeviceCleanup {
    Clear-Host
    Write-Host "`n  🔧 Abrindo Device Cleanup..." -ForegroundColor Yellow
    Write-Host ""

    $deviceCleanup = Join-Path $PSScriptRoot "Programs\DeviceCleanup.exe"

    if (Test-Path $deviceCleanup) {
        Write-Host "  ✅ Executando DeviceCleanup.exe..." -ForegroundColor Green
        Start-Process -FilePath $deviceCleanup
        Write-Host ""
        Read-Host "  Pressione ENTER para voltar ao menu"
    } else {
        Write-Host "  ❌ Erro: DeviceCleanup.exe nao encontrado em:" -ForegroundColor Red
        Write-Host "  $deviceCleanup" -ForegroundColor DarkYellow
        Write-Host ""
        Read-Host "  Pressione ENTER para voltar ao menu"
    }
}

# === LOOP PRINCIPAL ===
do {
    Show-Menu
    $choice = Read-Host "  Escolha"

    switch ($choice) {
        "1" { Invoke-DeleteUpdateCache }
        "2" { Invoke-DeleteTemporaryFiles }
        "3" { Invoke-DeleteLogFiles }
        "4" { Show-CleanCacheMenu }
        "5" { Invoke-CleanTempAndOpen }
        "6" { Invoke-CleanSystem }
        "7" { Invoke-DeviceCleanup }
        "0" { 
            Clear-Host
            Write-Host ""
            Write-Host "  👋 Ate logo!" -ForegroundColor Yellow
            Write-Host ""
            Start-Sleep -Seconds 1
            exit 
        }
        default { 
            Write-Host "  ❌ Opcao invalida" -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
} while ($true)
