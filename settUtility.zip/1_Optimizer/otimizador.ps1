﻿# ===== MENU PRINCIPAL =====
function Show-Menu {
    param (
        [string]$title,
        [string[]]$options,
        [scriptblock[]]$actions
    )

    do {
        Clear-Host
        Write-Host ("=" * 30)
        Write-Host ("         $title")
        Write-Host ("=" * 30)

        for ($i = 0; $i -lt $options.Count; $i++) {
            Write-Host "$($i + 1). $($options[$i])"
        }
        Write-Host ("=" * 30)

        $input = Read-Host "Escolha uma opção [1-$($options.Count)]"

        # Validação do input
        if ([int]::TryParse($input, [ref]$null)) {
            $index = [int]$input - 1
        } else {
            $index = -1
        }

        if ($index -ge 0 -and $index -lt $options.Count) {
            if ($options[$index] -match "Voltar") {
                return   # retorna para o menu anterior
            }
            elseif ($options[$index] -match "Sair") {
                exit     # fecha a janela inteira do PowerShell
            }
            else {
                # Executa a ação vinculada à opção escolhida
                & $actions[$index]
            }
        }

    } while ($true)
}




function Show-MainMenu {
    Show-Menu -title "OTIMIZADOR SETT" `
        -options @(
            "Otimizar Internet", 
            "Power Options", 
            "Game Mode", 
            "Memory Otimizations", 
            "Configurações Avançadas", 
            "Tweaks",
            "Nvidia Optimize",
            "AMD Optimize",
			"Integrations",
			"Privacy"
            "Clean",
            "Sair"
        ) `
        -actions @(
            { Show-OptimizeMenu },
            { Show-PowerOptionsMenu },
            { Show-GameModeMenu },
            { Show-MemoryOptimizationMenu },
            { Show-AdvancedSettingsMenu },
            { Show-SystemOptimizationMenu },
            { Show-NvidiaOptimizeMenu },
            { Show-AmdOptimizeMenu },
			{ Show-IntegrationsMenu },
			{ Show-PrivacyMenu},
            { Show-CleanMenu },
            { return }
        )
}

# ===== SUBMENU DE PROTECAO DE PRIVACIDADE =====
function Show-PrivacyMenu {
    Show-Menu -title "PRIVACIDADE" `
        -options @("Executar PRIVACIDADE", "Voltar ao Menu Anterior") `
        -actions @(
            { Invoke-ProtectPrivacy; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE INTEGRATIONS =====
function Show-IntegrationsMenu {
    Show-Menu -title "INTEGRATIONS" `
        -options @("Executar Integrations", "Voltar ao Menu Anterior") `
        -actions @(
            { Invoke-AppIntegrationKeys; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE CLEAN =====
function Show-CleanMenu {
    Show-Menu -title "CLEAN - LIMPEZA AVANÇADA" `
        -options @("Executar Limpeza", "Voltar ao Menu Anterior") `
        -actions @(
            { Invoke-CleanSystem; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE OTIMIZAÇÃO AMD =====
function Show-AmdOptimizeMenu {
    Show-Menu -title "AMD OPTIMIZE" `
        -options @("AMD Optimize 1", "Voltar ao Menu Anterior") `
        -actions @(
            { Invoke-AmdOptimize; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE OTIMIZAÇÃO NVIDIA =====
function Show-NvidiaOptimizeMenu {
    Show-Menu -title "NVIDIA OPTIMIZE" `
        -options @("Nvidia Optimize 1", "Nvidia Optimize 2", "Nvidia Optimize 3", "Voltar ao Menu Anterior") `
        -actions @(
            { Invoke-NvidiaOptimize1; Read-Host "Pressione Enter para voltar ao menu." },
            { Invoke-NvidiaOptimize2; Read-Host "Pressione Enter para voltar ao menu." },
			{ Invoke-NvidiaOptimize3; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE OTIMIZAÇÃO TWEAKS =====
function Show-SystemOptimizationMenu {
    Show-Menu -title "OTIMIZAÇÃO TWEAKS" `
        -options @("Aplicar Otimizacao de Tweaks", "Voltar ao Menu Anterior") `
        -actions @(
            { Optimize-SystemFunction; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE CONFIGURAÇÕES AVANÇADAS =====
function Show-AdvancedSettingsMenu {
    Show-Menu -title "CONFIGURAÇÕES AVANÇADAS" `
        -options @("Desativar Serviços", "Otimizar Processador", "Voltar ao Menu Principal") `
        -actions @(
            { Disable-ServicesFunction; Read-Host "Pressione Enter para voltar ao menu." },
            { Show-ProcessorOptimizationMenu },
            { return }
        )
}

# ===== SUBMENU DE OTIMIZAÇÃO PROCESSADOR =====
function Show-ProcessorOptimizationMenu {
    Show-Menu -title "OTIMIZAÇÃO DE PROCESSADOR" `
        -options @("Aplicar Otimizações", "Voltar ao Menu Anterior") `
        -actions @(
            { Optimize-ProcessorFunction; Read-Host "Pressione Enter para voltar ao menu." },
            { return }
        )
}

# ===== SUBMENU DE OTIMIZAÇÃO RAM =====
function Show-MemoryOptimizationMenu {
    Show-Menu -title "Memory Optimizations" `
        -options @("Aplicar Memory Optimizations", "Voltar ao Menu Principal") `
        -actions @(
            { Apply-MemoryOptimizations },
            { return }
        )
}

# ===== SUBMENU DE OTIMIZAÇÃO INTERNET =====
function Show-OptimizeMenu {
    Show-Menu -title "OTIMIZAR INTERNET" `
        -options @(
            "Aplicar Otimização",
            "Restaurar para o Padrão",
            "Ver Instruções de Ajustes Manuais",
            "Voltar ao Menu Principal"
        ) `
        -actions @(
            { Apply-InternetOptimization },
            { Restore-Default },
            { Show-ManualNetworkTweaks },
            { return }
        )
}

# ===== SUBMENU POWER OPTIONS =====
function Show-PowerOptionsMenu {
    Show-Menu -title "POWER OPTIONS" `
        -options @("Aplicar power option", "Voltar ao Menu Principal") `
        -actions @(
            { Apply-PowerOptions },
            { return }
        )
}

# ===== SUBMENU GAME MODE =====
function Show-GameModeMenu {
    Show-Menu -title "GAME MODE" `
        -options @(
            "Windows 10",
            "Windows 11",
            "Optimizacoes",
            "Voltar ao Menu Principal"
        ) `
        -actions @(
            { Configure-GameMode -os "Windows10" },
            { Configure-GameMode -os "Windows11" },
            { Apply-ExtraGameOptimizations },
            { return }
        )
}

# ===== APLICAR OTIMIZAÇÃO INTERNET =====
function Apply-InternetOptimization {
    Clear-Host
    Write-Host "Aplicando otimizações automáticas de Internet..."

    try {
        # --------------------------
        # 🔹 Otimizações TCP/AFD
        # --------------------------
        netsh int tcp set global autotuning=disabled

        $regSettings = @(
            # FastSendDatagramThreshold
            @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters"; Name = "FastSendDatagramThreshold"; Type = "DWORD"; Value = 64000 },

            # QoS Valorant
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Version"; Type = "String"; Value = "1.0" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Application Name"; Type = "String"; Value = "VALORANT.exe" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Protocol"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Local Port"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Local IP"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Local IP Prefix Length"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Remote Port"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Remote IP"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Remote IP Prefix Length"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "DSCP Value"; Type = "DWORD"; Value = 46 },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\ValorantPolicy"; Name = "Throttle Rate"; Type = "DWORD"; Value = -1 },

            # QoS CSGO
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Version"; Type = "String"; Value = "1.0" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Application Name"; Type = "String"; Value = "csgo.exe" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Protocol"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Local Port"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Local IP"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Local IP Prefix Length"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Remote Port"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Remote IP"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Remote IP Prefix Length"; Type = "String"; Value = "*" },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "DSCP Value"; Type = "DWORD"; Value = 46 },
            @{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\CSGOPolicy"; Name = "Throttle Rate"; Type = "DWORD"; Value = -1 }
        )

        foreach ($setting in $regSettings) {
            if (-not (Test-Path $setting.Path)) {
                New-Item -Path $setting.Path -Force | Out-Null
            }
            New-ItemProperty -Path $setting.Path -Name $setting.Name -PropertyType $setting.Type -Value $setting.Value -Force | Out-Null
        }

        Write-Host "`n✅ Otimizações + QoS aplicados com sucesso!"
    }
    catch {
        Write-Host "`n❌ Erro ao aplicar otimizações: $_"
    }

    Read-Host "Pressione Enter para voltar ao menu."
}


# ==== Manual Network Tweaks ====
function Show-ManualNetworkTweaks {
    Clear-Host
    Write-Host "ℹ️ Algumas otimizações devem ser feitas manualmente:"
    Write-Host ""
    Write-Host "1. Vá em: Painel de Controle > Rede e Internet > Central de Rede"
    Write-Host "   > Alterar configurações do adaptador"
    Write-Host "2. Clique com o botão direito na conexão Ethernet > Propriedades"
    Write-Host "   ❌ Desmarque todos os protocolos, exceto:"
    Write-Host "   ✅ QoS Packet Scheduler"
    Write-Host "   ✅ Internet Protocol Version 4 (TCP/IPv4)"
    Write-Host ""
    Write-Host "3. Vá em: Gerenciador de Dispositivos > Adaptadores de Rede"
    Write-Host "   > Realtek PCIe GbE Family Controller > Propriedades > Aba 'Avançado'"
    Write-Host ""
    Write-Host "⚙️ Configure os seguintes itens:"
    Write-Host "- Flow Control: Disabled"
    Write-Host "- Idle Power Down Restriction: Disabled"
    Write-Host "- Interrupt Moderation Rate: Off"
    Write-Host "- IPv4 Checksum Offload: Disabled"
    Write-Host "- Large Send Offload v2 (IPv4/IPv6): Disabled"
    Write-Host "- NS Offload: Disabled"
    Write-Host "- TCP/UDP Checksum Offload (IPv4/IPv6): Disabled"
    Write-Host "- Wake on Magic Packet: Disabled"
    Write-Host "- Interrupt Moderation: Disabled"
    Write-Host "- Speed & Duplex: Auto Negotiation"
    Write-Host ""
    Write-Host "4. Na aba Power Management:"
    Write-Host "   ❌ Desmarque todas as opções (Wake, Save Power, etc.)"
    Write-Host ""
    Read-Host "Pressione Enter para retornar ao menu."
}

# ===== RESTAURAR PADRÃO =====
function Restore-Default {
    Clear-Host
    Write-Host "Restaurando configurações de Internet para o padrão..."

    try {
        netsh int tcp set global autotuning=normal

        # Remove FastSendDatagramThreshold
        $afdParamsKey = "HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters"
        if (Test-Path "$afdParamsKey\FastSendDatagramThreshold") {
            Remove-ItemProperty -Path $afdParamsKey -Name "FastSendDatagramThreshold" -Force
        }

        Write-Host "`n✅ Configuração restaurada com sucesso!"
    } catch {
        Write-Host "`n❌ Erro ao restaurar configuração: $_"
    }

    Read-Host "Pressione Enter para continuar."
}

# ===== APLICAR POWER OPTIONS =====
function Apply-PowerOptions {
    Clear-Host
    Write-Host "Aplicando plano de energia 'Khorvie' via arquivo .pow..."

    # Caminho dinâmico: mesmo diretório do script
    $powFile = Join-Path $PSScriptRoot "Khorvie.pow"

    if (-not (Test-Path $powFile)) {
        Write-Host "❌ Arquivo 'Khorvie.pow' não encontrado na pasta do script."
        Read-Host "Pressione Enter para voltar ao menu."
        return
    }

    # Importa o plano .pow e captura o GUID
    $importResult = powercfg -import $powFile 2>&1
    $guidMatch = $importResult | Select-String -Pattern 'GUID: ([\w-]+)'

    if ($guidMatch) {
        $guid = $guidMatch.Matches[0].Groups[1].Value
        powercfg -setactive $guid
        Write-Host "✅ Plano 'Khorvie' ativado com sucesso."
    } else {
        Write-Host "⚠️ Não foi possível localizar o GUID do plano importado."
    }

    Write-Host "`nConfigurações aplicadas com sucesso! Pressione Enter para retornar ao menu."
    Read-Host
}


# ===== CONFIGURAR GAME MODE BASEADO NO SISTEMA =====
function Configure-GameMode {
    param (
        [string]$os
    )

    Clear-Host
    Write-Host "Configurando Game Mode para $os..."
    
    if ($os -eq "Windows10") {
        # Ativar Game Mode
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AllowAutoGameMode" -Value 1 -Force
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Value 1 -Force
    }
    elseif ($os -eq "Windows11") {
        # Desativar Game Mode
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AllowAutoGameMode" -Value 0 -Force
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Value 0 -Force
    }

    # Desativar Game Bar
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "ShowStartupPanel" -Value 0 -Force
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "GamePanelStartupTipIndex" -Value 3 -Force
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "UseNexusForGameBarEnabled" -Value 0 -Force
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" -Name "AppCaptureEnabled" -Value 0 -Force

    Write-Host "`n✅ Configurações de Game Mode aplicadas para $os."
    Read-Host "Pressione Enter para voltar ao menu."
}

function Apply-ExtraGameOptimizations {
    Clear-Host
    Write-Host "Aplicando otimizações adicionais..."

    try {
        # Win32PrioritySeparation: mais prioridade a apps em primeiro plano
        $priorityKey = "HKLM:\SYSTEM\ControlSet001\Control\PriorityControl"
        New-ItemProperty -Path $priorityKey -Name "Win32PrioritySeparation" -PropertyType DWord -Value 38 -Force | Out-Null

        # Disable Game DVR
        $gvrKey = "HKCU:\System\GameConfigStore"
        Set-ItemProperty -Path $gvrKey -Name "GameDVR_Enabled" -Value 0 -Force
        Set-ItemProperty -Path $gvrKey -Name "GameDVR_FSEBehavior" -Value 2 -Force
        Set-ItemProperty -Path $gvrKey -Name "GameDVR_FSEBehaviorMode" -Value 2 -Force
        Set-ItemProperty -Path $gvrKey -Name "GameDVR_HonorUserFSEBehaviorMode" -Value 0 -Force

        # Disable Background Apps (política de privacidade)
        $privacyKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy"
        if (-not (Test-Path $privacyKey)) {
            New-Item -Path $privacyKey -Force | Out-Null
        }
        New-ItemProperty -Path $privacyKey -Name "LetAppsRunInBackground" -PropertyType DWord -Value 2 -Force | Out-Null

        Write-Host "`n✅ Otimizações aplicadas com sucesso!"
    } catch {
        Write-Host "`n❌ Erro ao aplicar otimizações: $_"
    }

    Read-Host "Pressione Enter para voltar ao menu."
}

function Apply-MemoryOptimizations {
    Clear-Host
    Write-Host "🔧 Aplicando otimizações de memória..."

    try {
        # 🧠 Ajustes no gerenciamento de memória
        $regCommands = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "ClearPageFileAtShutdown" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "LargeSystemCache" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "NonPagedPoolQuota" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "NonPagedPoolSize" /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "PhysicalAddressExtension" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "EnergyDriverPolicyVideo" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "TimerBResolution" /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "TimerMinResolution" /t REG_DWORD /d 1 /f'
        )

        foreach ($cmd in $regCommands) {
            Invoke-Expression $cmd
        }

        # 🚫 Desativar compactação de memória
        powershell "Disable-MMAgent -MemoryCompression" | Out-Null

        Write-Host "✅ Otimizações de memória aplicadas com sucesso."
    } catch {
        Write-Host "❌ Erro ao aplicar otimizações de memória: $_"
    }

    # 💡 Otimização do SvcHost com base na RAM
    try {
        Write-Host "`n📏 Detectando quantidade de RAM para aplicar otimização do SvcHost..."

        $totalRamBytes = (Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory
        $totalRamGB = [math]::Round($totalRamBytes / 1GB)

        switch ($totalRamGB) {
            {$_ -le 4}  { $value = 4 * 1024 * 1024; $label = "4GB"; break }
            {$_ -le 8}  { $value = 8 * 1024 * 1024; $label = "8GB"; break }
            {$_ -le 12} { $value = 12 * 1024 * 1024; $label = "12GB"; break }
            {$_ -le 16} { $value = 16 * 1024 * 1024; $label = "16GB"; break }
            {$_ -le 24} { $value = 24 * 1024 * 1024; $label = "24GB"; break }
            {$_ -le 32} { $value = 32 * 1024 * 1024; $label = "32GB"; break }
            {$_ -le 48} { $value = 48 * 1024 * 1024; $label = "48GB"; break }
            {$_ -le 64} { $value = 64 * 1024 * 1024; $label = "64GB"; break }
            default     { $value = 128 * 1024 * 1024; $label = "128GB ou mais"; break }
        }

        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control" -Name "SvcHostSplitThresholdInKB" -Value $value -Type DWord -Force
        Write-Host "✅ SvcHost configurado com base em $label de RAM."

    } catch {
        Write-Host "❌ Falha ao configurar SvcHostSplitThresholdInKB: $_"
    }

    Read-Host "`nPressione Enter para voltar ao menu."
}


function Disable-ServicesFunction {
    $serviceSettings = @(
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\TapiSrv"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\FontCache3.0.0.0"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\WpcMonSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\SEMgrSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\PNRPsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\WEPHOSTSVC"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\p2psvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\p2pimsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\PhoneSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\Wecsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\SensorDataService"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\SensrSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\perceptionsimulation"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\StiSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\OneSyncSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\DevicePickerUserSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\UnistoreSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\DevicesFlowUserSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\WMPNetworkSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\icssvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\DusmSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\MapsBroker"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\edgeupdate"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\SensorService"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\shpamsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\svsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\MSiSCSI"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\CscService"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\ssh-agent"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\tzautoupdate"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\NfsClnt"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\wisvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\defragsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\autotimesvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\MessagingService"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\CDPUserSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\PimIndexMaintenanceSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\BcastDVRUserService"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\UserDataSvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\DeviceAssociationBrokerSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\cbdhsvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\edgeupdatem"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\MicrosoftEdgeElevationService"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\ALG"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\QWAVE"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\IpxlatCfgSvc"; Name = "Start"; Type = "DWORD"; Value = 3 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\SharedRealitySvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\RetailDemo"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\lltdsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\TrkWks"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\Fax"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\SCardSvr"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc"; Name = "Start"; Type = "DWORD"; Value = 4 },
        @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration"; Name = "Status"; Type = "DWORD"; Value = 0 }
    )

    Write-Host "⚙️ Aplicando configurações de serviços..." -ForegroundColor Cyan

    $total = $serviceSettings.Count
    $counter = 0

    foreach ($setting in $serviceSettings) {
        $counter++
        Write-Progress -Activity "Desativando serviços..." `
                       -Status "$counter de $total serviços" `
                       -PercentComplete (($counter / $total) * 100)

        try {
            if (-not (Test-Path $setting.Path)) {
                New-Item -Path $setting.Path -Force | Out-Null
            }

            Set-ItemProperty -Path $setting.Path -Name $setting.Name -Value $setting.Value -Type $setting.Type
        } catch {
            Write-Warning "⚠️ Erro ao configurar $($setting.Path)\$($setting.Name)"
        }
    }

    Write-Progress -Activity "Desativando serviços..." -Completed
    Write-Host "`n✅ $total serviços configurados com sucesso." -ForegroundColor Green
}


function Disable-Telemetry {
    $regSettings = @(
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata"; Name = "PreventDeviceMetadataFromNetwork"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"; Name = "AllowTelemetry"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKCU:\SOFTWARE\Microsoft\InputPersonalization"; Name = "RestrictImplicitInkCollection"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKCU:\SOFTWARE\Microsoft\InputPersonalization"; Name = "RestrictImplicitTextCollection"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}"; Name = "SensorPermissionState"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}"; Name = "SensorPermissionState"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF"; Name = "LogEnable"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF"; Name = "LogLevel"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "AllowTelemetry"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "DoNotShowFeedbackNotifications"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "AllowCommercialDataPipeline"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "AllowDeviceNameInTelemetry"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "LimitEnhancedDiagnosticDataWindowsAnalytics"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "MicrosoftEdgeDataOptIn"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKCU:\SOFTWARE\Microsoft\Siuf\Rules"; Name = "NumberOfSIUFInPeriod"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKCU:\SOFTWARE\Microsoft\Siuf\Rules"; Name = "PeriodInNanoSeconds"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKCU:\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0"; Name = "NoExplicitFeedback"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0"; Name = "NoActiveHelp"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat"; Name = "DisableInventory"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat"; Name = "AITEnable"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat"; Name = "DisableUAR"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\TabletPC"; Name = "PreventHandwritingDataSharing"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\TabletPC"; Name = "DoSvc"; Type = "DWORD"; Value = 3 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableLocation"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableLocationScripting"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableSensors"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableWindowsLocationProvider"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "PublishUserActivities"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "EnableActivityFeed"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "UploadUserActivities"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows"; Name = "CEIPEnable"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\SQMClient\Reliability"; Name = "CEIPEnable"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\SQMClient\Reliability"; Name = "SqmLoggerRunning"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\SQMClient\Windows"; Name = "CEIPEnable"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\SQMClient\Windows"; Name = "DisableOptinExperience"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\SQMClient\Windows"; Name = "SqmLoggerRunning"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\SQMClient\IE"; Name = "SqmLoggerRunning"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports"; Name = "PreventHandwritingErrorReports"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKCU:\SOFTWARE\Microsoft\MediaPlayer\Preferences"; Name = "UsageTracking"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent"; Name = "DisableSoftLanding"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Peernet"; Name = "Disabled"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config"; Name = "DODownloadMode"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting"; Name = "value"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo"; Name = "Enabled"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo"; Name = "DisabledByGroupPolicy"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\MRT"; Name = "DontOfferThroughWUAU"; Type = "DWORD"; Value = 1 },
		@{ Path = "HKLM:\SOFTWARE\Policies\Microsoft\Biometrics"; Name = "Enabled"; Type = "DWORD"; Value = 0 },
		@{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\dmwappushservice"; Name = "Start"; Type = "DWORD"; Value = 4 },
		@{ Path = "HKCU:\Control Panel\International\User Profile"; Name = "HttpAcceptLanguageOptOut"; Type = "DWORD"; Value = 1 }
	)

    $tasksToDisable = @(
        "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
        "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM",
        "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
        "\Microsoft\Windows\Customer Experience Improvement Program\DmClient",
        "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
        "\Microsoft\Windows\Application Experience\ProgramDataUpdater",
        "\Microsoft\Windows\Autochk\Proxy",
        "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask",
        "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector",
        "\Microsoft\Windows\Maintenance\WinSAT"
    )

    Write-Host "🔧 Aplicando configurações de registro para desativar telemetria..." -ForegroundColor Cyan
    $counter = 0
    $total = $regSettings.Count

    foreach ($setting in $regSettings) {
        $counter++
        Write-Progress -Activity "Aplicando ajustes de telemetria..." `
                       -Status "$counter de $total chaves de registro" `
                       -PercentComplete (($counter / $total) * 100)

        try {
            if (-not (Test-Path $setting.Path)) {
                New-Item -Path $setting.Path -Force | Out-Null
            }
            Set-ItemProperty -Path $setting.Path -Name $setting.Name -Value $setting.Value -Type $setting.Type
        } catch {
            Write-Warning "Falha ao configurar $($setting.Path)\$($setting.Name)"
        }
    }

    Write-Progress -Activity "Configurações de registro aplicadas" -Completed
    Write-Host "✅ $total chaves de registro ajustadas." -ForegroundColor Green


    Write-Host "`n⏸ Desabilitando tarefas agendadas relacionadas à telemetria..." -ForegroundColor Cyan
    $taskCounter = 0
    $taskTotal = $tasksToDisable.Count

    foreach ($task in $tasksToDisable) {
        $taskCounter++
        Write-Progress -Activity "Desabilitando tarefas de telemetria..." `
                       -Status "$taskCounter de $taskTotal tarefas" `
                       -PercentComplete (($taskCounter / $taskTotal) * 100)

        try {
            Disable-ScheduledTask -TaskPath (Split-Path $task) -TaskName (Split-Path $task -Leaf) -ErrorAction Stop | Out-Null
        } catch {
            Write-Warning "Não foi possível desabilitar: $task"
        }
    }

    Write-Progress -Activity "Tarefas agendadas processadas" -Completed
    Write-Host "✅ $taskTotal tarefas de telemetria desativadas." -ForegroundColor Green

    Write-Host "`n🎉 Concluído! Telemetria desativada (na medida do possível)." -ForegroundColor Magenta
}



function Optimize-SystemFunction {
    Write-Host "Aplicando otimizações de sistema..." -ForegroundColor Cyan

    # === REG DELETEs ===
    Write-Host "Removendo tarefas agendadas do Microsoft Edge..." -ForegroundColor Cyan
    $edgeTasks = @(
        "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\MicrosoftEdgeUpdateTaskMachineCore",
        "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\MicrosoftEdgeUpdateTaskMachineUA"
    )

    $count = 0
    foreach ($task in $edgeTasks) {
        $count++
        Write-Progress -Activity "Removendo Edge Tasks" -Status "$count de $($edgeTasks.Count)" -PercentComplete (($count / $edgeTasks.Count) * 100)
        try {
            reg.exe delete $task /f | Out-Null
        } catch {
            Write-Warning "Erro ao deletar $task"
        }
    }
    Write-Progress -Activity "Removendo Edge Tasks" -Completed
    Write-Host "✓ Tarefas do Edge removidas." -ForegroundColor Green


    # === REG ADDs (Otimizações de privacidade e serviços) ===
    Write-Host "Aplicando configurações de registro..." -ForegroundColor Cyan
    $registryEdits = @(
		@{ Path = "HKCU\CONSOLE"; Name = "VirtualTerminalLevel"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\MicrosoftEdgeElevationService"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\edgeupdate"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\edgeupdatem"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"; Name = "VisualFXSetting"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKCU\Control"; Name = "MinAnimate"; Type = "REG_SZ"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "TaskbarAnimations"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\DWM"; Name = "AlwaysHibernateThumbnails"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack"; Name = "ShowedToastAtLevel"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy"; Name = "TailoredExperiencesWithDiagnosticDataEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "MaintenanceDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\System"; Name = "EnableActivityFeed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\AdvertisingInfo"; Name = "DisabledByGroupPolicy"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "NoLazyMode"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "AlwaysOn"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Control"; Name = "FontSmoothing"; Type = "REG_SZ"; Value = 2 },
		@{ Path = "HKCU\Control"; Name = "FontSmoothingType"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "HideSCAHealth"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\AppHost"; Name = "ContentEvaluation"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\AppHost"; Name = "EnableWebContentEvaluation"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting"; Name = "value"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\ImmersiveShell"; Name = "UseActionCenterExperience"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\EnhancedStorageDevices"; Name = "TCGSecurityActivationDisabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Search"; Name = "BingSearchEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Search"; Name = "CortanaCapabilities"; Type = "REG_SZ"; Value = "" },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Search"; Name = "IsAssignedAccess"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Search"; Name = "IsWindowsHelloActive"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "ConnectedSearchPrivacy"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "ConnectedSearchSafeSearch"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\Software\Microsoft\PolicyManager\default\Experience\AllowCortana"; Name = "value"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\SearchCompanion"; Name = "DisableContentFileUpdates"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "AllowCloudSearch"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "AllowCortanaAboveLock"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "AllowSearchToUseLocation"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "ConnectedSearchPrivacy"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "ConnectedSearchUseWeb"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "ConnectedSearchUseWebOverMeteredConnections"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "DisableWebSearch"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "DoNotUseWebResults"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\System"; Name = "AllowExperimentation"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\PolicyManager\default\System\AllowExperimentation"; Name = "value"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "EnablingFeeds"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "EnablingActivityFeed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "DoReport"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "LoggingDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\PCHealth\ErrorReporting"; Name = "DoReport"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\Windows"; Name = "Disabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CDP"; Name = "CdpSessionUserAuthzPolicy"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CDP"; Name = "NearShareChannelUserAuthzPolicy"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\CaptureService"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\InputPersonalization"; Name = "RestrictImplicitInkCollection"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\InputPersonalization"; Name = "RestrictImplicitTextCollection"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore"; Name = "HarvestContacts"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC"; Name = "DoSvc"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKCU\Control"; Name = "HttpAcceptLanguageOptOut"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableLocation"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableLocationScripting"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableSensors"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"; Name = "DisableWindowsLocationProvider"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\FontCache"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\InstallService"; Name = "Start"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\OSRSS"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\sedsvc"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SENS"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\TabletInputService"; Name = "Start"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Themes"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\GoogleChromeElevationService"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\gupdate"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\gupdatem"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Device"; Name = "PreventDeviceMetadataFromNetwork"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\MRT"; Name = "DontOfferThroughWUAU"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\diagsvc"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\DPS"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\diagnosticshub.standardcollector.service"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WdiServiceHost"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WdiSystemHost"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableSettingSync"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableDesktopThemeSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisablePersonalizationSettingSync"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisablePersonalizationSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableStartLayoutSettingSync"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableStartLayoutSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableSyncOnPaidNetwork"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableWebBrowserSettingSync"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableWebBrowserSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableWindowsSettingSync"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableWindowsSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 2 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize"; Name = "EnablingTransparency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Privacy"; Name = "TailoredExperiencesWithDiagnosticDataEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack"; Name = "ShowedToastAtLevel"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_CURRENT_USER\Software\Microsoft\Input\TIPC"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\System"; Name = "UploadUserActivities"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\System"; Name = "PublishUserActivities"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments"; Name = "SaveZoneInformation"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\WDI\{9c5a40da-b965-4fc3-8781-88dd50a6299d}"; Name = "ScenarioExecutionEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "GPU"; Type = "REG_DWORD"; Value = 8 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Background"; Type = "REG_SZ"; Value = "False" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "BackgroundPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "EnablingSmartScreen"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Biometrics"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\WbioSrvc"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Priority"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Scheduling"; Type = "REG_SZ"; Value = "High" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "SFIO"; Type = "REG_SZ"; Value = "High" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Latency"; Type = "REG_SZ"; Value = "True" },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"; Name = "PriorityControl"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"; Name = "DisableOverlappedExecution"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"; Name = "TimeIncrement"; Type = "REG_DWORD"; Value = 15 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"; Name = "QuantumLength"; Type = "REG_DWORD"; Value = 20 },    
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel"; Name = "ThreadDpcEnable"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl"; Name = "Win32PrioritySeparation"; Type = "REG_DWORD"; Value = 38 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability"; Name = "TimeStampInterval"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Reliability"; Name = "IoPriority"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "ExitLatency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "ExitLatencyCheckEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "Latency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "LatencyToleranceDefault"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "LatencyToleranceFSVP"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "LatencyTolerancePerfOverride"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "LatencyToleranceScreenOffIR"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableAppSyncSettingSync"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableAppSyncSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableApplicationSettingSync"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableApplicationSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableCredentialsSettingSync"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableCredentialsSettingSyncUserOverride"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync"; Name = "DisableDesktopThemeSettingSync"; Type = "Reg_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "LatencyToleranceVSyncEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "RtlCapabilityCheckLatency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultD3TransitionLatencyActivelyUsed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultD3TransitionLatencyIdleLongTime"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultD3TransitionLatencyIdleMonitorOff"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultD3TransitionLatencyIdleNoContext"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultD3TransitionLatencyIdleShortTime"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultD3TransitionLatencyIdleVeryLongTime"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceIdle0"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceIdle0MonitorOff"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceIdle1"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceIdle1MonitorOff"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceMemory"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceNoContext"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceNoContextMonitorOff"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceOther"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultLatencyToleranceTimerPeriod"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultMemoryRefreshLatencyToleranceActivelyUsed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultMemoryRefreshLatencyToleranceMonitorOff"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "DefaultMemoryRefreshLatencyToleranceNoContext"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "Latency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "MaxIAverageGraphicsLatencyInOneBucket"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "MiracastPerfTrackGraphicsLatency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "MonitorLatencyTolerance"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "MonitorRefreshLatencyTolerance"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Power"; Name = "TransitionLatency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AppModel"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Circular"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DataMarket"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\HolographicDevice"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\iclsClient"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\iclsProxy"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\LwtNetLog"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Mellanox-Kernel"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-AssignedAccess-Trace"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-Setup"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\NBSMBLOGGER"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\PEAuthLog"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\RdrLog"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\ReadyBoot"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatform"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SocketHeciServer"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SpoolerLogger"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SQMLogger"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TileStore"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Tpm"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TPMProvisioningService"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\UBPM"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WdiContextLog"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WFP-IPsec"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiDriverIHVSession"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiDriverIHVSessionRepro"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiSession"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WinPhoneCritical"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "LogEnabling"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent"; Name = "DisableThirdPartySuggestions"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Credssp"; Name = "DebugLogLevel"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common\Feedback"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common"; Name = "qmEnable"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Firstrun"; Name = "Disablemovie"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "contigfileallocsize"; Type = "reg_dword"; Value = 1536 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "disabledeletenotification"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "filenamecache"; Type = "reg_dword"; Value = 1024 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "longpathsenabled"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsallowextendedcharacter8dot3rename"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsbugcheckoncorrupt"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsdisable8dot3namecreation"; Type = "reg_dword"; Value = 1 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsdisablecompression"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsdisableencryption"; Type = "reg_dword"; Value = 1 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsencryptpagingfile"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "ntfsmftzonereservation"; Type = "reg_dword"; Value = 3 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "pathcache"; Type = "reg_dword"; Value = 128 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "refsdisablelastaccessupdate"; Type = "reg_dword"; Value = 1 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "udfssoftwaredefectmanagement"; Type = "reg_dword"; Value = 0 },
		@{ Path = "hklm\system\currentcontrolset\control\filesystem"; Name = "win31filesystem"; Type = "reg_dword"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "AllowCortana"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "DisableWebSearch"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync"; Name = "SyncPolicy"; Type = "REG_DWORD"; Value = 5 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Personalization"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\BrowserSettings"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Credentials"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Accessibility"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Windows"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize"; Name = "EnableTransparency"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"; Name = "HwSchMode"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\DirectX\UserGpuPreferences"; Name = "DirectXUserGlobalSettings"; Type = "REG_SZ"; Value = "VRROptimizeEnable=0;" },
		@{ Path = "HKEY_CURRENT_USER\Control"; Name = "Flags"; Type = "REG_SZ"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\Control"; Name = "HttpAcceptLanguageOptOut"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "Start_TrackProgs"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-338393Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-353694Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-353696Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy"; Name = "HasAccepted"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Personalization\Settings"; Name = "AcceptedPrivacyPolicy"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\InputPersonalization"; Name = "RestrictImplicitInkCollection"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize"; Name = "StartupDelayInMSec"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\safer\codeidentifiers"; Name = "authenticodeenabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Windows"; Name = "DontSendAdditionalData"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Windows"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\InputPersonalization"; Name = "RestrictImplicitTextCollection"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore"; Name = "HarvestContacts"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack"; Name = "ShowedToastAtLevel"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy"; Name = "TailoredExperiencesWithDiagnosticDataEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\EventTranscriptKey"; Name = "EnableEventTranscript"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "UploadUserActivities"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Search"; Name = "BackgroundAppGlobalToggle"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "CacheHashTableBucketSize"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "CacheHashTableSize"; Type = "REG_DWORD"; Value = 180 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "MaxCacheEntryTtlLimit"; Type = "REG_DWORD"; Value = "0000FA00" },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "MaxSOACacheEntryTtlLimit"; Type = "REG_DWORD"; Value = "0000012D" },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "NegativeCacheTime"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "NetFailureCacheTime"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"; Name = "NegativeSOACacheTime"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\MSMQ\Parameters\Security"; Name = "SecureDSCommunication"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\System"; Name = "HiberbootEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched"; Name = "MaxOutstandingSends"; Type = "REG_DWORD"; Value = 1073741824 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched"; Name = "NonBestEffortLimit"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched"; Name = "TimerResolution"; Type = "REG_DWORD"; Value = 4294967295 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingConforming"; Name = "ServiceTypeBestEffort"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingConforming"; Name = "ServiceTypeControlledLoad"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingConforming"; Name = "ServiceTypeGuaranteed"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingConforming"; Name = "ServiceTypeNetworkControl"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingConforming"; Name = "ServiceTypeQualitative"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingNonConforming"; Name = "ServiceTypeBestEffort"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingNonConforming"; Name = "ServiceTypeControlledLoad"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingNonConforming"; Name = "ServiceTypeGuaranteed"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingNonConforming"; Name = "ServiceTypeNetworkControl"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\DiffservByteMappingNonConforming"; Name = "ServiceTypeQualitative"; Type = "REG_DWORD"; Value = 99 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\UserPriorityMapping"; Name = "ServiceTypeNonConforming"; Type = "REG_DWORD"; Value = 7 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\UserPriorityMapping"; Name = "ServiceTypeBestEffort"; Type = "REG_DWORD"; Value = 7 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\UserPriorityMapping"; Name = "ServiceTypeControlledLoad"; Type = "REG_DWORD"; Value = 7 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\UserPriorityMapping"; Name = "ServiceTypeGuaranteed"; Type = "REG_DWORD"; Value = 7 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\UserPriorityMapping"; Name = "ServiceTypeNetworkControl"; Type = "REG_DWORD"; Value = 7 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Psched\UserPriorityMapping"; Name = "ServiceTypeQualitative"; Type = "REG_DWORD"; Value = 7 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\BITS"; Name = "EnableBITSMaxBandwidth"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\NetCache"; Name = "PeerCachingLatencyThreshold"; Type = "REG_DWORD"; Value = 268435456 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\PeerDist\Service"; Name = "Enable"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\Network"; Name = "NC_AllowNetBridge_NLA"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Processor"; Name = "AllowPepPerfStates"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Processor"; Name = "Cstates"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Processor"; Name = "Capabilities"; Type = "REG_DWORD"; Value = 516198 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "HighPerformance"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "HighestPerformance"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "MinimumThrottlePercent"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "MaximumThrottlePercent"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "MaximumPerformancePercent"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "Class1InitialUnparkCount"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "InitialUnparkCount"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "EventProcessorEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power"; Name = "CStates"; Type = "REG_DWORD"; Value = 0 }
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WcmSvc\GroupPolicy"; Name = "fDisablePowerManagement"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\PDC\Activators\Default\VetoPolicy"; Name = "EA:EnergySaverEngaged"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\PDC\Activators\28\VetoPolicy"; Name = "EA:PowerStateDischarging"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Misc"; Name = "DeviceIdlePolicy"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "PerfEnergyPreference"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPMinCores"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPMaxCores"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPMinCores1"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPMaxCores1"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CpLatencyHintUnpark1"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPDistribution"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CpLatencyHintUnpark"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "MaxPerformance1"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "MaxPerformance"; Type = "REG_DWORD"; Value = 100 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPDistribution1"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPHEADROOM"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Control"; Name = "Policies"; Type = "REG_BINARY"; Value = "01000000020000000100000000000000020000000000000000000000000000002c0100003232030304000000040000000000000000000000840300002c01000000000000840300000001646464640000" },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling"; Name = "PowerThrottlingOff"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Power\Policy\Settings\Processor"; Name = "CPCONCURRENCY"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\Common\ClientTelemetry"; Name = "DisableTelemetry"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common"; Name = "sendcustomerdata"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common\Feedback"; Name = "includescreenshot"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\Mail"; Name = "EnableLogging"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Word\Options"; Name = "EnableLogging"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\Common\ClientTelemetry"; Name = "SendTelemetry"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common"; Name = "updatereliabilitydata"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common\General"; Name = "shownfirstrunoptin"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common\General"; Name = "skydrivesigninoption"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\Common\ptwatson"; Name = "ptwoptin"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM"; Name = "Enablelogging"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM"; Name = "EnableUpload"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM"; Name = "EnableFileObfuscation"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "accesssolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "olksolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "onenotesolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "pptsolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "projectsolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "publishersolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "visiosolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "wdsolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedapplications"; Name = "xlsolution"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes"; Name = "agave"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes"; Name = "appaddins"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes"; Name = "comaddins"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes"; Name = "documentfiles"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes"; Name = "templatefiles"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContentEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-280815Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-202914Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Spooler"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\PrintNotify"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\MapsBroker"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters"; Name = "PriorityBoost"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\System\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\System\CurrentControlSet\Control\WMI\Autologger\Diagtrack-Listener"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\SQMClient\IE"; Name = "CEIPEnable"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\AppV\CEIP"; Name = "CEIPEnable"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Messenger\Client"; Name = "CEIP"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\SQMClient\Windows"; Name = "CEIPEnable"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Internet"; Name = "DisableCustomerImprovementProgram"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Accessibility"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\AppSync"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\BrowserSettings"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Credentials"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\DesktopTheme"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Language"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\PackageState"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Personalization"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\StartLayout"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Steps-Recorder"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\DeviceHealthAttestationService"; Name = "DisableSendGenericDriverNotFoundToWER"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings"; Name = "DisableSendGenericDriverNotFoundToWER"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\DriverDatabase\Policies\Settings"; Name = "DisableSendGenericDriverNotFoundToWER"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Policies\Microsoft\Windows\CloudContent"; Name = "ConfigureWindowsSpotlight"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKCU\Software\Policies\Microsoft\Windows\CloudContent"; Name = "DisableThirdPartySuggestions"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Policies\Microsoft\Windows\CloudContent"; Name = "DisableWindowsSpotlightFeatures"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent"; Name = "DisableWindowsConsumerFeatures"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "ContentDeliveryAllowed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "FeatureManagementEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "OemPreInstalledAppsEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "PreInstalledAppsEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "PreInstalledAppsEverEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "RemediationRequired"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SilentInstalledAppsEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement"; Name = "ScoobeSystemSettingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "AllowOnlineTips"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Policies\Microsoft\PushToInstall"; Name = "DisablePushToInstall"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-310093Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-338388Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-338389Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-353698Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-338387Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-314563Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-314559Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\DeviceHealthAttestationService"; Name = "DisableSendGenericDriverNotFoundToWER"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\DataCollection"; Name = "DoNotShowFeedbackNotifications"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Policies\Microsoft\Assistance\Client\1.0"; Name = "NoExplicitFeedback"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Assistance\Client\1.0\Settings"; Name = "ImplicitFeedback"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\Windows"; Name = "DontShowUI"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\Windows"; Name = "Disabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\Windows"; Name = "DontSendAdditionalData"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\Windows"; Name = "LoggingDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\Windows"; Name = "DefaultConsent"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\Windows"; Name = "DefaultOverrideBehavior"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\Windows"; Name = "DontShowUI"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports"; Name = "PreventHandwritingErrorReports"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC"; Name = "PreventHandwritingDataSharing"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "AutoApproveOSDumps"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "Disabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "DontSendAdditionalData"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Microsoft\PCHealth\ErrorReporting"; Name = "ShowUI"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\W3SVC"; Name = "Start"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\Windows"; Name = "DontSendAdditionalData"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Microsoft\Windows\Windows"; Name = "DontShowUI"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Microsoft\Windows\Windows"; Name = "LoggingDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\Software\Microsoft\Windows\Windows"; Name = "DefaultConsent"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\Windows"; Name = "DefaultOverrideBehavior"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\FTH"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "StartupBoostEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "BackgroundModeEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\DWM"; Name = "UseDpiScaling"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Multimedia\Audio"; Name = "UserDuckingPreference"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"; Name = "ctfmon"; Type = "REG_SZ"; Value = "C:\Windows\System32\ctfmon.exe" },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\VideoSettings"; Name = "VideoQualityOnBattery"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "IconsOnly"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "ListviewShadow"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Policies\DataCollection"; Name = "AllowTelemetry"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy"; Name = "HasAccepted"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKU\S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings"; Name = "DownloadMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"; Name = "NoAutoUpdate"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\DWM"; Name = "EnableAeroPeek"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SilentInstalledAppsEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SystemPaneSuggestionsEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SoftLandingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "RotatingLockScreenEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Search"; Name = "BackgroundAppGlobalToggle"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config"; Name = "DownloadMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings"; Name = "NOC_GLOBAL_SETTING_ALLOW_NOTIFICATION_SOUND"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings"; Name = "NOC_GLOBAL_SETTING_ALLOW_CRITICAL_TOASTS_ABOVE_LOCK"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\QuietHours"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.AutoPlay"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.LowDisk"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.Print.Notification"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.WiFiNetworkManager"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows"; Name = "EnableFeeds"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft"; Name = "AllowNewsAndInterests"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "DisallowShaking"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "EnableBalloonTips"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "ShowSyncProviderNotifications"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Remote"; Name = "fAllowToGetHelp"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Edge"; Name = "StartupBoostEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Edge"; Name = "BackgroundModeEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SearchSettings"; Name = "IsDeviceSearchHistoryEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-338393Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-353694Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-353696Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync"; Name = "SyncPolicy"; Type = "REG_DWORD"; Value = 5 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MultitaskingView\AllUpView"; Name = "AllUpView"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MultitaskingView\AllUpView"; Name = "Remove"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Control"; Name = "AutoEndTasks"; Type = "REG_SZ"; Value = 1 },
		@{ Path = "HKCU\Control"; Name = "HungAppTimeout"; Type = "REG_SZ"; Value = 1000 },
		@{ Path = "HKCU\Control"; Name = "WaitToKillAppTimeout"; Type = "REG_SZ"; Value = 2000 },
		@{ Path = "HKCU\Control"; Name = "LowLevelHooksTimeout"; Type = "REG_SZ"; Value = 1000 },
		@{ Path = "HKCU\Control"; Name = "MenuShowDelay"; Type = "REG_SZ"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control"; Name = "WaitToKillServiceTimeout"; Type = "REG_SZ"; Value = 2000 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "Start_TrackProgs"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "ExtendedUIHoverTime"; Type = "REG_DWORD"; Value = 196608 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "DontPrettyPath"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "NoLowDiskSpaceChecks"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "LinkResolveIgnoreLinkInfo"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "NoResolveSearch"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "NoResolveTrack"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "NoInternetOpenWith"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "NoInstrumentation"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_CURRENT_USER\SYSTEM\GameConfigStore\Children\fefe78e0-cf54-411d-9154-04b8f488bea2"; Name = "Flags"; Type = "REG_DWORD"; Value = 529 },
		@{ Path = "HKLM\Software\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots"; Name = "value"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Background"; Type = "REG_SZ"; Value = "True" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Clock"; Type = "REG_DWORD"; Value = 10000 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "GPU"; Type = "REG_DWORD"; Value = 12 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Scheduling"; Type = "REG_SZ"; Value = "Medium" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "SFIO"; Type = "REG_SZ"; Value = "Normal" },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderDocuments"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderDocuments_ProviderSet"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderDownloads"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderDownloads_ProviderSet"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderPersonalFolder"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderPersonalFolder_ProviderSet"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderFileExplorer"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PolicyManager\current\device\Start"; Name = "AllowPinnedFolderFileExplorer_ProviderSet"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\Shell\Bags\1\Desktop"; Name = "FFlags"; Type = "REG_DWORD"; Value = 1075839525 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "TranslateEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "TaskManagerEndProcessEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "UserFeedbackAllowed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "SpellCheckServiceEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "SpellcheckEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "MediaRouterCastAllowAllIPs"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "AllowDinosaurEasterEgg"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultGeolocationSetting"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultCookiesSetting"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultFileHandlingGuardSetting"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultFileSystemReadGuardSetting"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultFileSystemnv11GuardSetting"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultImagesSetting"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultPopupsSetting"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultSensorsSetting"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultSerialGuardSetting"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultWebBluetoothGuardSetting"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultWebUsbGuardSetting"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "EnableMediaRouter"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "ShowCastIconInToolbar"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "CloudPrintProxyEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "PrintRasterizationMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "PrintingEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DefaultPluginsSetting"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "SafeBrowsingProtectionLevel"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "SafeBrowsingExtendedReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "HomepageIsNewTabPage"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "HomepageLocation"; Type = "REG_SZ"; Value = "google.com" },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "NewTabPageLocation"; Type = "REG_SZ"; Value = "google.com" },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome\Recommended"; Name = "MetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome\Recommended"; Name = "DeviceMetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Policies\Google\Chrome\Recommended"; Name = "MetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Policies\Google\Chrome\Recommended"; Name = "DeviceMetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "MetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Chrome"; Name = "DeviceMetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Policies\Google\Chrome"; Name = "MetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Policies\Google\Chrome"; Name = "DeviceMetricsReportingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "Install{8A69D345-D564-463C-AFF1-A69D9E530F96}"; Type = "REG_DWORD"; Value = 5 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "TargetChannel{8A69D345-D564-463C-AFF1-A69D9E530F96}"; Type = "REG_SZ"; Value = "stable" },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "Update{8A69D345-D564-463C-AFF1-A69D9E530F96}"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "Install{4CCED17F-7852-4AFC-9E9E-C89D8795BDD2}"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "AutoUpdateCheckPeriodMinutes"; Type = "REG_DWORD"; Value = 43200 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "DownloadPreference"; Type = "REG_SZ"; Value = "cacheable" },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "UpdatesSuppressedStartHour"; Type = "REG_DWORD"; Value = 23 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "UpdatesSuppressedStartMin"; Type = "REG_DWORD"; Value = 48 },
		@{ Path = "HKLM\SOFTWARE\Policies\Google\Update"; Name = "UpdatesSuppressedDurationMin"; Type = "REG_DWORD"; Value = 55 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive"; Name = "DisableFileSync"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive"; Name = "DisableFileSyncNGSC"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive"; Name = "DisableMeteredNetworkFileSync"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive"; Name = "DisableLibrariesDefaultSaveToOneDrive"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\System\CurrentControlSet\Control\Session"; Name = "ProtectionMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "PassiveIntRealTimeWorkerPriority"; Type = "REG_DWORD"; Value = 18 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\KernelVelocity"; Name = "DisableFGBoostDecay"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "DpcWatchdogProfileOffset"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "DisableExceptionChainValidation"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "KernelSEHOPEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "DisableAutoBoost"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "DpcTimeout"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "ThreadDpcEnable"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "DpcWatchdogPeriod"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "InterruptSteeringDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Control\Session"; Name = "DistributeTimers"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\HardCap0"; Name = "CapPercentage"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\HardCap0"; Name = "SchedulingType"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\Paused"; Name = "CapPercentage"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\Paused"; Name = "SchedulingType"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\SoftCapFull"; Name = "CapPercentage"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\SoftCapFull"; Name = "SchedulingType"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\SoftCapLow"; Name = "CapPercentage"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\CPU\SoftCapLow"; Name = "SchedulingType"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\BackgroundDefault"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\Frozen"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\FrozenDNCS"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\FrozenDNK"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\FrozenPPLE"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\Paused"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\PausedDNK"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\Pausing"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\PrelaunchForeground"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Flags\ThrottleGPUInterference"; Name = "IsLowPriority"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Critical"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Critical"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\CriticalNoUi"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\CriticalNoUi"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\EmptyHostPPLE"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\EmptyHostPPLE"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\High"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\High"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Low"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Low"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Lowest"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Lowest"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Medium"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\Medium"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\MediumHigh"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\MediumHigh"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\StartHost"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\StartHost"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\VeryHigh"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\VeryHigh"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\VeryLow"; Name = "BasePriority"; Type = "REG_DWORD"; Value = 82 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Importance\VeryLow"; Name = "OverTargetPriority"; Type = "REG_DWORD"; Value = 50 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\IO\NoCap"; Name = "IOBandwidth"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Memory\NoCap"; Name = "CommitLimit"; Type = "REG_DWORD"; Value = 4294967295 },
		@{ Path = "HKLM\SYSTEM\ResourcePolicyStore\ResourceSets\Policies\Memory\NoCap"; Name = "CommitTarget"; Type = "REG_DWORD"; Value = 4294967295 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "CpuPriority"; Type = "REG_DWORD"; Value = 42 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "PerformancePriority"; Type = "REG_DWORD"; Value = 8 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "Application"; Type = "REG_SZ"; Value = "%%i.exe" },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "Version"; Type = "REG_SZ"; Value = "1.0" },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "Protocol"; Type = "REG_SZ"; Value = "*" },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "Local"; Type = "REG_SZ"; Value = "*" },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "Remote"; Type = "REG_SZ"; Value = "*" },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "DSCP"; Type = "REG_SZ"; Value = 46 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "CpuPriorityControl"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "CpuPrioritySeperation"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "PowerLimitEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "PerformanceSpread"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "UnlimitedPerformance"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "CpuPriorityClass"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "IoPriority"; Type = "REG_DWORD"; Value = 3 },
		@{ Path = "HKLM\Software\Policies\Microsoft\Windows\QoS\%%i"; Name = "Throttle"; Type = "REG_SZ"; Value = -1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "GpuPriorityClass"; Type = "REG_DWORD"; Value = 8 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "MaximumPerformanceEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "CpuMaxPerformance"; Type = "REG_DWORD"; Value = 256 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "CpuPriorityClass"; Type = "REG_DWORD"; Value = 8 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "GpuPriority"; Type = "REG_DWORD"; Value = 42 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "IoPriority"; Type = "REG_DWORD"; Value = 8 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "PowerThrottlingOff"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "Priority"; Type = "REG_DWORD"; Value = 6 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "IOPriorityClass"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "GpuMaxPerformance"; Type = "REG_DWORD"; Value = 256 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "GpuAccelerating"; Type = "REG_DWORD"; Value = 256 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "HwSchMode"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows"; Name = "UseLargePages"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "TaskbarMn"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "ShowTaskViewButton"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Search"; Name = "SearchboxTaskbarMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "HideSCAMeetNow"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer"; Name = "DisableNotificationCenter"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds"; Name = "EnableFeeds"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer"; Name = "EnableAutoTray"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer"; Name = "ShowOrHideMostUsedApps"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer"; Name = "HideRecentlyAddedApps"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"; Name = "HideRecentlyAddedApps"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"; Name = "Start_TrackDocs"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Dsh"; Name = "AllowNewsAndInterests"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Control Panel\Desktop"; Name = "LogPixels"; Type = "REG_DWORD"; Value = 150 },
		@{ Path = "HKCU\Control Panel\Desktop"; Name = "Win8DpiScaling"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Control Panel\Desktop"; Name = "EnablePerProcessSystemDPI"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\BootAnimation"; Name = "DisableStartupSound"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Origin Client Service"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKLM\SYSTEM\CurrentControlSet\Services\Origin Web Helper Service"; Name = "Start"; Type = "REG_DWORD"; Value = 4 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "AudioEncodingBitrate"; Type = "REG_DWORD"; Value = 128000 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "AudioCaptureEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "CustomVideoEncodingBitrate"; Type = "REG_DWORD"; Value = 4000000 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "CustomVideoEncodingHeight"; Type = "REG_DWORD"; Value = 720 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "CustomVideoEncodingWidth"; Type = "REG_DWORD"; Value = 1280 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "HistoricalBufferLength"; Type = "REG_DWORD"; Value = 30 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "HistoricalBufferLengthUnit"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "HistoricalCaptureEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "HistoricalCaptureOnBatteryAllowed"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "HistoricalCaptureOnWirelessDisplayAllowed"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VideoEncodingBitrateMode"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VideoEncodingResolutionMode"; Type = "REG_DWORD"; Value = 2 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VideoEncodingFrameRateMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "EchoCancellationEnabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "CursorCaptureEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKToggleGameBar"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMToggleGameBar"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKSaveHistoricalVideo"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMSaveHistoricalVideo"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKToggleRecording"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMToggleRecording"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKTakeScreenshot"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMTakeScreenshot"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKToggleRecordingIndicator"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMToggleRecordingIndicator"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKToggleMicrophoneCapture"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMToggleMicrophoneCapture"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKToggleCameraCapture"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMToggleCameraCapture"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKToggleBroadcast"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "VKMToggleBroadcast"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "MicrophoneCaptureEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "SystemAudioGain"; Type = "REG_BINARY"; Value = "10,27,00,00,00,00,00,00" },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR"; Name = "MicrophoneGain"; Type = "REG_BINARY"; Value = "10,27,00,00,00,00,00,00" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam"; Name = "Value"; Type = "REG_SZ"; Value = "Allow" },
		@{ Path = "HKCU\Software\Microsoft\Speech_OneCore\Settings\VoiceActivation\UserPreferenceForAllApps"; Name = "AgentActivationEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Speech_OneCore\Settings\VoiceActivation\UserPreferenceForAllApps"; Name = "AgentActivationLastUsed"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCall"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userDataTasks"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\bluetoothSync"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\documentsLibrary"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\downloadsFolder"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\musicLibrary"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\picturesLibrary"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\videosLibrary"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\graphicsCaptureWithoutBorder"; Name = "Value"; Type = "REG_SZ"; Value = "Deny" },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\graphicsCaptureProgrammatic"; Name = "Value"; Type = "REG_SZ"; Value = "Allow" },
		@{ Path = "HKCU\Control Panel\International\User Profile"; Name = "HttpAcceptLanguageOptOut"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Policies\Microsoft\Windows\EdgeUI"; Name = "DisableMFUTracking"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\EdgeUI"; Name = "DisableMFUTracking"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\InputPersonalization"; Name = "RestrictImplicitInkCollection"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\InputPersonalization"; Name = "RestrictImplicitTextCollection"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\InputPersonalization\TrainedDataStore"; Name = "HarvestContacts"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Personalization\Settings"; Name = "AcceptedPrivacyPolicy"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Siuf\Rules"; Name = "NumberOfSIUFInPeriod"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Policies\Microsoft\Windows\System"; Name = "PublishUserActivities"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SearchSettings"; Name = "SafeSearchMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings"; Name = "IsAADCloudSearchEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings"; Name = "IsMSACloudSearchEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications"; Name = "ToastEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.CapabilityAccess"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.StartupApp"; Name = "Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"; Name = "SubscribedContent-338389Enabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\ScreenMagnifier"; Name = "FollowCaret"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\ScreenMagnifier"; Name = "FollowNarrator"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\ScreenMagnifier"; Name = "FollowMouse"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\ScreenMagnifier"; Name = "FollowFocus"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator"; Name = "IntonationPause"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator"; Name = "ReadHints"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator"; Name = "ErrorNotificationType"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator"; Name = "EchoChars"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator"; Name = "EchoWords"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator\NarratorHome"; Name = "MinimizeType"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator\NarratorHome"; Name = "AutoStart"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\Microsoft\Narrator\NoRoam"; Name = "EchoToggleKeys"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Narrator\NoRoam"; Name = "DuckAudio"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Narrator\NoRoam"; Name = "WinEnterLaunchEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Narrator\NoRoam"; Name = "ScriptingEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Narrator\NoRoam"; Name = "OnlineServicesEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Narrator"; Name = "NarratorCursorHighlight"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Narrator"; Name = "CoupleNarratorCursorKeyboard"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Ease of Access"; Name = "selfvoice"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\Microsoft\Ease of Access"; Name = "selfscan"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Control Panel\Accessibility"; Name = "Sound on Activation"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Control Panel\Accessibility"; Name = "Warning Sounds"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Control Panel\Accessibility\SlateLaunch"; Name = "LaunchAT"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching"; Name = "SearchOrderConfig"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\Software\NVIDIA Corporation\NvTray"; Name = "StartOnLogin"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance"; Name = "MaintenanceDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications"; Name = "GlobalUserDisabled"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"; Name = "DisableAutomaticRestartSignOn"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SYSTEM\Maps"; Name = "AutoUpdateEnabled"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_ENABLE_UNSAFE_COMMAND_BUFFER_REUSE"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_ENABLE_RUNTIME_DRIVER_OPTIMIZATIONS"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_RESOURCE_ALIGNMENT"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D11_MULTITHREADED"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_MULTITHREADED"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D11_DEFERRED_CONTEXTS"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_DEFERRED_CONTEXTS"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D11_ALLOW_TILING"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D11_ENABLE_DYNAMIC_CODEGEN"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_ALLOW_TILING"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_CPU_PAGE_TABLE_ENABLED"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_HEAP_SERIALIZATION_ENABLED"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_MAP_HEAP_ALLOCATIONS"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\DirectX"; Name = "D3D12_RESIDENCY_MANAGEMENT_ENABLED"; Type = "REG_DWORD"; Value = 1 },
		@{ Path = "HKLM\SOFTWARE\Microsoft\Windows\Dwm"; Name = "OverlayTestMode"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKLM\SOFTWARE\NVIDIA Corporation\NvControlPanel2\Client"; Name = "OptInOrOutPreference"; Type = "REG_DWORD"; Value = 0 },
		@{ Path = "HKCU\SOFTWARE\NVIDIA Corporation\NVControlPanel2\Client"; Name = "OptInOrOutPreference"; Type = "REG_DWORD"; Value = 0 }

	)

    $counter = 0
    $total = $registryEdits.Count
    foreach ($reg in $registryEdits) {
        $counter++
        Write-Progress -Activity "Aplicando otimizações de registro" -Status "$counter de $total" -PercentComplete (($counter / $total) * 100)
        try {
            reg.exe add $reg.Path /v $reg.Name /t $reg.Type /d $reg.Value /f | Out-Null
        } catch {
            Write-Warning "Erro ao definir $($reg.Name) em $($reg.Path)"
        }
    }
    Write-Progress -Activity "Aplicando otimizações de registro" -Completed
    Write-Host "✓ Configurações de registro aplicadas." -ForegroundColor Green


    # === BCDEDIT ===
    Write-Host "Aplicando configurações avançadas via bcdedit..." -ForegroundColor Cyan
    $bcdSettings = @(
        @{ Command = "set"; Argument = "configaccesspolicy default" },
        @{ Command = "set"; Argument = "usephysicaldestination no" },
        @{ Command = "set"; Argument = "usefirmwarepcisettings no" },
        @{ Command = "deletevalue"; Argument = "useplatformtick" },
        @{ Command = "deletevalue"; Argument = "useplatformclock" },
        @{ Command = "set"; Argument = "disabledynamictick yes" },
        @{ Command = "set"; Argument = "tscsyncpolicy legacy" },
        @{ Command = "set"; Argument = "x2apicpolicy enable" },
        @{ Command = "set"; Argument = "ems no" },
        @{ Command = "set"; Argument = "bootems no" },
        @{ Command = "set"; Argument = "vm no" },
        @{ Command = "set"; Argument = "sos no" },
        @{ Command = "set"; Argument = "quietboot yes" },
        @{ Command = "set"; Argument = "integrityservices disable" },
        @{ Command = "set"; Argument = "bootux disabled" },
        @{ Command = "set"; Argument = "bootlog no" },
        @{ Command = "set"; Argument = "tpmbootentropy ForceDisable" },
        @{ Command = "set"; Argument = "disableelamdrivers yes" },
        @{ Command = "set"; Argument = "hypervisorlaunchtype off" },
        @{ Command = "set"; Argument = "isolatedcontext no" },
        @{ Command = "set"; Argument = "pae ForceDisable" },
        @{ Command = "set"; Argument = "vsmlaunchtype off" }
    )

    $count = 0
    foreach ($setting in $bcdSettings) {
        $count++
        Write-Progress -Activity "Configurando bcdedit" -Status "$count de $($bcdSettings.Count)" -PercentComplete (($count / $bcdSettings.Count) * 100)
        try {
            bcdedit /$($setting.Command) $($setting.Argument) | Out-Null
        } catch {
            Write-Warning "Erro ao aplicar bcdedit $($setting.Command) $($setting.Argument)"
        }
    }
    Write-Progress -Activity "Configurando bcdedit" -Completed
    Write-Host "✓ Configurações de boot aplicadas." -ForegroundColor Green


    # === AUDITPOL ===
    Write-Host "Ajustando políticas de auditoria..." -ForegroundColor Cyan
    $auditSettings = @(
        'Process Termination',
        'RPC Events',
        'Filtering Platform Connection',
        'DPAPI Activity',
        'IPsec Driver',
        'Other System Events',
        'Security State Change',
        'Security System Extension',
        'System Integrity'
    )

    $count = 0
    foreach ($subcat in $auditSettings) {
        $count++
        Write-Progress -Activity "Configurando auditoria" -Status "$count de $($auditSettings.Count)" -PercentComplete (($count / $auditSettings.Count) * 100)
        try {
            Auditpol /set /subcategory:"$subcat" /failure:Disable /failure:Enable | Out-Null
        } catch {
            Write-Warning "Erro ao aplicar Auditpol em $subcat"
        }
    }
    Write-Progress -Activity "Configurando auditoria" -Completed
    Write-Host "✓ Políticas de auditoria aplicadas." -ForegroundColor Green


    # === SCHTASKS ===
    Write-Host "Desativando tarefas agendadas desnecessárias..." -ForegroundColor Cyan
    $tasks = @(
        "\Microsoft\Windows\Customer Experience Improvement Program\Uploader",
        "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser",
        "\Microsoft\Windows\Application Experience\StartupAppTask",
        "\Microsoft\Windows\Shell\FamilySafetyMonitor",
        "\Microsoft\Windows\Shell\FamilySafetyRefresh",
        "\Microsoft\Windows\Shell\FamilySafetyUpload",
    )

    $count = 0
    foreach ($task in $tasks) {
        $count++
        Write-Progress -Activity "Desativando tarefas agendadas" -Status "$count de $($tasks.Count)" -PercentComplete (($count / $tasks.Count) * 100)
        schtasks /end /tn $task | Out-Null
        schtasks /change /tn $task /disable | Out-Null
    }
    Write-Progress -Activity "Desativando tarefas agendadas" -Completed
    Write-Host "✓ Tarefas agendadas desativadas." -ForegroundColor Green


    # === FSUTIL ===
    Write-Host "Aplicando ajustes com fsutil..." -ForegroundColor Cyan
    fsutil behavior set memoryusage 2 | Out-Null
    fsutil behavior set mftzone 4 | Out-Null
    fsutil behavior set Disablinglastaccess 1 | Out-Null
    fsutil behavior set encryptpagingfile 0 | Out-Null
    Write-Host "✓ Ajustes fsutil aplicados." -ForegroundColor Green


    # === LIMPEZA TEMP, LOGS, PREFETCH ===
    Write-Host "Limpando arquivos temporários e logs..." -ForegroundColor Cyan
    del *.log /a /s /q /f
    del /s /f /q C:\Windows\Temp\*.*
    del /s /f /q C:\WINDOWS\Prefetch\*.*
    del /s /f /q $env:TEMP\*.*
    RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 8
    RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 16384
    RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 2
    ipconfig /flushdns | Out-Null
    Write-Host "✓ Limpeza de temporários concluída." -ForegroundColor Green


    # === LIMPEZA CACHE WINDOWS UPDATE ===
    Write-Host "Limpando cache do Windows Update..." -ForegroundColor Cyan
    net stop wuauserv | Out-Null
    net stop UsoSvc | Out-Null
    rd /s /q C:\Windows\SoftwareDistribution
    md C:\Windows\SoftwareDistribution
    RD /S /Q $env:TEMP
    MKDIR $env:TEMP
    takeown /f "$env:TEMP" /r /d y | Out-Null
    takeown /f "C:\Windows\Temp" /r /d y | Out-Null
    RD /S /Q C:\Windows\Temp
    MKDIR C:\Windows\Temp
    Write-Host "✓ Cache do Windows Update limpo." -ForegroundColor Green

	# === USB POWER MANAGEMENT ===
    Write-Host "Desativando economia de energia em dispositivos USB..." -ForegroundColor Cyan
    try {
        $usbDevices = Get-WmiObject Win32_USBHub | Select-Object -ExpandProperty DeviceID | Where-Object { $_ -match "VID_" }
        $total = $usbDevices.Count
        $i = 0
        foreach ($dev in $usbDevices) {
            $i++
            Write-Progress -Activity "Aplicando otimizações USB" -Status "$i de $total" -PercentComplete (($i / $total) * 100)
            $basePath = "HKLM:\SYSTEM\CurrentControlSet\Enum\$dev\Device Parameters"
            
            # Cria as chaves e aplica valores
            New-Item -Path $basePath -Force | Out-Null
            New-ItemProperty -Path $basePath -Name "EnhancedPowerManagementEnabled" -Value 0 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $basePath -Name "AllowIdleIrpInD3" -Value 0 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $basePath -Name "SelectiveSuspendOn" -Value 0 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $basePath -Name "DeviceSelectiveSuspended" -Value 0 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $basePath -Name "SelectiveSuspendEnabled" -Value 0 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $basePath -Name "IdleInWorkingState" -Value 0 -PropertyType DWord -Force | Out-Null
            
            Write-Host "✓ USB otimizado: $dev" -ForegroundColor Green
        }
    } catch {
        Write-Warning "Erro ao aplicar otimizações de energia USB."
    }
    Write-Progress -Activity "Aplicando otimizações USB" -Completed
    Write-Host "✓ Economia de energia em USB desativada." -ForegroundColor Green

    Write-Host "=====================================" -ForegroundColor Cyan
    Write-Host "✅ Otimizações de sistema aplicadas com sucesso!" -ForegroundColor Green
    Write-Host "=====================================" -ForegroundColor Cyan
}


function Invoke-NvidiaOptimize1 {
    $nvPath = "C:\Program Files\NVIDIA Corporation\NVSMI"
    if (-Not (Test-Path $nvPath)) {
        Write-Warning "Caminho NVIDIA NVSMI não encontrado: $nvPath"
        return
    }
    Push-Location $nvPath
    try {
        # Executa os comandos nvidia-smi com os parâmetros
        & .\nvidia-smi.exe -acp 0
        & .\nvidia-smi.exe -e 1
    } catch {
        Write-Error "Erro ao executar comandos NVIDIA: $_"
    }
    Pop-Location
}

function Invoke-NvidiaOptimize2 {
    # Essa função em PowerShell reproduz o batch para desabilitar DynamicPstate

    $devices = (wmic path Win32_VideoController get PNPDeviceID | Select-String "PCI\\VEN_").Matches.Value

    foreach ($device in $devices) {
        $regPath = "HKLM:\SYSTEM\ControlSet001\Enum\$device"
        try {
            $driverValue = (Get-ItemProperty -Path $regPath -Name Driver -ErrorAction Stop).Driver
            if ($driverValue -match "^{.*}$") {
                $classRegPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\$driverValue"
                # Adiciona o valor DisableDynamicPstate = 1
                New-ItemProperty -Path $classRegPath -Name "DisableDynamicPstate" -PropertyType DWord -Value 1 -Force | Out-Null
                Write-Host "Definido DisableDynamicPstate=1 em $classRegPath"
            }
        } catch {
            Write-Warning "Não foi possível acessar o registro para $device"
        }
    }
}

function Invoke-NvidiaOptimize3{
    Clear-Host
    Write-Host "Aplicando otimizações NVIDIA (Optimize 3)..."

    try {
        # 🔧 Desabilitar tarefas agendadas de crash report da NVIDIA
        $tasks = @(
            "NvTmRepCrashReport2{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}",
            "NvTmRepCrashReport3{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}",
            "NvTmRepCrashReport4{B2FE1952-0186-46C3-BAEC-A80AA35AC5B8}"
        )

        foreach ($task in $tasks) {
            schtasks /change /disable /tn $task >$null 2>&1
        }

        # 🔧 Configurações de registro
        $regSettings = @(
            @{ Path = "HKLM:\SOFTWARE\NVIDIA Corporation\NvControlPanel2\Client"; Name = "OptInOrOutPreference"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\CurrentControlSet\Services\nvlddmkm\Global\Startup"; Name = "SendTelemetryData"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "DisablePreemption"; Type = "DWORD"; Value = 1 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "DisableCudaContextPreemption"; Type = "DWORD"; Value = 1 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "EnableCEPreemption"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "DisablePreemptionOnS3S4"; Type = "DWORD"; Value = 1 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "ComputePreemption"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "EnableMidGfxPreemption"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "EnableMidGfxPreemptionVGPU"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "EnableMidBufferPreemptionForHighTdrTimeout"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "EnableMidBufferPreemption"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Services\nvlddmkm"; Name = "EnableAsyncMidBufferPreemption"; Type = "DWORD"; Value = 0 },
            @{ Path = "HKLM:\SYSTEM\ControlSet001\Control\GraphicsDrivers\Scheduler"; Name = "EnablePreemption"; Type = "DWORD"; Value = 0 }
        )

        foreach ($setting in $regSettings) {
            if (-not (Test-Path $setting.Path)) {
                New-Item -Path $setting.Path -Force | Out-Null
            }
            New-ItemProperty -Path $setting.Path -Name $setting.Name -PropertyType $setting.Type -Value $setting.Value -Force | Out-Null
        }

        Write-Host "`n✅ Otimizações NVIDIA (Optimize 3) aplicadas com sucesso!"
    }
    catch {
        Write-Host "`n❌ Erro ao aplicar otimizações NVIDIA: $_"
    }

    Read-Host "Pressione Enter para voltar ao menu."
}

function Invoke-AmdOptimize {
    Clear-Host
    Write-Host "Aplicando otimizações AMD..."

    try {
        $basePath = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000"

        $regSettings = @(
            @{ Name = "DisableUVDPowerGatingDynamic"; Type = "DWORD"; Value = 1 },
            @{ Name = "AllowSnapshot"; Type = "DWORD"; Value = 0 },
            @{ Name = "DisableDrmdmaPowerGating"; Type = "DWORD"; Value = 1 },
            @{ Name = "EnableUlps"; Type = "DWORD"; Value = 0 },
            @{ Name = "AllowRSOverlay"; Type = "String"; Value = "false" },
            @{ Name = "AutoColorDepthReduction_NA"; Type = "DWORD"; Value = 0 },
            @{ Name = "AllowSubscription"; Type = "DWORD"; Value = 0 },
            @{ Name = "DisableVCEPowerGating"; Type = "DWORD"; Value = 1 },
            @{ Name = "DisableDMACopy"; Type = "DWORD"; Value = 1 },
            @{ Name = "AllowSkins"; Type = "String"; Value = "false" },
            @{ Name = "PP_GPUPowerDownEnabled"; Type = "DWORD"; Value = 0 },
            @{ Name = "DisableBlockWrite"; Type = "DWORD"; Value = 0 },
            @{ Name = "StutterMode"; Type = "DWORD"; Value = 0 },
            @{ Name = "DisablePowerGating"; Type = "DWORD"; Value = 1 }
        )

        foreach ($setting in $regSettings) {
            if (-not (Test-Path $basePath)) {
                New-Item -Path $basePath -Force | Out-Null
            }
            New-ItemProperty -Path $basePath -Name $setting.Name -PropertyType $setting.Type -Value $setting.Value -Force | Out-Null
        }

        Write-Host "`n✅ Otimizações AMD aplicadas com sucesso!"
    }
    catch {
        Write-Host "`n❌ Erro ao aplicar otimizações AMD: $_"
    }

    Read-Host "Pressione Enter para voltar ao menu."
}

function Invoke-CleanSystem {
    Clear-Host
    Write-Host "`n[INFO] Iniciando limpeza avançada do sistema..." -ForegroundColor Green

    # Lista de diretórios a limpar
    $paths = @(
        $env:TEMP,
        "C:\Windows\Temp",
        "C:\Windows\Prefetch",
        "C:\Windows\Spool\Printers",
        "C:\Windows\History",
        "C:\Windows\Cookies",
        "C:\Windows\Recent",
        "C:\Windows\Tmp"
    )

    # Arquivos adicionais
    $files = @(
        "C:\WIN386.SWP",
        "C:\Windows\ff*.tmp"
    )

    # === ETAPA 1 - Limpando arquivos e diretórios ===
    Write-Host "`n[ETAPA 1/3] Limpando arquivos temporários, cache e logs..." -ForegroundColor Yellow

    $i = 0
    foreach ($item in $paths) {
        $i++
        if (Test-Path $item) {
            Write-Progress -Activity "Limpando diretórios" -Status $item -PercentComplete (($i / $paths.Count) * 100)
            Get-ChildItem -Path $item -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
        }
        Start-Sleep -Milliseconds 400
    }

    foreach ($file in $files) {
        if (Test-Path $file) {
            Remove-Item $file -Force -ErrorAction SilentlyContinue
            Write-Host "Arquivo removido: $file"
        }
    }

    Write-Progress -Activity "Limpando diretórios" -Completed

    # === ETAPA 2 - Recriando TEMP ===
    Write-Host "`n[ETAPA 2/3] Recriando pastas TEMP..." -ForegroundColor Yellow
    $recreate = @($env:TEMP, "C:\Windows\Temp")
    foreach ($p in $recreate) {
        try {
            if (Test-Path $p) { Remove-Item -Path $p -Recurse -Force -ErrorAction SilentlyContinue }
            New-Item -Path $p -ItemType Directory -Force | Out-Null
            Write-Host "Recriada: $p"
        } catch {}
    }

    # === ETAPA 3 - Limpando Logs de Eventos ===
    Write-Host "`n[ETAPA 3/3] Limpando Logs de Eventos..." -ForegroundColor Yellow
    $logs = wevtutil el
    $count = $logs.Count
    $i = 0
    foreach ($log in $logs) {
        $i++
        Write-Progress -Activity "Limpando Logs de Eventos" -Status $log -PercentComplete (($i / $count) * 100)
        try {
            wevtutil cl "$log" 2>$null
        } catch {}
    }
    Write-Progress -Activity "Limpando Logs de Eventos" -Completed

    Write-Host "`n[FINALIZADO] Limpeza concluída com sucesso!" -ForegroundColor Green
}

# ===== FUNÇÃO DE REMOÇÃO DE INTEGRAÇÕES =====
Function Invoke-AppIntegrationKeys {
    $Keys = @(

        # Windows File
        "HKCR:\Extensions\ContractId\Windows.File\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0",

        # Launch
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy",

        # PreInstalledConfigTask
        "HKCR:\Extensions\ContractId\Windows.PreInstalledConfigTask\PackageId\Microsoft.MicrosoftOfficeHub_17.7909.7600.0_x64__8wekyb3d8bbwe",

        # Protocol
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0",
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy",

        # Share Target
        "HKCR:\Extensions\ContractId\Windows.ShareTarget\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
    )

    Write-Host "`n=== INICIANDO LIMPEZA DE INTEGRAÇÕES DE APPS ===" -ForegroundColor Cyan

    ForEach ($Key in $Keys) {
        if (Test-Path $Key) {
            Write-Host "✅ Removendo: $Key" -ForegroundColor Green
            Remove-Item $Key -Recurse -Force
        } else {
            Write-Host "⚠️ Chave não encontrada: $Key" -ForegroundColor Yellow
        }
    }

    Write-Host "`n=== Removed Integrations ===" -ForegroundColor Cyan
}

function Invoke-AppIntegrationKeys {
    # Lista de chaves de registro de integração de apps
    $Keys = @(
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\46928bounde.EclipseManager_2.2.4.51_neutral__a5h4egax66k6y",
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0",
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy",
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy",
        "HKCR:\Extensions\ContractId\Windows.BackgroundTasks\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy",
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\46928bounde.EclipseManager_2.2.4.51_neutral__a5h4egax66k6y",
        "HKCR:\Extensions\ContractId\Windows.Launch\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0",
        "HKCR:\Extensions\ContractId\Windows.PreInstalledConfigTask\PackageId\Microsoft.MicrosoftOfficeHub_17.7909.7600.0_x64__8wekyb3d8bbwe",
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.PPIProjection_10.0.15063.0_neutral_neutral_cw5n1h2txyewy",
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.XboxGameCallableUI_1000.15063.0.0_neutral_neutral_cw5n1h2txyewy",
        "HKCR:\Extensions\ContractId\Windows.Protocol\PackageId\Microsoft.XboxGameCallableUI_1000.16299.15.0_neutral_neutral_cw5n1h2txyewy",
        "HKCR:\Extensions\ContractId\Windows.ShareTarget\PackageId\ActiproSoftwareLLC.562882FEEB491_2.6.18.18_neutral__24pqs290vpjk0"
    )

    Write-Host "`n=== INICIANDO LIMPEZA DE INTEGRAÇÕES DE APPS ===" -ForegroundColor Cyan

    foreach ($Key in $Keys) {
        if (Test-Path $Key) {
            try {
                Remove-Item $Key -Recurse -Force
                Write-Host "✅ Removido: $Key" -ForegroundColor Green
            } catch {
                Write-Warning "❌ Erro ao remover $Key: $_"
            }
        } else {
            Write-Host "⚠️ Chave não encontrada: $Key" -ForegroundColor Yellow
        }
    }

    Write-Host "`n=== LIMPEZA CONCLUÍDA ===" -ForegroundColor Cyan
}

function Invoke-ProtectPrivacy {
    Write-Host "🔒 Aplicando proteções de privacidade..." -ForegroundColor Cyan

    try {
        # === Disable Windows Feedback Experience ===
        $Advertising = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo"
        if (Test-Path $Advertising) { Set-ItemProperty $Advertising Enabled -Value 0 }

        # === Disable Cortana via Windows Search policy ===
        $Search = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
        if (Test-Path $Search) { Set-ItemProperty $Search AllowCortana -Value 0 }

        # === Disable Cortana user data collection ===
        $Cortana1 = "HKCU:\SOFTWARE\Microsoft\Personalization\Settings"
        $Cortana2 = "HKCU:\SOFTWARE\Microsoft\InputPersonalization"
        $Cortana3 = "HKCU:\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore"
        if (!(Test-Path $Cortana1)) { New-Item $Cortana1 | Out-Null }
        Set-ItemProperty $Cortana1 AcceptedPrivacyPolicy -Value 0
        if (!(Test-Path $Cortana2)) { New-Item $Cortana2 | Out-Null }
        Set-ItemProperty $Cortana2 RestrictImplicitTextCollection -Value 1
        Set-ItemProperty $Cortana2 RestrictImplicitInkCollection -Value 1
        if (!(Test-Path $Cortana3)) { New-Item $Cortana3 | Out-Null }
        Set-ItemProperty $Cortana3 HarvestContacts -Value 0

        # === Disable Web Search in Start Menu ===
        $WebSearch = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search"
        if (!(Test-Path $WebSearch)) { New-Item $WebSearch | Out-Null }
        Set-ItemProperty $WebSearch DisableWebSearch -Value 1
        Set-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" BingSearchEnabled -Value 0

        # === Disable telemetry & data collection ===
        $DataPaths = @(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection",
            "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
            "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Policies\DataCollection"
        )
        foreach ($path in $DataPaths) { if (Test-Path $path) { Set-ItemProperty $path AllowTelemetry -Value 0 } }

        # === Disable location tracking ===
        $SensorState = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}"
        $LocationConfig = "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration"
        if (!(Test-Path $SensorState)) { New-Item $SensorState | Out-Null }
        Set-ItemProperty $SensorState SensorPermissionState -Value 0
        if (!(Test-Path $LocationConfig)) { New-Item $LocationConfig | Out-Null }
        Set-ItemProperty $LocationConfig Status -Value 0

        # === Disable live tiles ===
        $Live = "HKCU:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\PushNotifications"
        if (!(Test-Path $Live)) { New-Item $Live | Out-Null }
        Set-ItemProperty $Live NoTileApplicationNotification -Value 1

        # === Disable People icon on Taskbar ===
        $People = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People"
        if (Test-Path $People) { Set-ItemProperty $People -Name PeopleBand -Value 0 }

        # === Disable scheduled tasks ===
        $tasks = @(
            "XblGameSaveTaskLogon",
            "XblGameSaveTask",
            "Consolidator",
            "UsbCeip",
            "DmClient",
            "DmClientOnScenarioDownload"
        )
        foreach ($task in $tasks) { Get-ScheduledTask $task | Disable-ScheduledTask }

        # === Disable Diagnostics Tracking Service ===
        Stop-Service "DiagTrack" -ErrorAction SilentlyContinue
        Set-Service "DiagTrack" -StartupType Disabled

        # === Remove CloudStore ===
        $CloudStore = "HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore"
        if (Test-Path $CloudStore) {
            Stop-Process Explorer.exe -Force
            Remove-Item $CloudStore -Recurse -Force
            Start-Process Explorer.exe -Wait
        }

        # === Prevent Edge from taking over as default PDF viewer ===
        Write-Host "🚫 Bloqueando Edge como visualizador padrão de PDF"
        $NoPDF = "HKCR:\.pdf"
        $NoProgids = "HKCR:\.pdf\OpenWithProgids"
        $NoWithList = "HKCR:\.pdf\OpenWithList"
        $Edge = "HKCR:\AppXd4nrz8ff68srnhf9t5a8sbjyar1cr723_"

        $pdfPaths = @($NoPDF, $NoProgids, $NoWithList)
        foreach ($path in $pdfPaths) {
            if (!(Get-ItemProperty $path -Name NoOpenWith -ErrorAction SilentlyContinue)) { New-ItemProperty $path NoOpenWith | Out-Null }
            if (!(Get-ItemProperty $path -Name NoStaticDefaultVerb -ErrorAction SilentlyContinue)) { New-ItemProperty $path NoStaticDefaultVerb | Out-Null }
        }

        if (Test-Path $Edge) {
            Set-ItemProperty $Edge AppXd4nrz8ff68srnhf9t5a8sbjyar1cr723_ 
        }

        Write-Host "🎉 Proteções de privacidade aplicadas com sucesso!" -ForegroundColor Green

    } catch {
        Write-Error "Erro ao aplicar proteções de privacidade: $_"
    }
}






# ===== INICIAR SCRIPT =====
Show-MainMenu
