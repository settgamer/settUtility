﻿# =====================================
# PowerShell Installation Menu - Full Version with Remove
# =====================================

# Helper functions
function Show-Menu {
    param ([string]$title, [hashtable]$options)
    Clear-Host
    Write-Host "=== $title ===" -ForegroundColor Cyan
    foreach ($key in $options.Keys | Sort-Object) {
        Write-Host "$key) $($options[$key].Name)" -ForegroundColor White
    }
    Write-Host "0) Back" -ForegroundColor White
}

function Install-App {
    param ([string]$id, [string]$displayName)
    $confirm = Read-Host "Tem certeza que deseja instalar $displayName? (Y/N)"
    if ($confirm -match '^[Yy]$') {
        Write-Host "⏳ Instalando $displayName..." -ForegroundColor Yellow
        try {
            winget install --id=$id --silent --accept-source-agreements --accept-package-agreements
            Write-Host "✅ $displayName instalado com sucesso!" -ForegroundColor Green
        } catch {
            Write-Host "❌ Erro ao instalar $displayName" -ForegroundColor Red
        }
        Start-Sleep 1.5
    }
}

function Remove-App {
    param ([string]$id, [string]$displayName)
    $confirm = Read-Host "Tem certeza que deseja remover $displayName? (Y/N)"
    if ($confirm -match '^[Yy]$') {
        Write-Host "🟡 Removendo $displayName..." -ForegroundColor Yellow
        try {
            winget uninstall --id=$id
            Write-Host "✅ $displayName removido com sucesso!" -ForegroundColor Green
        } catch {
            Write-Host "❌ Erro ao remover $displayName" -ForegroundColor Red
        }
        Start-Sleep 1.5
    }
}

# Define categories and apps
$menu = @{
    '1' = @{ Name='Utils'; Apps=@{
        '1' = @{ Name='MSI Afterburner'; Id='MSI.Afterburner' }
        '2' = @{ Name='Ryzen Master'; Id='AMD.RyzenMaster' }
        '3' = @{ Name='Lightshot'; Id='Skillbrains.Lightshot' }
    }}
    '2' = @{ Name='Communication'; Apps=@{
        '1' = @{ Name='TeamSpeak'; Id='TeamSpeakSystems.TeamSpeak' }
    }}
    '3' = @{ Name='Games'; Apps=@{
        '1' = @{ Name='FACEIT'; Id='com.faceit.app' }
        '2' = @{ Name='GamersClub'; Id='br.gamersclub.launcher' }
    }}
}

# Main loop
while ($true) {
    Clear-Host
    Write-Host "=== Main Menu ===" -ForegroundColor Cyan
    foreach ($key in $menu.Keys | Sort-Object) {
        Write-Host "$key) $($menu[$key].Name)" -ForegroundColor White
    }
    Write-Host "R) Remove/Uninstall" -ForegroundColor White
    Write-Host "0) Exit" -ForegroundColor White

    $mainChoice = Read-Host 'Enter option'

    if ($mainChoice -eq '0') { break }

    if ($mainChoice -eq 'R' -or $mainChoice -eq 'r') {
        # Remove flow
        while ($true) {
            Show-Menu -title 'Select category to Remove' -options $menu
            $removeCat = Read-Host 'Enter option'
            if ($removeCat -eq '0') { break }
            if (-not $menu.ContainsKey($removeCat)) { continue }

            $apps = $menu[$removeCat].Apps
            while ($true) {
                Show-Menu -title "$($menu[$removeCat].Name) - Remove" -options $apps
                $appChoice = Read-Host 'Enter option'
                if ($appChoice -eq '0') { break }
                if (-not $apps.ContainsKey($appChoice)) { continue }
                $app = $apps[$appChoice]
                Remove-App -id $app.Id -displayName $app.Name
            }
        }
        continue
    }

    # Normal install flow
    if (-not $menu.ContainsKey($mainChoice)) { continue }

    $category = $menu[$mainChoice]
    $apps = $category.Apps
    while ($true) {
        Show-Menu -title $category.Name -options $apps
        $appChoice = Read-Host 'Enter option'
        if ($appChoice -eq '0') { break }
        if (-not $apps.ContainsKey($appChoice)) { continue }
        $app = $apps[$appChoice]
        Install-App -id $app.Id -displayName $app.Name
    }
}