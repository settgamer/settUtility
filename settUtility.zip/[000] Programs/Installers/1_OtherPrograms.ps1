﻿# =====================================
# PowerShell Installation Menu - Refactored Version
# =====================================

#region Helper Functions
function Show-Menu {
    param (
        [string]$Title,
        [System.Collections.IDictionary]$Options,
        [string]$ReturnOption = "Voltar"
    )
    Clear-Host
    Write-Host "=== $Title ===`n" -ForegroundColor Cyan
    
    # Dynamically create menu from options
    $menuItems = @{}
    $i = 1
    foreach ($key in $Options.Keys | Sort-Object) {
        $menuItems[$i] = $key
        Write-Host "$i) $($Options[$key].Name)" -ForegroundColor White
        $i++
    }

    Write-Host "`n0) $ReturnOption" -ForegroundColor White
    return $menuItems
}

function Invoke-WingetAction {
    param (
        [string]$Action, # "install" or "uninstall"
        [string]$Id,
        [string]$DisplayName
    )
    $actionVerb = @{
        install = "Instalando"
        uninstall = "Removendo"
    }[$action]

    $actionPast = @{
        install = "instalado"
        uninstall = "removido"
    }[$action]

    Write-Host "⏳ $actionVerb $DisplayName..." -ForegroundColor Yellow
    
    $params = @("--id=$Id", "--silent", "--accept-source-agreements", "--accept-package-agreements")
    if ($action -eq "uninstall") {
        $params = @("--id=$Id", "--silent") # Uninstall doesn't need all agreements
    }

    try {
        Start-Process winget -ArgumentList $params -Wait -NoNewWindow
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ $DisplayName $actionPast com sucesso!" -ForegroundColor Green
        } else {
            Write-Host "❌ Erro ao $actionVerb $DisplayName (Código de saída: $LASTEXITCODE)" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Falha crítica ao executar winget para $DisplayName." -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
    Start-Sleep -Seconds 2
}

function Handle-AppSelection {
    param (
        [string]$CategoryName,
        [hashtable]$Apps,
        [string]$Action # "install" or "uninstall"
    )
    $actionTitle = @{
        install = "Instalar"
        uninstall = "Remover"
    }[$action]

    while ($true) {
        $title = "$CategoryName - $actionTitle"
        $appMenuItems = Show-Menu -Title $title -Options $Apps
        $choice = Read-Host "Opção"

        if ($choice -eq '0') { break }
        if ($appMenuItems.ContainsKey([int]$choice)) {
            $appKey = $appMenuItems[[int]$choice]
            $app = $Apps[$appKey]
            
            if ($action -eq "uninstall") {
                $confirm = Read-Host "Tem certeza que deseja remover $($app.Name)? (Y/N)"
                if ($confirm -notmatch '^[Yy]$') { continue }
            }
            
            Invoke-WingetAction -Action $action -Id $app.Id -DisplayName $app.Name
        } else {
            Write-Host "❌ Opção inválida!" -ForegroundColor Red
            Start-Sleep -Seconds 1
        }
    }
}

function Update-AllPrograms {
    Clear-Host
    Write-Host "=== Atualizar Programas ===" -ForegroundColor Cyan
    Write-Host "`n📋 Verificando programas com atualizações disponíveis..." -ForegroundColor Yellow
    
    # Show available upgrades first
    try {
        winget upgrade
    } catch {
        Write-Host "❌ Não foi possível verificar as atualizações." -ForegroundColor Red
        Start-Sleep -Seconds 2
        return
    }

    $confirm = Read-Host "`nDeseja atualizar todos os programas? (Y/N)"
    if ($confirm -match '^[Yy]$') {
        Write-Host "`n⏳ Atualizando todos os programas..." -ForegroundColor Yellow
        Invoke-WingetAction -Action "install" -Id "winget" -DisplayName "Todos os Programas" # A bit of a hack for the message
        # The actual command to upgrade all
        Start-Process winget -ArgumentList "upgrade", "--all", "--silent", "--accept-source-agreements", "--accept-package-agreements" -Wait -NoNewWindow
        Write-Host "✅ Atualização de todos os programas concluída!" -ForegroundColor Green
    } else {
        Write-Host "Operação cancelada."
    }
    Start-Sleep -Seconds 2
}
#endregion

#region Menu and App Definitions
$categories = @{
    'Utils' = @{ Name='Utilitários'; Apps=@{
        'MSI.Afterburner' = @{ Name='MSI Afterburner' }
        'AMD.RyzenMaster' = @{ Name='Ryzen Master' }
        'Rem0o.FanControl' = @{ Name='FanControl' }
        'Skillbrains.Lightshot' = @{ Name='Lightshot' }
        'GitHub.cli' = @{ Name='Github' }
        'OpenJS.NodeJS.LTS' = @{ Name='NodeJS' }
    }}
    'Communication' = @{ Name='Comunicação'; Apps=@{
        'TeamSpeakSystems.TeamSpeak' = @{ Name='TeamSpeak' }
    }}
    'Games' = @{ Name='Jogos'; Apps=@{
        'com.faceit.app' = @{ Name='FACEIT' }
        'br.gamersclub.launcher' = @{ Name='GamersClub Launcher' }
    }}
}

$mainMenuActions = @{
    'Install' = @{ Name = 'Instalar Programas' }
    'Uninstall' = @{ Name = 'Remover Programas' }
    'Update' = @{ Name = 'Atualizar Todos os Programas' }
}
#endregion

#region Main Loop
while ($true) {
    $mainMenuItems = Show-Menu -Title "Menu Principal" -Options $mainMenuActions -ReturnOption "Sair"
    $mainChoice = Read-Host "Opção"

    if ($mainChoice -eq '0') { break }

    if (-not $mainMenuItems.ContainsKey([int]$mainChoice)) {
        Write-Host "❌ Opção inválida!" -ForegroundColor Red
        Start-Sleep 1
        continue
    }

    $actionKey = $mainMenuItems[[int]$mainChoice]

    switch ($actionKey) {
        'Update' {
            Update-AllPrograms
        }
        'Install' {
            $categoryMenuItems = Show-Menu -Title "Instalar - Selecione a Categoria" -Options $categories
            $categoryChoice = Read-Host "Opção"
            if ($categoryChoice -eq '0') { continue }
            if ($categoryMenuItems.ContainsKey([int]$categoryChoice)) {
                $categoryKey = $categoryMenuItems[[int]$categoryChoice]
                Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'install'
            }
        }
        'Uninstall' {
            $categoryMenuItems = Show-Menu -Title "Remover - Selecione a Categoria" -Options $categories
            $categoryChoice = Read-Host "Opção"
            if ($categoryChoice -eq '0') { continue }
            if ($categoryMenuItems.ContainsKey([int]$categoryChoice)) {
                $categoryKey = $categoryMenuItems[[int]$categoryChoice]
                Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'uninstall'
            }
        }
    }
}
#endregion
