@echo off
title SiteWindowsBug

echo ============================================
echo         SiteWindowsBug - Telemetry OFF
echo ============================================
echo.
echo Desativando telemetria do Windows...
echo.

powershell.exe -NoProfile -Command ^
  "Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' -Name 'AllowTelemetry' -Value 0 -Type DWord -Force"

if %ERRORLEVEL% equ 0 (
    echo [OK] AllowTelemetry definido como 0
) else (
    echo [ERRO] Falha ao aplicar -- execute como Administrador!
)

echo.
echo ============================================
echo Pressione qualquer tecla para sair...
pause > nul
