@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Requirements\BackupRestore.ps1"
pause
