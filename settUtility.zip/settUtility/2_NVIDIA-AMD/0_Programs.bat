@echo off
:: -- Garante que o .bat rode como administrador --
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permissao de administrador...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: -- Script PowerShell (relativo ao .bat) --
set "SCRIPT=%~dp00 - Programs\1_GpuPrograms.ps1"

if not exist "%SCRIPT%" (
    echo Script nao encontrado: "%SCRIPT%"
    pause
    exit /b
)

echo Executando 1_OtherPrograms.ps1 ...
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"

echo Concluido.
pause
