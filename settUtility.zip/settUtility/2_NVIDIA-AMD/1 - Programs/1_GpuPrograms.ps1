Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"
$ScriptDir = $PSScriptRoot

# ============================================================
#  LOGGING SYSTEM  -  clean ASCII prefixes, no unicode/emojis
# ============================================================
function Write-Log {
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [ValidateSet('Banner','Info','OK','Fail','Warn','Step','Ask')]
        [string]$Level = 'Info'
    )
    $style = @{
        'Banner' = @{ P=''; C='Cyan'      }
        'Info'   = @{ P='  >'; C='DarkGray' }
        'OK'     = @{ P='  +'; C='Green'    }
        'Fail'   = @{ P='  !'; C='Red'      }
        'Warn'   = @{ P='  *'; C='Yellow'   }
        'Step'   = @{ P='  ~'; C='Magenta'  }
        'Ask'    = @{ P='  ?'; C='White'    }
    }
    $s = $style[$Level]
    if ($Level -eq 'Banner') {
        Write-Host ''
        Write-Host '  ========================================' -ForegroundColor $s.C
        Write-Host "  $Message" -ForegroundColor $s.C
        Write-Host '  ========================================' -ForegroundColor $s.C
    }
    else {
        Write-Host "$($s.P) $Message" -ForegroundColor $s.C
    }
}

# ============================================================
#  DIRECT DOWNLOAD  -  baixa com progresso (%), suporta ZIP
# ============================================================
function Invoke-DirectDownload {
    param(
        [Parameter(Mandatory)]
        [string]$Url,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [string]$Arguments = '',
        [switch]$IsArchive
    )
    $tempDir = $env:TEMP
    $fileName = [System.IO.Path]::GetFileName(([uri]$Url).AbsolutePath)
    if ((-not $fileName) -or ($fileName -eq '')) {
        $ext = if ($IsArchive) { '.zip' } else { '.exe' }
        if ($Url -match '\.msi') { $ext = '.msi' }
        $fileName = "$DisplayName$ext" -replace ' ', ''
    }
    $outFile = Join-Path $tempDir $fileName

    Write-Log -Level Step -Message "Baixando $DisplayName..."
    Write-Log -Level Info -Message "URL: $Url"

    try {
        $ProgressPreference = 'Continue'
        Invoke-WebRequest -Uri $Url -OutFile $outFile -UseBasicParsing
        Write-Log -Level OK -Message "Download concluido: $outFile"
    }
    catch {
        Write-Log -Level Fail -Message "Falha no download: $_"
        return 1
    }

    if ($IsArchive) {
        Unblock-File -LiteralPath $outFile -ErrorAction SilentlyContinue
        $extractPath = Join-Path $tempDir "$DisplayName"
        if (Test-Path -LiteralPath $extractPath) {
            Remove-Item -LiteralPath $extractPath -Recurse -Force -ErrorAction SilentlyContinue
        }
        try {
            Write-Log -Level Step -Message "Extraindo $DisplayName..."
            Expand-Archive -LiteralPath $outFile -DestinationPath $extractPath -Force
            Write-Log -Level OK -Message "Extraido para: $extractPath"
            Write-Log -Level Step -Message "Abrindo pasta de $DisplayName..."
            Start-Process explorer.exe -ArgumentList $extractPath
        }
        catch {
            Write-Log -Level Fail -Message "Erro ao extrair: $_"
        }
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        return 0
    }

    Write-Log -Level Step -Message "Executando instalador de $DisplayName..."
    try {
        if ($Arguments) {
            $proc = Start-Process -FilePath $outFile -ArgumentList $Arguments -Wait -PassThru
        }
        else {
            $proc = Start-Process -FilePath $outFile -Wait -PassThru
        }
        if ($proc.ExitCode -eq 0) {
            Write-Log -Level OK -Message "$DisplayName instalado com sucesso!"
        }
        else {
            Write-Log -Level Warn -Message "$DisplayName finalizado (codigo $($proc.ExitCode))"
        }
    }
    catch {
        Write-Log -Level Fail -Message "Erro ao executar instalador: $_"
    }

    Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
    return 0
}

# ============================================================
#  SHOW-MENU  -  exibe menu interativo numerado
# ============================================================
function Show-Menu {
    param(
        [string]$Title,
        [System.Collections.IDictionary]$Options,
        [string]$ReturnOption = "Voltar"
    )
    Clear-Host
    Write-Log -Level Banner -Message $Title
    Write-Host ''
    $menuItems = @{}
    $i = 1
    foreach ($key in ($Options.Keys | Sort-Object)) {
        $menuItems[$i] = $key
        $label = if ($Options[$key].Name) { $Options[$key].Name } else { $key }
        Write-Host "    $i) $label" -ForegroundColor White
        $i++
    }
    Write-Host ''
    Write-Host "    0) $ReturnOption" -ForegroundColor DarkGray
    Write-Host ''
    return $menuItems
}

# ============================================================
#  INVOKE-WINGETACTION  -  instala/remove via winget
# ============================================================
function Invoke-WingetAction {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action,
        [Parameter(Mandatory)]
        [string]$Id,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [ValidateSet("winget", "msstore")]
        [string]$Source = "winget"
    )
    $actionVerb = @{ install = "Instalando"; uninstall = "Removendo" }[$Action]
    $actionPast  = @{ install = "instalado"; uninstall = "removido"  }[$Action]

    Write-Log -Level Step -Message "$actionVerb $DisplayName via winget..."

    $params = @($Action, "--id=$Id", "--silent")
    if ($Source -eq "msstore") {
        if ($Action -eq "install") {
            $params += "--source", "msstore", "--accept-package-agreements"
        }
    }
    else {
        if ($Action -eq "install") {
            $params += "--accept-source-agreements", "--accept-package-agreements"
        }
    }

    $AlreadyInstalledCodes = @(-1978335189, -1978335215)

    try {
        $process = Start-Process winget -ArgumentList $params -Wait -NoNewWindow -PassThru
        if ($process.ExitCode -eq 0) {
            Write-Log -Level OK -Message "$DisplayName $actionPast com sucesso!"
            return 0
        }
        elseif ($AlreadyInstalledCodes -contains $process.ExitCode) {
            Write-Log -Level OK -Message "$DisplayName ja estava $actionPast!"
            return 0
        }
        else {
            Write-Log -Level Fail -Message "Erro ao $actionVerb $DisplayName (winget: $($process.ExitCode))"
            return $process.ExitCode
        }
    }
    catch {
        Write-Log -Level Fail -Message "Falha critica ao executar winget para $DisplayName"
        Write-Log -Level Fail -Message $_.Exception.Message
        return -1
    }
}

# ============================================================
#  INVOKE-APPINSTALL  -  winget > direct download > browser
# ============================================================
function Invoke-AppInstall {
    param(
        [Parameter(Mandatory)]
        [string]$AppKey,
        [Parameter(Mandatory)]
        [hashtable]$App,
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $displayName = $App.Name

    # --- Uninstall ---
    if ($Action -eq "uninstall") {
        if ($App.ContainsKey('SkipWinget') -and $App.SkipWinget) {
            Write-Log -Level Info -Message "$displayName nao possui instalacao via winget."
            Write-Log -Level Info -Message "Remova manualmente em: Configuracoes > Aplicativos > Aplicativos instalados"
            Start-Sleep -Seconds 3
            return
        }
        $confirm = Read-Host "  ? Tem certeza que deseja remover $displayName? (Y/N)"
        if ($confirm -notmatch '^[Yy]$') { return }
        $source = if ($App.ContainsKey('Source')) { $App.Source } else { "winget" }
        $null = Invoke-WingetAction -Action $Action -Id $AppKey -DisplayName $displayName -Source $source
        return
    }

    # --- Install ---
    $source = if ($App.ContainsKey('Source')) { $App.Source } else { "winget" }
    $skipWinget = $App.ContainsKey('SkipWinget') -and $App.SkipWinget

    # Step 1: Try winget (if available)
    if (-not $skipWinget) {
        $wingetResult = Invoke-WingetAction -Action install -Id $AppKey -DisplayName $displayName -Source $source
        if ($wingetResult -eq 0) {
            Start-Sleep -Seconds 1
            return
        }
        # Winget falhou ou usuario cancelou -- volta ao menu
        return
    }

    # Step 2: Try direct download (skipWinget apps only)
    if ($App.ContainsKey('DirectUrl')) {
        $silentArgs = if ($App.ContainsKey('SilentArgs')) { $App.SilentArgs } else { '' }
        $isZip = $App.ContainsKey('IsArchive') -and $App.IsArchive
        $dlResult = Invoke-DirectDownload -Url $App.DirectUrl -DisplayName $displayName -Arguments $silentArgs -IsArchive:$isZip
        if ($dlResult -eq 0) {
            Start-Sleep -Seconds 1
            return
        }
        Write-Log -Level Warn -Message "Download direto falhou. Abrindo navegador..."
    }

    # Step 3: Last resort - open browser
    $fallbackUrl = if ($App.ContainsKey('FallbackUrl')) { $App.FallbackUrl }
                   elseif ($App.ContainsKey('StoreLink')) { $App.StoreLink }
                   else { $null }

    if ($fallbackUrl) {
        Write-Log -Level Step -Message "Abrindo $fallbackUrl no navegador..."
        Start-Sleep -Seconds 1
        Start-Process $fallbackUrl
        Write-Log -Level OK -Message "Pagina de download aberta no navegador."
    }
    else {
        Write-Log -Level Fail -Message "Nao foi possivel instalar $displayName (sem URL de fallback)."
    }

    Start-Sleep -Seconds 3
}

# ============================================================
#  HANDLE-APPSELECTION  -  menu de selecao de apps
# ============================================================
function Handle-AppSelection {
    param(
        [Parameter(Mandatory)]
        [string]$CategoryName,
        [Parameter(Mandatory)]
        [hashtable]$Apps,
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $actionTitle = @{ install = "Instalar"; uninstall = "Remover" }[$Action]

    while ($true) {
        $appMenuItems = Show-Menu -Title "$CategoryName - $actionTitle" -Options $Apps
        $choice = Read-Host "  ? Escolha uma opcao"

        if ($choice -eq '0') { break }

        if ((-not $choice) -or (-not ($appMenuItems.ContainsKey([int]$choice)))) {
            Write-Log -Level Fail -Message "Opcao invalida!"
            Start-Sleep -Seconds 1
            continue
        }

        $appKey = $appMenuItems[[int]$choice]
        $app = $Apps[$appKey]

        Invoke-AppInstall -AppKey $appKey -App $app -Action $Action
    }
}

# ============================================================
#  APP DEFINITIONS  -  3 categorias: Utilitarios, AMD, NVIDIA
# ============================================================
$categories = @{
    'Utils' = @{
        Name = 'Utilitarios'
        Apps = @{
            'Guru3D.MSIAfterburner' = @{
                Name        = 'MSI Afterburner'
                FallbackUrl = 'https://www.msi.com/Landing/afterburner/graphics-cards'
            }
            'CPUID.HWMonitor' = @{
                Name        = 'HWMonitor'
                FallbackUrl = 'https://www.cpuid.com/softwares/hwmonitor.html'
            }
            'TechPowerUp.GPU-Z' = @{
                Name        = 'GPU-Z'
                FallbackUrl = 'https://www.techpowerup.com/download/techpowerup-gpu-z/'
            }
            'Wagnardsoft.DisplayDriverUninstaller' = @{
                Name        = 'DDU'
                FallbackUrl = 'https://www.wagnardsoft.com/display-driver-uninstaller-DDU-'
            }
        }
    }

    'AMD' = @{
        Name = 'AMD'
        Apps = @{
            'RadeonSoftwareSlimmer' = @{
                Name        = 'RadeonSoftwareSlimmer'
                SkipWinget  = $true
                FallbackUrl = 'https://github.com/GSDragoon/RadeonSoftwareSlimmer/releases/latest'
            }
            'MorePowerTool' = @{
                Name        = 'MorePowerTool'
                SkipWinget  = $true
                FallbackUrl = 'https://www.igorslab.de/en/red-bios-rebellion-team/2/#Downloads'
            }
        }
    }

    'NVIDIA' = @{
        Name = 'NVIDIA'
        Apps = @{
            'TechPowerUp.NVCleanstall' = @{
                Name        = 'NVCleanstall'
                FallbackUrl = 'https://www.techpowerup.com/download/techpowerup-nvcleanstall/'
            }
            'NvidiaProfileInspector' = @{
                Name        = 'NvidiaProfileInspector'
                SkipWinget  = $true
                DirectUrl   = 'https://github.com/Orbmu2k/nvidiaProfileInspector/releases/latest/download/nvidiaProfileInspector.zip'
                IsArchive   = $true
                FallbackUrl = 'https://github.com/Orbmu2k/nvidiaProfileInspector/releases/latest'
            }
        }
    }
}

# Main menu actions
$mainMenuActions = @{
    'Install'   = @{ Name = 'Instalar Programas' }
    'Uninstall' = @{ Name = 'Remover Programas' }
}

# ============================================================
#  MAIN LOOP
# ============================================================
while ($true) {
    $mainMenuItems = Show-Menu -Title "Menu Principal" -Options $mainMenuActions -ReturnOption "Sair"
    $mainChoice = Read-Host "  ? Escolha uma opcao"

    if ($mainChoice -eq '0') { break }

    if ((-not $mainChoice) -or (-not ($mainMenuItems.ContainsKey([int]$mainChoice)))) {
        Write-Log -Level Fail -Message "Opcao invalida!"
        Start-Sleep 1
        continue
    }

    $actionKey = $mainMenuItems[[int]$mainChoice]
    $actionTitle = @{ Install = 'Instalar'; Uninstall = 'Remover' }[$actionKey]

    # Show categories
    $categoryMenuItems = Show-Menu -Title "$actionTitle - Selecione a Categoria" -Options $categories
    $categoryChoice = Read-Host "  ? Escolha uma opcao"

    if ($categoryChoice -eq '0') { continue }

    if ((-not $categoryChoice) -or (-not ($categoryMenuItems.ContainsKey([int]$categoryChoice)))) {
        Write-Log -Level Fail -Message "Opcao invalida!"
        Start-Sleep 1
        continue
    }

    $categoryKey = $categoryMenuItems[[int]$categoryChoice]
    Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action $actionKey.ToLower()
}
