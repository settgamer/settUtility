Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"
$ScriptDir = $PSScriptRoot

# ============================================================
#  LOGGING SYSTEM  -  clean ASCII prefixes, no unicode/emojis
# ============================================================
function Write-Log {
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [ValidateSet('Banner','Info','OK','Fail','Warn','Step','Ask')]
        [string]$Level = 'Info'
    )
    $style = @{
        'Banner' = @{ P=''; C='Cyan'      }
        'Info'   = @{ P='  >'; C='DarkGray' }
        'OK'     = @{ P='  +'; C='Green'    }
        'Fail'   = @{ P='  !'; C='Red'      }
        'Warn'   = @{ P='  *'; C='Yellow'   }
        'Step'   = @{ P='  ~'; C='Magenta'  }
        'Ask'    = @{ P='  ?'; C='White'    }
    }
    $s = $style[$Level]
    if ($Level -eq 'Banner') {
        Write-Host ''
        Write-Host '  ========================================' -ForegroundColor $s.C
        Write-Host "  $Message" -ForegroundColor $s.C
        Write-Host '  ========================================' -ForegroundColor $s.C
    }
    else {
        Write-Host "$($s.P) $Message" -ForegroundColor $s.C
    }
}

# ============================================================
#  DIRECT DOWNLOAD  -  baixa o instalador e roda, sem browser
# ============================================================
function Invoke-DirectDownload {
    param(
        [Parameter(Mandatory)]
        [string]$Url,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [string]$Arguments = ''
    )
    $tempDir = $env:TEMP
    $fileName = [System.IO.Path]::GetFileName(([uri]$Url).AbsolutePath)
    if ((-not $fileName) -or ($fileName -eq '')) {
        $ext = '.exe'
        if ($Url -match '\.zip')       { $ext = '.zip' }
        elseif ($Url -match '\.msi')   { $ext = '.msi' }
        $fileName = "$DisplayName$ext" -replace ' ', ''
    }
    $outFile = Join-Path $tempDir $fileName

    Write-Log -Level Step -Message "Baixando $DisplayName..."
    Write-Log -Level Info -Message "URL: $Url"

    try {
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $Url -OutFile $outFile -UseBasicParsing
        Write-Log -Level OK -Message "Download concluido: $outFile"
    }
    catch {
        Write-Log -Level Fail -Message "Falha no download: $_"
        return 1
    }

    Write-Log -Level Step -Message "Executando instalador de $DisplayName..."
    try {
        if ($Arguments) {
            $proc = Start-Process -FilePath $outFile -ArgumentList $Arguments -Wait -PassThru
        }
        else {
            $proc = Start-Process -FilePath $outFile -Wait -PassThru
        }
        if ($proc.ExitCode -eq 0) {
            Write-Log -Level OK -Message "$DisplayName instalado com sucesso!"
        }
        else {
            Write-Log -Level Warn -Message "$DisplayName finalizado (codigo $($proc.ExitCode))"
        }
    }
    catch {
        Write-Log -Level Fail -Message "Erro ao executar instalador: $_"
    }

    Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
    return 0
}

# ============================================================
#  SHOW-MENU  -  exibe menu interativo numerado
# ============================================================
function Show-Menu {
    param(
        [string]$Title,
        [System.Collections.IDictionary]$Options,
        [string]$ReturnOption = "Voltar"
    )
    Clear-Host
    Write-Log -Level Banner -Message $Title
    Write-Host ''
    $menuItems = @{}
    $i = 1
    foreach ($key in ($Options.Keys | Sort-Object)) {
        $menuItems[$i] = $key
        $label = if ($Options[$key].Name) { $Options[$key].Name } else { $key }
        Write-Host "    $i) $label" -ForegroundColor White
        $i++
    }
    Write-Host ''
    Write-Host "    0) $ReturnOption" -ForegroundColor DarkGray
    Write-Host ''
    return $menuItems
}

# ============================================================
#  INVOKE-WINGETACTION  -  instala/remove via winget
# ============================================================
function Invoke-WingetAction {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action,
        [Parameter(Mandatory)]
        [string]$Id,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [ValidateSet("winget", "msstore")]
        [string]$Source = "winget"
    )
    $actionVerb = @{ install = "Instalando"; uninstall = "Removendo" }[$Action]
    $actionPast  = @{ install = "instalado"; uninstall = "removido"  }[$Action]

    Write-Log -Level Step -Message "$actionVerb $DisplayName via winget..."

    $params = @($Action, "--id=$Id", "--silent")
    if ($Source -eq "msstore") {
        if ($Action -eq "install") {
            $params += "--source", "msstore", "--accept-package-agreements"
        }
    }
    else {
        if ($Action -eq "install") {
            $params += "--accept-source-agreements", "--accept-package-agreements"
        }
    }

    $AlreadyInstalledCodes = @(-1978335189, -1978335215)

    try {
        $process = Start-Process winget -ArgumentList $params -Wait -NoNewWindow -PassThru
        if ($process.ExitCode -eq 0) {
            Write-Log -Level OK -Message "$DisplayName $actionPast com sucesso!"
            return 0
        }
        elseif ($AlreadyInstalledCodes -contains $process.ExitCode) {
            Write-Log -Level OK -Message "$DisplayName ja estava instalado!"
            return 0
        }
        else {
            Write-Log -Level Fail -Message "Erro ao $actionVerb $DisplayName (winget: $($process.ExitCode))"
            return $process.ExitCode
        }
    }
    catch {
        Write-Log -Level Fail -Message "Falha critica ao executar winget para $DisplayName"
        Write-Log -Level Fail -Message $_.Exception.Message
        return -1
    }
}

# ============================================================
#  INVOKE-APPINSTALL  -  tenta winget, fallback download direto
# ============================================================
function Invoke-AppInstall {
    param(
        [Parameter(Mandatory)]
        [string]$AppKey,
        [Parameter(Mandatory)]
        [hashtable]$App,
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $displayName = $App.Name

    if ($Action -eq "uninstall") {
        $confirm = Read-Host "  ? Tem certeza que deseja remover $displayName? (Y/N)"
        if ($confirm -notmatch '^[Yy]$') { return }
        $source = if ($App.ContainsKey('Source')) { $App.Source } else { "winget" }
        $null = Invoke-WingetAction -Action $Action -Id $AppKey -DisplayName $displayName -Source $source
        return
    }

    $source = if ($App.ContainsKey('Source')) { $App.Source } else { "winget" }

    $wingetResult = Invoke-WingetAction -Action install -Id $AppKey -DisplayName $displayName -Source $source

    if ($wingetResult -eq 0) {
        if ($App.ContainsKey('SetupLinks')) {
            Start-Sleep -Seconds 1
            Write-Log -Level Step -Message "Abrindo links de configuracao para $displayName..."
            foreach ($link in $App.SetupLinks) {
                Write-Log -Level Info -Message " -> $link"
                Start-Process $link
            }
            Start-Sleep -Seconds 2
        }
        return
    }

    if ($App.ContainsKey('DirectUrl')) {
        Write-Log -Level Warn -Message "Winget falhou. Tentando download direto..."
        $silentArgs = if ($App.ContainsKey('SilentArgs')) { $App.SilentArgs } else { '' }
        $dlResult = Invoke-DirectDownload -Url $App.DirectUrl -DisplayName $displayName -Arguments $silentArgs
        if ($dlResult -eq 0) {
            Start-Sleep -Seconds 1
            return
        }
        Write-Log -Level Warn -Message "Download direto falhou. Abrindo navegador..."
    }

    $fallbackUrl = if ($App.ContainsKey('FallbackUrl')) { $App.FallbackUrl }
                   elseif ($App.ContainsKey('StoreLink')) { $App.StoreLink }
                   else { $null }

    if ($fallbackUrl) {
        Write-Log -Level Step -Message "Abrindo $fallbackUrl no navegador..."
        Start-Sleep -Seconds 1
        Start-Process $fallbackUrl
        Write-Log -Level OK -Message "Pagina de download aberta no navegador."
    }
    else {
        Write-Log -Level Fail -Message "Nao foi possivel instalar $displayName (sem URL de fallback)."
    }

    Start-Sleep -Seconds 3
}

# ============================================================
#  HANDLE-APPSELECTION  -  menu de selecao de apps
# ============================================================
function Handle-AppSelection {
    param(
        [Parameter(Mandatory)]
        [string]$CategoryName,
        [Parameter(Mandatory)]
        [hashtable]$Apps,
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $actionTitle = @{ install = "Instalar"; uninstall = "Remover" }[$Action]

    while ($true) {
        $appMenuItems = Show-Menu -Title "$CategoryName - $actionTitle" -Options $Apps
        $choice = Read-Host "  ? Escolha uma opcao"

        if ($choice -eq '0') { break }

        if ((-not $choice) -or (-not ($appMenuItems.ContainsKey([int]$choice)))) {
            Write-Log -Level Fail -Message "Opcao invalida!"
            Start-Sleep -Seconds 1
            continue
        }

        $appKey = $appMenuItems[[int]$choice]
        $app = $Apps[$appKey]

        Invoke-AppInstall -AppKey $appKey -App $app -Action $Action
    }
}

# ============================================================
#  APP DEFINITIONS
# ============================================================
$categories = @{
    'AMD' = @{
        Name = 'AMD'
        Apps = @{
            'AMD.RyzenMaster' = @{
                Name        = 'Ryzen Master'
                FallbackUrl = 'https://www.amd.com/en/products/software/ryzen-master.html'
            }
        }
    }

    'Intel' = @{
        Name = 'Intel'
        Apps = @{
            'Intel.ExtremeTuningUtility' = @{
                Name        = 'Extreme Tuning Utility'
                FallbackUrl = 'https://www.intel.com/content/www/us/en/download/17881/intel-extreme-tuning-utility-intel-xtu.html'
            }
            'TechPowerUp.ThrottleStop' = @{
                Name        = 'ThrottleStop'
                FallbackUrl = 'https://www.techpowerup.com/download/techpowerup-throttlestop/'
            }
        }
    }

    'Utilitarios' = @{
        Name = 'Utilitarios'
        Apps = @{
            'Rem0o.FanControl' = @{
                Name        = 'FanControl'
                FallbackUrl = 'https://getfancontrol.com/'
            }
        }
    }
}

# ============================================================
#  MAIN MENU ACTIONS
# ============================================================
$mainMenuActions = @{
    'Install'   = @{ Name = 'Instalar Programas' }
    'Uninstall' = @{ Name = 'Remover Programas' }
}

# ============================================================
#  MAIN LOOP
# ============================================================
while ($true) {
    $mainMenuItems = Show-Menu -Title "Menu Principal" -Options $mainMenuActions -ReturnOption "Sair"
    $mainChoice = Read-Host "  ? Escolha uma opcao"

    if ($mainChoice -eq '0') { break }

    if ((-not $mainChoice) -or (-not ($mainMenuItems.ContainsKey([int]$mainChoice)))) {
        Write-Log -Level Fail -Message "Opcao invalida!"
        Start-Sleep 1
        continue
    }

    $actionKey = $mainMenuItems[[int]$mainChoice]

    switch ($actionKey) {
        'Install' {
            $categoryMenuItems = Show-Menu -Title "Instalar - Selecione a Categoria" -Options $categories
            $categoryChoice = Read-Host "  ? Escolha uma opcao"
            if ($categoryChoice -eq '0') { continue }
            if ((-not $categoryChoice) -or (-not ($categoryMenuItems.ContainsKey([int]$categoryChoice)))) {
                Write-Log -Level Fail -Message "Opcao invalida!"
                Start-Sleep 1
                continue
            }
            $categoryKey = $categoryMenuItems[[int]$categoryChoice]
            Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'install'
        }

        'Uninstall' {
            $categoryMenuItems = Show-Menu -Title "Remover - Selecione a Categoria" -Options $categories
            $categoryChoice = Read-Host "  ? Escolha uma opcao"
            if ($categoryChoice -eq '0') { continue }
            if ((-not $categoryChoice) -or (-not ($categoryMenuItems.ContainsKey([int]$categoryChoice)))) {
                Write-Log -Level Fail -Message "Opcao invalida!"
                Start-Sleep 1
                continue
            }
            $categoryKey = $categoryMenuItems[[int]$categoryChoice]
            Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'uninstall'
        }
    }
}
