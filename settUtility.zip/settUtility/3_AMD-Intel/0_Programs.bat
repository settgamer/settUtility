@echo off
set "SCRIPT_DIR=%~dp0"
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%0 - Programs\1_CPUPrograms.ps1"
