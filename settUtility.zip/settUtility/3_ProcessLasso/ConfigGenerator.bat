@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Requirements\ConfigGenerator.ps1"
pause
