Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Animated {
    param(
        [string]$Text = "",
        [string]$Color = "White",
        [int]$DelayMs = 180
    )
    if ($Text -eq "") {
        Write-Host ""
        Start-Sleep -Milliseconds 100
    } else {
        Write-Host $Text -ForegroundColor $Color
        Start-Sleep -Milliseconds $DelayMs
    }
}

try {
    $cpuInfo = Get-CimInstance Win32_Processor
    if (-not $cpuInfo) {
        Write-Animated ("=" * 60) -Color DarkGray
        Write-Animated "  [X] Failed to detect CPU via CIM/WMI." -Color Red
        Write-Animated "  Make sure you are running on Windows with admin privileges." -Color Red
        Write-Animated ("=" * 60) -Color DarkGray
        exit 1
    }

    $logicalCores = ($cpuInfo | ForEach-Object { $_.NumberOfLogicalProcessors } | Measure-Object -Sum).Sum
    if ($logicalCores -le 1) {
        Write-Animated ("=" * 60) -Color DarkGray
        Write-Animated "  [X] Only $logicalCores logical core detected." -Color Red
        Write-Animated "  CPU affinity optimization requires at least 2 cores." -Color Red
        Write-Animated ("=" * 60) -Color DarkGray
        exit 1
    }

    $lastCore = $logicalCores - 1
    $affinity = "1-$lastCore"
    $cpuModel = $cpuInfo[0].Name.Trim()
    $physicalCores = ($cpuInfo | ForEach-Object { $_.NumberOfCores } | Measure-Object -Sum).Sum

    $sep = "=" * 60
    $sub = "-" * 60

    Write-Animated $sep -Color DarkGray
    Write-Animated "  Process Lasso Config Generator" -Color Yellow
    Write-Animated $sep -Color DarkGray
    Write-Animated "" -DelayMs 100
    Write-Animated "  [*] SYSTEM DETECTION" -Color Cyan
    Write-Animated "  $sub" -Color DarkGray
    Write-Animated "  CPU Model       : $cpuModel" -Color White
    Write-Animated "  Physical Cores  : $physicalCores" -Color White
    Write-Animated "  Logical Cores   : $logicalCores (SMT/HT)" -Color White
    Write-Animated "  Core Range      : 0 .. $lastCore" -Color White
    Write-Animated "  Game Affinity   : $affinity (core 0 reserved for system)" -Color White
    Write-Animated "" -DelayMs 100
    Write-Animated "  [*] GENERATING RULES" -Color Cyan
    Write-Animated "  $sub" -Color DarkGray

$json = @"
{
  "`$id": "https://bitsum.com/json-schemas/2026-01-17-00/processlasso.schema.json",
  "`$schema": "https://json-schema.org/draft/2020-12/schema",
  "cpuModel": "$cpuModel",
  "description": "Rulesets for Process Lasso",
  "title": "Process Lasso Rules",
  "appPowerProfileRuleOrder": [
    "powershell.exe",
    "deadlock.exe",
    "aimlab_tb.exe",
    "cod.exe",
    "cs2.exe",
    "csgo.exe",
    "fortniteclient-win64-shipping.exe",
    "fpsaimtrainer-win64-shipping.exe",
    "overwatch.exe",
    "r5apex.exe",
    "rust.exe",
    "valorant-win64-shipping.exe"
  ],
  "cpuAffinityRuleOrder": [
    "deadlock.exe",
    "cs2.exe",
    "aimlab_tb.exe",
    "cod.exe",
    "csgo.exe",
    "fortniteclient-win64-shipping.exe",
    "fpsaimtrainer-win64-shipping.exe",
    "overwatch.exe",
    "r5apex.exe",
    "rust.exe"
  ],
  "gpuAdapterPreferenceRuleOrder": [
    "c:\\program files (x86)\\steam\\steamapps\\common\\counter-strike global offensive\\game\\bin\\win64\\cs2.exe",
    "c:\\program files\\bluestacks_nxt\\hd-player.exe",
    "c:\\program files\\bluestacks_nxt\\hd-glcheck.exe",
    "c:\\program files\\ldplayer9box\\ld9boxheadless.exe",
    "c:\\ldplayer\\ldplayer9\\dnplayer.exe",
    "aimlab_tb.exe",
    "cod.exe",
    "cs2.exe",
    "csgo.exe",
    "deadlock.exe",
    "fortniteclient-win64-shipping.exe",
    "fpsaimtrainer-win64-shipping.exe",
    "overwatch.exe",
    "r5apex.exe",
    "rust.exe",
    "valorant-win64-shipping.exe"
  ],
  "gpuPriorityClassRuleOrder": [
    "lightshot.exe",
    "vibrancegui.exe",
    "fdm.exe",
    "deadlock.exe",
    "cs2.exe",
    "valorant-win64-shipping.exe",
    "oo2reck.exe",
    "tabtip.exe",
    "yourphone.exe",
    "skypeapp.exe",
    "skypebackgroundhost.exe",
    "newsandinterests.exe",
    "cortana.exe",
    "hxtsr.exe",
    "hxcalendarappimm.exe",
    "systemsettings.exe",
    "officeclicktorun.exe",
    "googleupdate.exe",
    "braveupdate.exe",
    "adobearm.exe",
    "adobeupdateservice.exe",
    "adobeipcbroker.exe",
    "agsservice.exe",
    "spoolsv.exe",
    "lockapp.exe"
  ],
  "ioPriorityClassRuleOrder": [
    "csrss.exe",
    "dwm.exe",
    "csgo.exe",
    "aimlab_tb.exe",
    "rust.exe",
    "valorant-win64-shipping.exe",
    "fortniteclient-win64-shipping.exe",
    "r5apex.exe",
    "fpsaimtrainer-win64-shipping.exe",
    "overwatch.exe",
    "cod.exe",
    "cs2.exe",
    "explorer.exe",
    "audiodg.exe",
    "agent.exe",
    "battle.net.exe",
    "conhost.exe",
    "ctfmon.exe",
    "discord.exe",
    "dllhost.exe",
    "epicgameslauncher.exe",
    "epicwebhelper.exe",
    "fontdrvhost.exe",
    "lsass.exe",
    "nvcontainer.exe",
    "nvdisplay.container.exe",
    "nvidia geforce experience.exe",
    "nvidia share.exe",
    "nvidia web helper.exe",
    "nvsphelper64.exe",
    "opera.exe",
    "chrome.exe",
    "brave.exe",
    "msedge.exe",
    "opera_crashreporter.exe",
    "riotclientcrashhandler.exe",
    "riotclientservices.exe",
    "riotclientux.exe",
    "riotclientuxrender.exe",
    "rundll32.exe (\"c:\\program files\\nvidia corporation\\nvstreamsrv\\rxdiag.dll\" rxdiagsetruntimemessagepump)",
    "runtimebroker.exe",
    "searchapp.exe",
    "settimerresolutionservice.exe",
    "sgrmbroker.exe",
    "sihost.exe",
    "spotify.exe",
    "srvstub.exe",
    "startmenuexperiencehost.exe",
    "steam.exe",
    "steamwebhelper.exe",
    "svchost.exe (appmodel -p)",
    "svchost.exe (dcomlaunch -p)",
    "svchost.exe (localservice -p)",
    "svchost.exe (localservicenetworkrestricted -p)",
    "svchost.exe (localservicenetworkrestricted)",
    "svchost.exe (localservicenonetwork -p)",
    "svchost.exe (localservicenonetworkfirewall -p)",
    "svchost.exe (localsystemnetworkrestricted -p)",
    "svchost.exe (netsvcs -p)",
    "svchost.exe (unistacksvcgroup)",
    "textinputhost.exe",
    "upc.exe",
    "uplaywebcore.exe",
    "vgtray.exe",
    "winexp.exe",
    "winlogon.exe",
    "vgc.exe",
    "taskhostw.exe",
    "backgroundtaskhost.exe",
    "smartscreen.exe",
    "msteams.exe",
    "onedrive.exe",
    "zen.exe",
    "arc.exe",
    "firefox.exe",
    "oo2reck.exe",
    "searchfilterhost.exe",
    "searchindexer.exe",
    "searchprotocolhost.exe",
    "wmiprvse.exe",
    "tabtip.exe",
    "yourphone.exe",
    "skypeapp.exe",
    "skypebackgroundhost.exe",
    "lockapp.exe",
    "newsandinterests.exe",
    "cortana.exe",
    "hxtsr.exe",
    "hxcalendarappimm.exe",
    "systemsettings.exe",
    "officeclicktorun.exe",
    "googleupdate.exe",
    "braveupdate.exe",
    "adobearm.exe",
    "adobeupdateservice.exe",
    "adobeipcbroker.exe",
    "agsservice.exe",
    "spoolsv.exe",
    "deadlock.exe",
    "crossdeviceservice.exe",
    "fdm.exe",
    "gamebar.exe",
    "gamebarftserver.exe",
    "microsoftedgeupdate.exe",
    "mousocoreworker.exe",
    "msedgewebview2.exe",
    "vibrancegui.exe",
    "lightshot.exe",
    "widgets.exe"
  ],
  "memoryPriorityRuleOrder": [
    "oo2reck.exe"
  ],
  "priorityBoostRuleOrder": [
    "cs2.exe",
    "valorant-win64-shipping.exe"
  ],
  "priorityClassRuleOrder": [
    "lightshot.exe",
    "vibrancegui.exe",
    "fdm.exe",
    "msedgewebview2.exe",
    "deadlock.exe",
    "brave.exe",
    "csrss.exe",
    "dwm.exe",
    "aimlab_tb.exe",
    "csgo.exe",
    "rust.exe",
    "valorant-win64-shipping.exe",
    "fortniteclient-win64-shipping.exe",
    "r5apex.exe",
    "fpsaimtrainer-win64-shipping.exe",
    "overwatch.exe",
    "cod.exe",
    "cs2.exe",
    "explorer.exe",
    "audiodg.exe",
    "agent.exe",
    "battle.net.exe",
    "conhost.exe",
    "ctfmon.exe",
    "discord.exe",
    "dllhost.exe",
    "epicgameslauncher.exe",
    "epicwebhelper.exe",
    "fontdrvhost.exe",
    "lsass.exe",
    "opera_crashreporter.exe",
    "riotclientcrashhandler.exe",
    "riotclientservices.exe",
    "riotclientux.exe",
    "riotclientuxrender.exe",
    "rundll32.exe (\"c:\\program files\\nvidia corporation\\nvstreamsrv\\rxdiag.dll\" rxdiagsetruntimemessagepump)",
    "runtimebroker.exe",
    "searchapp.exe",
    "settimerresolutionservice.exe",
    "sgrmbroker.exe",
    "sihost.exe",
    "spotify.exe",
    "srvstub.exe",
    "startmenuexperiencehost.exe",
    "steam.exe",
    "steamwebhelper.exe",
    "svchost.exe (appmodel -p)",
    "svchost.exe (dcomlaunch -p)",
    "svchost.exe (localservice -p)",
    "svchost.exe (localservicenetworkrestricted -p)",
    "svchost.exe (localservicenetworkrestricted)",
    "svchost.exe (localservicenonetwork -p)",
    "svchost.exe (localservicenonetworkfirewall -p)",
    "svchost.exe (localsystemnetworkrestricted -p)",
    "svchost.exe (netsvcs -p)",
    "svchost.exe (unistacksvcgroup)",
    "textinputhost.exe",
    "upc.exe",
    "uplaywebcore.exe",
    "vgtray.exe",
    "winexp.exe",
    "winlogon.exe",
    "opera.exe",
    "chrome.exe",
    "msedge.exe",
    "nvcontainer.exe",
    "nvdisplay.container.exe",
    "nvidia geforce experience.exe",
    "nvidia share.exe",
    "nvidia web helper.exe",
    "nvsphelper64.exe",
    "vgc.exe",
    "taskhostw.exe",
    "backgroundtaskhost.exe",
    "smartscreen.exe",
    "msteams.exe",
    "onedrive.exe",
    "zen.exe",
    "arc.exe",
    "firefox.exe",
    "oo2reck.exe",
    "searchfilterhost.exe",
    "searchindexer.exe",
    "searchprotocolhost.exe",
    "wmiprvse.exe",
    "crossdeviceservice.exe",
    "gamebar.exe",
    "gamebarftserver.exe",
    "microsoftedgeupdate.exe",
    "mousocoreworker.exe",
    "widgets.exe",
    "tabtip.exe",
    "yourphone.exe",
    "skypeapp.exe",
    "skypebackgroundhost.exe",
    "lockapp.exe",
    "newsandinterests.exe",
    "cortana.exe",
    "hxtsr.exe",
    "hxcalendarappimm.exe",
    "systemsettings.exe",
    "officeclicktorun.exe",
    "googleupdate.exe",
    "braveupdate.exe",
    "adobearm.exe",
    "adobeupdateservice.exe",
    "adobeipcbroker.exe",
    "agsservice.exe",
    "spoolsv.exe"
  ],
  "ruleSets": [
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "adobearm.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "adobeipcbroker.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "adobeupdateservice.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "agent.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "agsservice.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "aimlab_tb.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "arc.exe"
    },
    {
      "ioPriority": "Normal",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "audiodg.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "backgroundtaskhost.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "battle.net.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "brave.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "braveupdate.exe"
    },
    {
      "gpuAdapterPreference": "High performance",
      "processName": "c:\\ldplayer\\ldplayer9\\dnplayer.exe"
    },
    {
      "gpuAdapterPreference": "High performance",
      "processName": "c:\\program files (x86)\\steam\\steamapps\\common\\counter-strike global offensive\\game\\bin\\win64\\cs2.exe"
    },
    {
      "gpuAdapterPreference": "High performance",
      "processName": "c:\\program files\\bluestacks_nxt\\hd-glcheck.exe"
    },
    {
      "gpuAdapterPreference": "High performance",
      "processName": "c:\\program files\\bluestacks_nxt\\hd-player.exe"
    },
    {
      "gpuAdapterPreference": "High performance",
      "processName": "c:\\program files\\ldplayer9box\\ld9boxheadless.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "chrome.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "cod.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "conhost.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "cortana.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "crossdeviceservice.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "gpuPriority": "High",
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "cs2.exe",
      "threadPriorityBoosts": "on",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "csgo.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Normal",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "csrss.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "ctfmon.exe"
    },
    {
      "appPowerProfile": "SETT'S PowerPlan",
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "gpuPriority": "High",
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "deadlock.exe",
      "smarttrimExclusion": true
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "discord.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "dllhost.exe"
    },
    {
      "ioPriority": "Normal",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "dwm.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "epicgameslauncher.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "epicwebhelper.exe"
    },
    {
      "ioPriority": "Normal",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Above normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "explorer.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "fdm.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "firefox.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "fontdrvhost.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "fortniteclient-win64-shipping.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "fpsaimtrainer-win64-shipping.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "gamebar.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "gamebarftserver.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "googleupdate.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "hxcalendarappimm.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "hxtsr.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "lightshot.exe"
    },
    {
      "gpuPriority": "Low",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Low",
      "priorityClassEnforcedByRegistry": false,
      "processName": "lockapp.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "lsass.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "microsoftedgeupdate.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "mousocoreworker.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "msedge.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "msedgewebview2.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "msteams.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "newsandinterests.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "nvcontainer.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "nvdisplay.container.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "nvidia geforce experience.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "nvidia share.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "nvidia web helper.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "nvsphelper64.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "officeclicktorun.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "onedrive.exe"
    },
    {
      "gpuPriority": "Normal",
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "memoryPriority": "Low",
      "memoryPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "oo2reck.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "opera.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "opera_crashreporter.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "overwatch.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "appPowerProfile": "SETT'S PowerPlan",
      "processName": "powershell.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "r5apex.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "riotclientcrashhandler.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "riotclientservices.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "riotclientux.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "riotclientuxrender.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "rundll32.exe (\"c:\\program files\\nvidia corporation\\nvstreamsrv\\rxdiag.dll\" rxdiagsetruntimemessagepump)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "runtimebroker.exe"
    },
    {
      "cpuAffinity": "$affinity",
      "cpuAffinityDelay": 0,
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "rust.exe",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "searchapp.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "searchfilterhost.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "searchindexer.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "searchprotocolhost.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "settimerresolutionservice.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "sgrmbroker.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "sihost.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "skypeapp.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "skypebackgroundhost.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "smartscreen.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "spoolsv.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "spotify.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "srvstub.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "startmenuexperiencehost.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "steam.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "steamwebhelper.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (appmodel -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (dcomlaunch -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (localservice -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (localservicenetworkrestricted -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (localservicenetworkrestricted)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (localservicenonetwork -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (localservicenonetworkfirewall -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (localsystemnetworkrestricted -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (netsvcs -p)"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "svchost.exe (unistacksvcgroup)"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "systemsettings.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "tabtip.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "taskhostw.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "textinputhost.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "upc.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "uplaywebcore.exe"
    },
    {
      "gpuPriority": "High",
      "ioPriority": "High",
      "ioPriorityEnforcedByRegistry": false,
      "performanceMode": true,
      "priorityClass": "High",
      "priorityClassEnforcedByRegistry": false,
      "processName": "valorant-win64-shipping.exe",
      "threadPriorityBoosts": "on",
      "smarttrimExclusion": true,
      "appPowerProfile": "SETT'S PowerPlan"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "vgc.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "vgtray.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "vibrancegui.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "widgets.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "winexp.exe"
    },
    {
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "winlogon.exe"
    },
    {
      "ioPriority": "Normal",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "wmiprvse.exe"
    },
    {
      "gpuPriority": "Idle",
      "ioPriority": "Very Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Idle",
      "priorityClassEnforcedByRegistry": false,
      "processName": "yourphone.exe"
    },
    {
      "ioPriority": "Low",
      "ioPriorityEnforcedByRegistry": false,
      "priorityClass": "Below normal",
      "priorityClassEnforcedByRegistry": false,
      "processName": "zen.exe"
    }
  ]
}
"@

    $outputPath = Join-Path (Split-Path -Parent $ScriptDir) "SETT.json"
    $Utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($outputPath, $json, $Utf8NoBom)

    $isValid = try { $json | ConvertFrom-Json | Out-Null; $true } catch { $false }
    $jsonObj = $json | ConvertFrom-Json
    $totalRules = ($jsonObj.ruleSets | Measure-Object).Count
    $gameRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('priorityClass').Count -gt 0 -and $_.priorityClass -eq "High" } | Measure-Object).Count
    $idleRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('priorityClass').Count -gt 0 -and $_.priorityClass -eq "Idle" } | Measure-Object).Count
    $belowNormalRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('priorityClass').Count -gt 0 -and $_.priorityClass -eq "Below normal" } | Measure-Object).Count
    $normalRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('priorityClass').Count -gt 0 -and $_.priorityClass -eq "Normal" } | Measure-Object).Count
    $lowRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('priorityClass').Count -gt 0 -and $_.priorityClass -eq "Low" } | Measure-Object).Count
    $aboveNormalRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('priorityClass').Count -gt 0 -and $_.priorityClass -eq "Above normal" } | Measure-Object).Count
    $affinityRules = ($jsonObj.ruleSets | Where-Object { $_.PSObject.Properties.Match('cpuAffinity').Count -gt 0 } | Measure-Object).Count
    $fileSize = "{0:N1} KB" -f ((Get-Item $outputPath).Length / 1KB)

    Write-Animated "  Rules generated  : $totalRules total" -Color Green
    Write-Animated "    - Games" -Color Yellow
    Write-Animated "         CPU Properties (High): $gameRules games" -Color White
    Write-Animated "    - System & Background Apps" -Color Yellow
    Write-Animated "         Above normal: $aboveNormalRules" -Color White
    Write-Animated "         Normal: $normalRules" -Color White
    Write-Animated "         Below normal: $belowNormalRules" -Color White
    Write-Animated "         Low: $lowRules" -Color White
    Write-Animated "         Idle: $idleRules" -Color White
    Write-Animated "" -DelayMs 100
    Write-Animated "  [*] OUTPUT" -Color Cyan
    Write-Animated "  $sub" -Color DarkGray
    Write-Animated "  File             : $outputPath" -Color White
    Write-Animated "  Size             : $fileSize" -Color White
    $jsonValidStr = if ($isValid) { "YES" } else { "NO - CORRUPTED" }
    $jsonValidColor = if ($isValid) { "Green" } else { "Red" }
    Write-Animated "  JSON valid       : $jsonValidStr" -Color $jsonValidColor
    Write-Animated "" -DelayMs 100
    Write-Animated "  [*] NEXT STEPS" -Color Cyan
    Write-Animated "  $sub" -Color DarkGray
    Write-Animated "  1. Open Process Lasso" -Color White
    Write-Animated "  2. File -> Import Settings -> Select SETT.json" -Color White
    Write-Animated "  3. Options -> Power -> SETT's Power Plan" -Color White
    Write-Animated "  4. Options -> Power -> Disable Core Parking" -Color White
    Write-Animated "" -DelayMs 100
    Write-Animated $sep -Color DarkGray
    Write-Animated "  [OK] Done! Your system is ready for maximum gaming performance." -Color Green
    Write-Animated $sep -Color DarkGray
    exit 0
}
catch {
    Write-Animated "" -DelayMs 100
    Write-Animated ("=" * 60) -Color DarkGray
    Write-Animated "  [X] GENERATION FAILED" -Color Red
    Write-Animated ("=" * 60) -Color DarkGray
    Write-Animated "  Error: $_" -Color Red
    Write-Animated ("=" * 60) -Color DarkGray
    exit 1
}
