@echo off
:: -- Garante que o .bat rode como administrador --
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permissao de administrador...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: -- Pasta Installers (relativa ao .bat) --
set "INSTALLERS_DIR=%~dp0Installers"

if not exist "%INSTALLERS_DIR%" (
    echo Pasta not found: "%INSTALLERS_DIR%"
    pause
    exit /b
)

:: -- Executa o instalador .exe e espera ele terminar --
if exist "%INSTALLERS_DIR%\0_AllPrograms.exe" (
    echo Iniciando 0_AllPrograms.exe ...
    start "" /wait "%INSTALLERS_DIR%\0_AllPrograms.exe"
) else (
    echo Arquivo 0_AllPrograms.exe nao encontrado em "%INSTALLERS_DIR%".
)

:: -- Executa o script PowerShell (rodando elevado porque o .bat ja foi elevado) --
if exist "%INSTALLERS_DIR%\1_OtherPrograms.ps1" (
    echo Executando 1_OtherPrograms.ps1 ...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALLERS_DIR%\1_OtherPrograms.ps1"
) else (
    echo Arquivo 1_OtherPrograms.ps1 nao encontrado em "%INSTALLERS_DIR%".
)

echo Concluido.
pause
