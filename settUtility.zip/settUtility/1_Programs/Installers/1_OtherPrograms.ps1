Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"
$ScriptDir = $PSScriptRoot

# ============================================================
#  LOGGING SYSTEM  -  clean ASCII prefixes, no unicode/emojis
# ============================================================
function Write-Log {
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [ValidateSet('Banner','Info','OK','Fail','Warn','Step','Ask')]
        [string]$Level = 'Info'
    )
    $style = @{
        'Banner' = @{ P=''; C='Cyan'      }
        'Info'   = @{ P='  >'; C='DarkGray' }
        'OK'     = @{ P='  +'; C='Green'    }
        'Fail'   = @{ P='  !'; C='Red'      }
        'Warn'   = @{ P='  *'; C='Yellow'   }
        'Step'   = @{ P='  ~'; C='Magenta'  }
        'Ask'    = @{ P='  ?'; C='White'    }
    }
    $s = $style[$Level]
    if ($Level -eq 'Banner') {
        Write-Host ''
        Write-Host '  ========================================' -ForegroundColor $s.C
        Write-Host "  $Message" -ForegroundColor $s.C
        Write-Host '  ========================================' -ForegroundColor $s.C
    }
    else {
        Write-Host "$($s.P) $Message" -ForegroundColor $s.C
    }
}

# ============================================================
#  DIRECT DOWNLOAD  -  baixa o instalador e roda, sem browser
# ============================================================
function Invoke-DirectDownload {
    param(
        [Parameter(Mandatory)]
        [string]$Url,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [string]$Arguments = ''
    )
    $tempDir = $env:TEMP
    $fileName = [System.IO.Path]::GetFileName(([uri]$Url).AbsolutePath)
    if ((-not $fileName) -or ($fileName -eq '')) {
        $ext = '.exe'
        if ($Url -match '\.zip')       { $ext = '.zip' }
        elseif ($Url -match '\.msi')   { $ext = '.msi' }
        $fileName = "$DisplayName$ext" -replace ' ', ''
    }
    $outFile = Join-Path $tempDir $fileName

    Write-Log -Level Step -Message "Baixando $DisplayName..."
    Write-Log -Level Info -Message "URL: $Url"

    try {
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $Url -OutFile $outFile -UseBasicParsing
        Write-Log -Level OK -Message "Download concluido: $outFile"
    }
    catch {
        Write-Log -Level Fail -Message "Falha no download: $_"
        return 1
    }

    Write-Log -Level Step -Message "Executando instalador de $DisplayName..."
    try {
        if ($Arguments) {
            $proc = Start-Process -FilePath $outFile -ArgumentList $Arguments -Wait -PassThru
        }
        else {
            $proc = Start-Process -FilePath $outFile -Wait -PassThru
        }
        if ($proc.ExitCode -eq 0) {
            Write-Log -Level OK -Message "$DisplayName instalado com sucesso!"
        }
        else {
            Write-Log -Level Warn -Message "$DisplayName finalizado (codigo $($proc.ExitCode))"
        }
    }
    catch {
        Write-Log -Level Fail -Message "Erro ao executar instalador: $_"
    }

    Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
    return 0
}

# ============================================================
#  SHOW-MENU  -  exibe menu interativo numerado
# ============================================================
function Show-Menu {
    param(
        [string]$Title,
        [System.Collections.IDictionary]$Options,
        [string]$ReturnOption = "Voltar"
    )
    Clear-Host
    Write-Log -Level Banner -Message $Title
    Write-Host ''
    $menuItems = @{}
    $i = 1
    foreach ($key in ($Options.Keys | Sort-Object)) {
        $menuItems[$i] = $key
        $label = if ($Options[$key].Name) { $Options[$key].Name } else { $key }
        Write-Host "    $i) $label" -ForegroundColor White
        $i++
    }
    Write-Host ''
    Write-Host "    0) $ReturnOption" -ForegroundColor DarkGray
    Write-Host ''
    return $menuItems
}

# ============================================================
#  INVOKE-WINGETACTION  -  instala/remove via winget
# ============================================================
function Invoke-WingetAction {
    param(
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action,
        [Parameter(Mandatory)]
        [string]$Id,
        [Parameter(Mandatory)]
        [string]$DisplayName,
        [ValidateSet("winget", "msstore")]
        [string]$Source = "winget"
    )
    $actionVerb = @{ install = "Instalando"; uninstall = "Removendo" }[$Action]
    $actionPast  = @{ install = "instalado"; uninstall = "removido"  }[$Action]

    Write-Log -Level Step -Message "$actionVerb $DisplayName via winget..."

    $params = @($Action, "--id=$Id", "--silent")
    if ($Source -eq "msstore") {
        if ($Action -eq "install") {
            $params += "--source", "msstore", "--accept-package-agreements"
        }
    }
    else {
        if ($Action -eq "install") {
            $params += "--accept-source-agreements", "--accept-package-agreements"
        }
    }

    $AlreadyInstalledCodes = @(-1978335189, -1978335215)

    try {
        $process = Start-Process winget -ArgumentList $params -Wait -NoNewWindow -PassThru
        if ($process.ExitCode -eq 0) {
            Write-Log -Level OK -Message "$DisplayName $actionPast com sucesso!"
            return 0
        }
        elseif ($AlreadyInstalledCodes -contains $process.ExitCode) {
            Write-Log -Level OK -Message "$DisplayName ja estava instalado!"
            return 0
        }
        else {
            Write-Log -Level Fail -Message "Erro ao $actionVerb $DisplayName (winget: $($process.ExitCode))"
            return $process.ExitCode
        }
    }
    catch {
        Write-Log -Level Fail -Message "Falha critica ao executar winget para $DisplayName"
        Write-Log -Level Fail -Message $_.Exception.Message
        return -1
    }
}

# ============================================================
#  INVOKE-APPINSTALL  -  tenta winget, fallback download direto
# ============================================================
function Invoke-AppInstall {
    param(
        [Parameter(Mandatory)]
        [string]$AppKey,
        [Parameter(Mandatory)]
        [hashtable]$App,
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $displayName = $App.Name

    # --- Uninstall: winget only ---
    if ($Action -eq "uninstall") {
        $confirm = Read-Host "  ? Tem certeza que deseja remover $displayName? (Y/N)"
        if ($confirm -notmatch '^[Yy]$') { return }
        $source = if ($App.ContainsKey('Source')) { $App.Source } else { "winget" }
        $null = Invoke-WingetAction -Action $Action -Id $AppKey -DisplayName $displayName -Source $source
        return
    }

    # --- Install: winget > direct download > browser ---
    $source = if ($App.ContainsKey('Source')) { $App.Source } else { "winget" }

    # Step 1: Try winget (preferred, no browser)
    if ($AppKey -notmatch '^9[A-Z0-9]+$') {
        $wingetResult = Invoke-WingetAction -Action install -Id $AppKey -DisplayName $displayName -Source $source
    }
    else {
        $wingetResult = Invoke-WingetAction -Action install -Id $AppKey -DisplayName $displayName -Source $source
    }

    if ($wingetResult -eq 0) {
        # Success via winget - open setup links if any
        if ($App.ContainsKey('SetupLinks')) {
            Start-Sleep -Seconds 1
            Write-Log -Level Step -Message "Abrindo links de configuracao para $displayName..."
            foreach ($link in $App.SetupLinks) {
                Write-Log -Level Info -Message " -> $link"
                Start-Process $link
            }
            Start-Sleep -Seconds 2
        }
        return
    }

    # Step 2: Try direct download (if URL available)
    if ($App.ContainsKey('DirectUrl')) {
        Write-Log -Level Warn -Message "Winget falhou. Tentando download direto..."
        $silentArgs = if ($App.ContainsKey('SilentArgs')) { $App.SilentArgs } else { '' }
        $dlResult = Invoke-DirectDownload -Url $App.DirectUrl -DisplayName $displayName -Arguments $silentArgs
        if ($dlResult -eq 0) {
            Start-Sleep -Seconds 1
            return
        }
        Write-Log -Level Warn -Message "Download direto falhou. Abrindo navegador..."
    }

    # Step 3: Last resort - open browser
    $fallbackUrl = if ($App.ContainsKey('FallbackUrl')) { $App.FallbackUrl }
                   elseif ($App.ContainsKey('StoreLink')) { $App.StoreLink }
                   else { $null }

    if ($fallbackUrl) {
        Write-Log -Level Step -Message "Abrindo $fallbackUrl no navegador..."
        Start-Sleep -Seconds 1
        Start-Process $fallbackUrl
        Write-Log -Level OK -Message "Pagina de download aberta no navegador."
    }
    else {
        Write-Log -Level Fail -Message "Nao foi possivel instalar $displayName (sem URL de fallback)."
    }

    Start-Sleep -Seconds 3
}

# ============================================================
#  HANDLE-APPSELECTION  -  menu de selecao de apps
# ============================================================
function Handle-AppSelection {
    param(
        [Parameter(Mandatory)]
        [string]$CategoryName,
        [Parameter(Mandatory)]
        [hashtable]$Apps,
        [Parameter(Mandatory)]
        [ValidateSet("install", "uninstall")]
        [string]$Action
    )
    $actionTitle = @{ install = "Instalar"; uninstall = "Remover" }[$Action]

    while ($true) {
        $appMenuItems = Show-Menu -Title "$CategoryName - $actionTitle" -Options $Apps
        $choice = Read-Host "  ? Escolha uma opcao"

        if ($choice -eq '0') { break }

        if ((-not $choice) -or (-not ($appMenuItems.ContainsKey([int]$choice)))) {
            Write-Log -Level Fail -Message "Opcao invalida!"
            Start-Sleep -Seconds 1
            continue
        }

        $appKey = $appMenuItems[[int]$choice]
        $app = $Apps[$appKey]

        if ($Action -eq "uninstall") {
            Invoke-AppInstall -AppKey $appKey -App $app -Action uninstall
        }
        else {
            Invoke-AppInstall -AppKey $appKey -App $app -Action install
        }
    }
}

# ============================================================
#  OPEN-OOAPPBUSTER
# ============================================================
function Open-OOAppBuster {
    Clear-Host
    Write-Log -Level Banner -Message "O&O AppBuster"
    $appPath = Join-Path $ScriptDir "Programs\OOAPB.exe"
    if (Test-Path -LiteralPath $appPath) {
        Write-Log -Level Step -Message "Abrindo O&O AppBuster..."
        Start-Process -FilePath $appPath
        Write-Log -Level OK -Message "O&O AppBuster aberto com sucesso!"
    }
    else {
        Write-Log -Level Fail -Message "OOAPB.exe nao encontrado em: $appPath"
        Write-Log -Level Info -Message "Coloque o arquivo na pasta: Programs"
    }
    Start-Sleep -Seconds 2
}

# ============================================================
#  OPEN-WINDOWSDEBLOAT
# ============================================================
function Open-WindowsDebloat {
    Clear-Host
    Write-Log -Level Banner -Message "Windows Debloat"
    $appPath = Join-Path $ScriptDir "Programs\WindowsDebloat.exe"
    if (Test-Path -LiteralPath $appPath) {
        Write-Log -Level Step -Message "Abrindo Windows Debloat..."
        Start-Process -FilePath $appPath
        Write-Log -Level OK -Message "Windows Debloat aberto com sucesso!"
    }
    else {
        Write-Log -Level Fail -Message "WindowsDebloat.exe nao encontrado em: $appPath"
        Write-Log -Level Info -Message "Coloque o arquivo na pasta: Programs"
    }
    Start-Sleep -Seconds 2
}

# ============================================================
#  REMOVE-WINDOWSAI
# ============================================================
function Remove-WindowsAI {
    Clear-Host
    Write-Log -Level Banner -Message "Remover Windows AI"
    Write-Log -Level Warn -Message "Este script remove componentes de IA do Windows."
    Write-Log -Level Info -Message "O processo pode demorar alguns minutos..."

    $confirm = Read-Host "`n  ? Deseja continuar? (Y/N)"
    if ($confirm -notmatch '^[Yy]$') {
        Write-Log -Level Info -Message "Operacao cancelada."
        Start-Sleep -Seconds 2
        return
    }

    try {
        Write-Log -Level Step -Message "Baixando e executando script de remocao..."
        $scriptUrl = 'https://raw.githubusercontent.com/zoicware/RemoveWindowsAI/main/RemoveWindowsAi.ps1'
        & ([scriptblock]::Create((Invoke-RestMethod $scriptUrl)))
        Write-Log -Level OK -Message "Script executado!"
    }
    catch {
        Write-Log -Level Fail -Message "Falha ao executar o script de remocao."
        Write-Log -Level Fail -Message $_.Exception.Message
    }

    Write-Host ''
    Write-Log -Level Info -Message "Pressione qualquer tecla para voltar ao menu..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

# ============================================================
#  UPDATE-ALLPROGRAMS
# ============================================================
function Update-AllPrograms {
    Clear-Host
    Write-Log -Level Banner -Message "Atualizar Programas"
    Write-Log -Level Info -Message "Verificando programas com atualizacoes disponiveis..."

    try {
        winget upgrade
    }
    catch {
        Write-Log -Level Fail -Message "Nao foi possivel verificar as atualizacoes."
        Start-Sleep -Seconds 2
        return
    }

    $confirm = Read-Host "`n  ? Deseja atualizar todos os programas? (Y/N)"
    if ($confirm -match '^[Yy]$') {
        Write-Log -Level Step -Message "Atualizando todos os programas..."
        $proc = Start-Process winget -ArgumentList @("upgrade", "--all", "--silent", "--accept-source-agreements", "--accept-package-agreements") -Wait -NoNewWindow -PassThru
        if ($proc.ExitCode -eq 0) {
            Write-Log -Level OK -Message "Atualizacao concluida com sucesso!"
        }
        else {
            Write-Log -Level Fail -Message "Erro ao atualizar (winget: $($proc.ExitCode))"
        }
    }
    else {
        Write-Log -Level Info -Message "Operacao de atualizacao cancelada."
    }
    Start-Sleep -Seconds 2
}

# ============================================================
#  APP DEFINITIONS
#
#  Cada app pode ter:
#    Name       -> nome de exibicao
#    Source     -> "winget" (padrao) ou "msstore"
#    StoreLink  -> link da Microsoft Store (referencia)
#    DirectUrl  -> URL de download direto (fallback se winget falhar)
#    FallbackUrl-> URL para abrir no navegador (ultimo recurso)
#    SetupLinks -> links de configuracao pos-instalacao
#    SilentArgs -> argumentos para instalacao silenciosa
# ============================================================
$categories = @{
    'Utils' = @{
        Name = 'Utilitarios'
        Apps = @{
            '9N7JSXC1SJK6' = @{
                Name      = 'Blip Transfer'
                Source    = 'msstore'
                StoreLink = 'https://apps.microsoft.com/detail/9N7JSXC1SJK6'
            }
            'DuongDieuPhap.ImageGlass' = @{
                Name        = 'Image Glass'
                FallbackUrl = 'https://imageglass.org/'
            }
            'GitHub.cli' = @{
                Name        = 'Github CLI'
                FallbackUrl = 'https://cli.github.com/'
            }
            'Microsoft.VisualStudioCode' = @{
                Name        = 'Visual Studio Code'
                DirectUrl   = 'https://code.visualstudio.com/sha/download?build=stable&os=win32-x64-user'
                FallbackUrl = 'https://code.visualstudio.com/'
            }
            'OpenJS.NodeJS.LTS' = @{
                Name        = 'NodeJS'
                FallbackUrl = 'https://nodejs.org/'
            }
            'Python.Python' = @{
                Name        = 'Python'
                FallbackUrl = 'https://www.python.org/downloads/'
            }
            'Skillbrains.Lightshot' = @{
                Name        = 'Lightshot'
                FallbackUrl = 'https://app.prntscr.com/'
            }
            'Spotify.Spotify' = @{
                Name        = 'Spotify'
                FallbackUrl = 'https://www.spotify.com/download/'
            }
            'Spicetify.Spicetify' = @{
                Name        = 'Spicetify'
                FallbackUrl = 'https://spicetify.app/'
            }
            'Firemin' = @{
                Name       = 'Firemin'
                DirectUrl  = 'https://rizonesoft.com/?gdm_process_download=1&download_id=18327'
                FallbackUrl = 'https://rizonesoft.com/downloads/firemin/'
                SetupLinks = @('https://rizonesoft.com/downloads/firemin/')
            }
            'AirLiveDrive' = @{
                Name       = 'Air Live Drive'
                DirectUrl  = 'https://www.airlivedrive.com/downloads/AirLiveDrive-Installer.exe'
                FallbackUrl = 'https://www.airlivedrive.com/en/'
                SetupLinks = @('https://www.airlivedrive.com/en/')
            }
        }
    }

    'Desktop' = @{
        Name = 'Desktop'
        Apps = @{
            'RamenSoftware.Windhawk' = @{
                Name        = 'WindHawk'
                FallbackUrl = 'https://windhawk.net/'
            }
            '9NBLGGH516XP' = @{
                Name      = 'EarTrumpet'
                Source    = 'msstore'
                StoreLink = 'https://apps.microsoft.com/detail/9NBLGGH516XP'
            }
            '9NTM2QC6QWS7' = @{
                Name      = 'Lively Wallpaper'
                Source    = 'msstore'
                StoreLink = 'https://apps.microsoft.com/detail/9NTM2QC6QWS7'
            }
            '9PF4KZ2VN4W9' = @{
                Name      = 'Translucent TB'
                Source    = 'msstore'
                StoreLink = 'https://apps.microsoft.com/detail/9PF4KZ2VN4W9'
            }
            '9P67C2D4T9FB' = @{
                Name      = 'Seelen UI'
                Source    = 'msstore'
                StoreLink = 'https://apps.microsoft.com/detail/9P67C2D4T9FB'
            }
            'Flow-Launcher.Flow-Launcher' = @{
                Name        = 'Flow Launcher'
                FallbackUrl = 'https://www.flowlauncher.com/'
            }
            'Softdeluxe.FreeDownloadManager' = @{
                Name        = 'Free Download Manager'
                FallbackUrl = 'https://www.freedownloadmanager.org/'
            }
            'Rainmeter.Rainmeter' = @{
                Name        = 'RainMeter'
                FallbackUrl = 'https://www.rainmeter.net/'
                SetupLinks  = @(
                    'https://www.droptopfour.com/',
                    'https://github.com/creewick/MontereyRainmeter/releases'
                )
            }
        }
    }

    'Communication' = @{
        Name = 'Comunicacao'
        Apps = @{
            'TeamSpeakSystems.TeamSpeak' = @{
                Name        = 'TeamSpeak'
                FallbackUrl = 'https://www.teamspeak.com/en/downloads/'
            }
            'Vencord.Vencord' = @{
                Name        = 'Vencord'
                DirectUrl   = 'https://github.com/Vencord/Installer/releases/latest/download/VencordInstaller.exe'
                SilentArgs  = '/S'
                FallbackUrl = 'https://vencord.dev/'
                SetupLinks  = @('https://github.com/Vencord/Installer/releases/latest/download/VencordInstaller.exe')
            }
        }
    }

    'Games' = @{
        Name = 'Jogos'
        Apps = @{
            'FACEITLTD.FACEITClient' = @{
                Name        = 'FACEIT'
                FallbackUrl = 'https://www.faceit.com/en/downloads'
            }
            'br.gamersclub.launcher' = @{
                Name        = 'GamersClub Launcher'
                DirectUrl   = 'https://acupdate.gamersclub.com.br/download'
                FallbackUrl = 'https://gamersclub.com.br/'
                SetupLinks  = @('https://acupdate.gamersclub.com.br/download')
            }
        }
    }
}

# Main menu actions
$mainMenuActions = @{
    'Install'   = @{ Name = 'Instalar Programas' }
    'Uninstall' = @{ Name = 'Remover Programas' }
    'Update'    = @{ Name = 'Atualizar Todos os Programas' }
}

# Uninstall sub-menu
$uninstallMenuActions = @{
    'OOAppBuster'    = @{ Name = 'Abrir O&O AppBuster' }
    'WindowsDebloat' = @{ Name = 'Abrir Windows Debloat' }
    'RemoveAI'       = @{ Name = 'Remover AI' }
    'Categories'     = @{ Name = 'Remover por Categoria' }
}

# ============================================================
#  MAIN LOOP
# ============================================================
while ($true) {
    $mainMenuItems = Show-Menu -Title "Menu Principal" -Options $mainMenuActions -ReturnOption "Sair"
    $mainChoice = Read-Host "  ? Escolha uma opcao"

    if ($mainChoice -eq '0') { break }

    if ((-not $mainChoice) -or (-not ($mainMenuItems.ContainsKey([int]$mainChoice)))) {
        Write-Log -Level Fail -Message "Opcao invalida!"
        Start-Sleep 1
        continue
    }

    $actionKey = $mainMenuItems[[int]$mainChoice]

    switch ($actionKey) {
        'Update' {
            Update-AllPrograms
        }

        'Install' {
            $categoryMenuItems = Show-Menu -Title "Instalar - Selecione a Categoria" -Options $categories
            $categoryChoice = Read-Host "  ? Escolha uma opcao"
            if ($categoryChoice -eq '0') { continue }
            if ((-not $categoryChoice) -or (-not ($categoryMenuItems.ContainsKey([int]$categoryChoice)))) {
                Write-Log -Level Fail -Message "Opcao invalida!"
                Start-Sleep 1
                continue
            }
            $categoryKey = $categoryMenuItems[[int]$categoryChoice]
            Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'install'
        }

        'Uninstall' {
            while ($true) {
                $uninstallMenuItems = Show-Menu -Title "Remover Programas" -Options $uninstallMenuActions
                $uninstallChoice = Read-Host "  ? Escolha uma opcao"
                if ($uninstallChoice -eq '0') { break }

                if ((-not $uninstallChoice) -or (-not ($uninstallMenuItems.ContainsKey([int]$uninstallChoice)))) {
                    Write-Log -Level Fail -Message "Opcao invalida!"
                    Start-Sleep 1
                    continue
                }

                $uninstallKey = $uninstallMenuItems[[int]$uninstallChoice]

                switch ($uninstallKey) {
                    'OOAppBuster'    { Open-OOAppBuster }
                    'WindowsDebloat' { Open-WindowsDebloat }
                    'RemoveAI'       { Remove-WindowsAI }
                    'Categories' {
                        $categoryMenuItems = Show-Menu -Title "Remover - Selecione a Categoria" -Options $categories
                        $categoryChoice = Read-Host "  ? Escolha uma opcao"
                        if ($categoryChoice -eq '0') { continue }
                        if ((-not $categoryChoice) -or (-not ($categoryMenuItems.ContainsKey([int]$categoryChoice)))) {
                            Write-Log -Level Fail -Message "Opcao invalida!"
                            Start-Sleep 1
                            continue
                        }
                        $categoryKey = $categoryMenuItems[[int]$categoryChoice]
                        Handle-AppSelection -CategoryName $categories[$categoryKey].Name -Apps $categories[$categoryKey].Apps -Action 'uninstall'
                    }
                }
            }
        }
    }
}
