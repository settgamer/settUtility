const DEFAULT_YT_BLOCKS = {
  shorts: true,
  comments: false,
  theater: false,
};

document.addEventListener("DOMContentLoaded", async () => {
  const volumeSlider = document.getElementById("volume-slider");
  const volumeDisplay = document.getElementById("volume-display");
  const boostBtn = document.getElementById("boost-btn");
  const resetBtn = document.getElementById("reset-btn");
  const tabTitleEl = document.getElementById("tab-title");

  const urlsInput = document.getElementById("urls-input");
  const openUrlsBtn = document.getElementById("open-urls-btn");
  const clearUrlsBtn = document.getElementById("clear-urls-btn");
  const urlCountEl = document.getElementById("url-count");

  let currentTabId = null;
  let currentTabUrl = "";

  function updateVolumeDisplay(value) {
    volumeDisplay.textContent = `${value}%`;
  }

  async function injectVolumeBooster(gain) {
    if (currentTabId == null) return false;
    if (!/^https?:/.test(tabTitleEl.title || "")) {
      try {
        const [tab] = await chrome.tabs.query({
          active: true,
          currentWindow: true,
        });
        if (tab && !/^https?:/.test(tab.url || "")) return false;
      } catch (e) {
        return false;
      }
    }
    try {
      await chrome.scripting.executeScript({
        target: { tabId: currentTabId },
        func: (g) => {
          if (!window._settAudioCtx) {
            window._settAudioCtx = new AudioContext();
            window._settMediaNodes = new WeakMap();
          }
          var ctx = window._settAudioCtx;
          var nodes = window._settMediaNodes;

          function applyGain(el) {
            try {
              var node = nodes.get(el);
              if (!node) {
                var src = ctx.createMediaElementSource(el);
                var gn = ctx.createGain();
                src.connect(gn);
                gn.connect(ctx.destination);
                node = { src: src, gain: gn };
                nodes.set(el, node);
              }
              node.gain.gain.value = g;
            } catch (_) {}
          }

          var media = document.querySelectorAll("video, audio");
          for (var i = 0; i < media.length; i++) {
            applyGain(media[i]);
          }

          if (!window._settMediaListener) {
            window._settMediaListener = function (e) {
              var t = e.target;
              if (t.tagName === "VIDEO" || t.tagName === "AUDIO") {
                applyGain(t);
              }
            };
            document.addEventListener(
              "loadstart",
              window._settMediaListener,
              true,
            );
            document.addEventListener("play", window._settMediaListener, true);
          }

          window._settCurrentGain = g;
        },
        args: [gain / 100],
      });
      return true;
    } catch (e) {
      console.warn("SETT UTILITY: Cannot inject on this page.");
      return false;
    }
  }

  async function loadVolume() {
    const result = await chrome.storage.local.get(["volume"]);
    const vol = result.volume != null ? result.volume : 100;
    volumeSlider.value = vol;
    updateVolumeDisplay(vol);
    if (result.volume == null) {
      await chrome.storage.local.set({ volume: 100 });
    }
  }

  async function saveVolume(value) {
    await chrome.storage.local.set({ volume: value });
  }

  volumeSlider.addEventListener("input", () => {
    updateVolumeDisplay(parseInt(volumeSlider.value));
  });

  volumeSlider.addEventListener("change", () => {
    saveVolume(parseInt(volumeSlider.value));
  });

  document.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const vol = parseInt(chip.dataset.vol);
      volumeSlider.value = vol;
      updateVolumeDisplay(vol);
      saveVolume(vol);
    });
  });

  boostBtn.addEventListener("click", async () => {
    boostBtn.textContent = "...";
    boostBtn.disabled = true;
    const gain = parseInt(volumeSlider.value);

    const timeoutId = setTimeout(() => {
      boostBtn.textContent = "Error";
      boostBtn.disabled = false;
      setTimeout(() => {
        boostBtn.textContent = "Boost";
      }, 1500);
    }, 3000);

    const success = await injectVolumeBooster(gain);
    clearTimeout(timeoutId);

    if (success) {
      await saveVolume(gain);
      boostBtn.textContent = "Boost";
    } else {
      boostBtn.textContent = "Failed";
      setTimeout(() => {
        boostBtn.textContent = "Boost";
      }, 1500);
    }
    boostBtn.disabled = false;
  });

  resetBtn.addEventListener("click", async () => {
    volumeSlider.value = 100;
    updateVolumeDisplay(100);
    await injectVolumeBooster(100);
    await saveVolume(100);
  });

  let urlCountTimer = null;

  function updateUrlCount() {
    const text = urlsInput.value.trim();
    if (!text) {
      urlCountEl.textContent = "0 links";
      return;
    }
    const n = text.split("\n").filter((l) => l.trim()).length;
    urlCountEl.textContent = `${n} link${n !== 1 ? "s" : ""}`;
  }

  urlsInput.addEventListener("input", () => {
    clearTimeout(urlCountTimer);
    urlCountTimer = setTimeout(updateUrlCount, 150);
  });

  openUrlsBtn.addEventListener("click", async () => {
    const lines = urlsInput.value
      .trim()
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);
    if (!lines.length) return;
    for (const line of lines) {
      const url = /^https?:\/\//i.test(line) ? line : `https://${line}`;
      try {
        await chrome.tabs.create({ url, active: false });
      } catch (_) {}
    }
    window.close();
  });

  clearUrlsBtn.addEventListener("click", () => {
    urlsInput.value = "";
    updateUrlCount();
  });

  const ytBlockBtns = document.querySelectorAll(".yt-block");
  const ytStatus = document.getElementById("yt-blocks-status");

  function getYTBlocks() {
    const b = {};
    ytBlockBtns.forEach((btn) => {
      b[btn.dataset.key] = btn.classList.contains("active");
    });
    return b;
  }

  async function applyYTBlocks() {
    const blocks = getYTBlocks();
    await chrome.storage.local.set({ ytBlocks: blocks });
    await updateContentScriptRegistration(blocks);
    try {
      if (currentTabId != null) {
        await chrome.tabs.sendMessage(currentTabId, {
          action: "ytBlocks",
          blocks,
        });
      }
    } catch (_) {}
    ytStatus.textContent = "Updated";
    ytStatus.className = "counter done";
    ytStatus.style.display = "block";
    setTimeout(() => {
      ytStatus.style.display = "none";
    }, 1200);
  }

  function extractYTVideoId(url) {
    try {
      const u = new URL(url);
      if (
        u.hostname === "www.youtube-nocookie.com" &&
        u.pathname.startsWith("/embed/")
      ) {
        return u.pathname.split("/embed/")[1].split("?")[0].split("/")[0];
      }
      if (u.hostname.includes("youtube.com")) {
        if (u.pathname === "/watch" || u.pathname === "/watch/")
          return u.searchParams.get("v");
        var m = u.pathname.match(/\/shorts\/([^/?]+)/);
        if (m) return m[1];
      }
      if (u.hostname === "youtu.be") {
        return u.pathname.slice(1).split("?")[0];
      }
    } catch (_) {}
    return null;
  }

  async function redirectTabToAdFree() {
    try {
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (!tab || !tab.url) return;
      var videoId = extractYTVideoId(tab.url);
      if (!videoId) return;
      await chrome.tabs.update(tab.id, {
        url: "https://www.yout-ube.com/watch?v=" + videoId,
      });
      window.close();
    } catch (_) {}
  }

  ytBlockBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      btn.classList.toggle("active");
      applyYTBlocks();
    });
  });

  document.getElementById("noads-btn").addEventListener("click", async () => {
    await redirectTabToAdFree();
  });

  async function loadYTBlocks() {
    const result = await chrome.storage.local.get(["ytBlocks"]);
    const blocks = result.ytBlocks || DEFAULT_YT_BLOCKS;
    ytBlockBtns.forEach((btn) => {
      if (blocks[btn.dataset.key]) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });
    if (!result.ytBlocks) {
      await chrome.storage.local.set({ ytBlocks: blocks });
      await updateContentScriptRegistration(blocks);
    }
  }

  async function updateContentScriptRegistration(blocks) {
    const shouldInject = blocks.shorts || blocks.comments || blocks.theater;
    try {
      const scripts = await chrome.scripting.getRegisteredContentScripts();
      const isRegistered = scripts.some((s) => s.id === "yt-enhancements");

      if (shouldInject && !isRegistered) {
        await chrome.scripting.registerContentScripts([
          {
            id: "yt-enhancements",
            matches: ["*://www.youtube.com/*", "*://m.youtube.com/*"],
            js: ["content/youtube.js"],
            runAt: "document_start",
            persistAcrossSessions: true,
          },
        ]);
      } else if (!shouldInject && isRegistered) {
        await chrome.scripting.unregisterContentScripts({
          ids: ["yt-enhancements"],
        });
      }
    } catch (e) {
      console.warn("Failed to update content script registration:", e);
    }
  }

  const iconBtns = document.querySelectorAll(
    ".icon-btn:not(.scope-btn):not(.yt-block)",
  );
  const allSitesBtn = document.getElementById("all-sites-btn");
  const clearCacheBtn = document.getElementById("clear-cache-btn");
  const cacheStatus = document.getElementById("cache-status");
  const originHint = document.getElementById("cache-origin-hint");

  const DATA_KEYS = {
    siteData: ["localStorage", "cacheStorage"],
    cache: "cache",
    cookies: "cookies",
    history: "history",
  };

  let globalScope = false;

  function updateClearBtnState() {
    const hasActive =
      document.querySelectorAll(
        ".icon-btn:not(.scope-btn):not(.yt-block).active",
      ).length > 0;
    clearCacheBtn.disabled = !hasActive;
    clearCacheBtn.style.opacity = hasActive ? "1" : "0.4";
    clearCacheBtn.style.cursor = hasActive ? "pointer" : "not-allowed";
  }

  iconBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      btn.classList.toggle("active");
      updateClearBtnState();
    });
  });

  updateClearBtnState();

  allSitesBtn.addEventListener("click", () => {
    allSitesBtn.classList.toggle("active");
    globalScope = allSitesBtn.classList.contains("active");
    originHint.textContent = globalScope
      ? "all sites"
      : currentTabUrl
        ? new URL(currentTabUrl).hostname
        : "current site";
  });

  function getActiveKeys() {
    const keys = [];
    document
      .querySelectorAll(".icon-btn:not(.scope-btn):not(.yt-block).active")
      .forEach((btn) => {
        keys.push(btn.dataset.key);
      });
    return keys;
  }

  async function clearBrowsingData(keys) {
    try {
      const data = {};
      keys.forEach((k) => {
        const mapped = DATA_KEYS[k];
        if (!mapped) return;
        if (Array.isArray(mapped)) {
          mapped.forEach((m) => {
            data[m] = true;
          });
        } else {
          data[mapped] = true;
        }
      });
      if (Object.keys(data).length === 0) {
        cacheStatus.textContent = "Nothing selected";
        cacheStatus.className = "counter";
        cacheStatus.style.display = "block";
        return;
      }
      const options = { since: 0 };
      if (!globalScope && currentTabUrl) {
        try {
          const url = new URL(currentTabUrl);
          if (!/^https?:$/.test(url.protocol)) {
            cacheStatus.textContent = "Invalid protocol";
            cacheStatus.className = "counter";
            cacheStatus.style.display = "block";
            setTimeout(() => {
              cacheStatus.style.display = "none";
            }, 2000);
            return;
          }
          options.origins = [currentTabUrl];
        } catch (_) {
          cacheStatus.textContent = "Invalid URL";
          cacheStatus.className = "counter";
          cacheStatus.style.display = "block";
          setTimeout(() => {
            cacheStatus.style.display = "none";
          }, 2000);
          return;
        }
      }
      await chrome.browsingData.remove(options, data);
      cacheStatus.textContent = "Cleared + reloading...";
      cacheStatus.className = "counter done";
      cacheStatus.style.display = "block";
      const hasCache = keys.includes("cache");
      if (currentTabId != null) {
        await chrome.tabs.reload(currentTabId, { bypassCache: hasCache });
      }
      setTimeout(() => {
        cacheStatus.style.display = "none";
      }, 1500);
    } catch (e) {
      cacheStatus.textContent = "Error";
      cacheStatus.className = "counter";
      cacheStatus.style.display = "block";
    }
  }

  clearCacheBtn.addEventListener("click", () => {
    clearBrowsingData(getActiveKeys());
  });

  async function getCurrentTabInfo() {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });
    if (tab) {
      currentTabId = tab.id;
      try {
        const url = new URL(tab.url);
        currentTabUrl = url.origin;
        originHint.textContent = globalScope ? "all sites" : url.hostname;
      } catch (_) {
        currentTabUrl = "";
        originHint.textContent = globalScope ? "all sites" : "current site";
      }
      const title = tab.title || "Untitled";
      tabTitleEl.textContent =
        title.length > 36 ? title.slice(0, 33) + "..." : title;
      tabTitleEl.title = tab.title || "";
    }
  }

  await getCurrentTabInfo();
  await loadVolume();
  await loadYTBlocks();
  updateUrlCount();
});
