chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['volume', 'ytBlocks'], r => {
    if (r.volume == null) chrome.storage.local.set({ volume: 100 });
    if (!r.ytBlocks) {
      chrome.storage.local.set({ ytBlocks: { shorts: true, comments: false } });
    }
  });
});
