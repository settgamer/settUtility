const DEFAULT_YT_BLOCKS = {
  shorts: true,
  comments: false,
  theater: false,
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["volume", "ytBlocks"], async (r) => {
    const updates = {};
    if (r.volume == null) updates.volume = 100;
    if (!r.ytBlocks) updates.ytBlocks = DEFAULT_YT_BLOCKS;
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates);
    }

    const blocks = r.ytBlocks || updates.ytBlocks || DEFAULT_YT_BLOCKS;
    const shouldInject = blocks.shorts || blocks.comments || blocks.theater;

    if (shouldInject) {
      try {
        await chrome.scripting.registerContentScripts([
          {
            id: "youtube",
            matches: ["*://www.youtube.com/*", "*://m.youtube.com/*"],
            js: ["content/youtube.js"],
            runAt: "document_start",
            persistAcrossSessions: true,
          },
        ]);
      } catch (e) {
        console.warn("Failed to register content script:", e);
      }
    }
  });
});
