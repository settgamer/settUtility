(function () {
  'use strict';

  const RULES = {
    shorts: [
      'ytd-rich-section-renderer:has(a[href*="/shorts"])',
      'ytd-reel-shelf-renderer',
      'ytd-guide-entry-renderer:has(a[title*="Short"])',
      'ytd-mini-guide-entry-renderer:has(a[title*="Short"])',
      'ytd-video-renderer:has(a[href*="/shorts"])',
      'ytd-grid-video-renderer:has(a[href*="/shorts"])',
      'ytd-compact-video-renderer:has(a[href*="/shorts"])',
      'ytd-rich-item-renderer:has(a[href*="/shorts"])',
      'ytd-shelf-renderer:has(a[href*="/shorts"])',
      'ytd-item-section-renderer:has(a[href*="/shorts"])',
    ],
    comments: [
      '#comments',
      'ytd-comments',
      'ytd-comment-thread-renderer',
    ],
  };

  var STYLE_ID = 'sett-yt-blocks';
  var blocks = { shorts: true, comments: true };
  var style = null;

  function buildCSS() {
    var parts = [];
    var keys = Object.keys(blocks);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      if (blocks[key] && RULES[key]) {
        for (var j = 0; j < RULES[key].length; j++) {
          parts.push(RULES[key][j] + '{display:none!important}');
        }
      }
    }
    return parts.join('');
  }

  function apply() {
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }
    style.textContent = buildCSS();

    if (blocks.shorts && window.location.pathname.indexOf('/shorts/') === 0) {
      var id = window.location.pathname.replace('/shorts/', '').split('?')[0];
      if (id) window.location.replace('https://www.youtube.com/watch?v=' + id);
    }
  }

  function load() {
    chrome.storage.local.get(['ytBlocks'], function (r) {
      if (r.ytBlocks) blocks = r.ytBlocks;
      apply();
    });
  }

  load();

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === 'local' && changes.ytBlocks) {
      blocks = changes.ytBlocks.newValue;
      apply();
    }
  });

  chrome.runtime.onMessage.addListener(function (msg, _, respond) {
    if (msg.action === 'ytBlocks') {
      blocks = msg.blocks;
      apply();
      respond({ ok: true });
    }
    return true;
  });
})();
