(function () {
  "use strict";

  const DEFAULT_BLOCKS = {
    shorts: true,
    comments: false,
    theater: false,
  };
  const THEATER_WIDTH_THRESHOLD = 0.8; // 80% of window width = theater mode

  const RULES = {
    shorts: [
      "ytd-reel-shelf-renderer",
      "ytd-rich-shelf-renderer:has(ytd-reel-shelf-renderer)",
      'ytd-guide-entry-renderer:has(a[title*="Short"])',
      'ytd-mini-guide-entry-renderer:has(a[title*="Short"])',
      'ytd-video-renderer:has(a[href*="/shorts"])',
      'ytd-grid-video-renderer:has(a[href*="/shorts"])',
      'ytd-compact-video-renderer:has(a[href*="/shorts"])',
      'ytd-rich-item-renderer:has(a[href*="/shorts"])',
      'ytd-rich-section-renderer:has(#video-title[href*="/shorts"])',
      "ytd-shelf-renderer:has(ytd-reel-shelf-renderer)",
      "ytd-item-section-renderer:has(ytd-reel-shelf-renderer)",
    ],
    comments: ["#comments", "ytd-comments", "ytd-comment-thread-renderer"],
  };

  var STYLE_ID = "sett-yt-blocks";
  var blocks = Object.assign({}, DEFAULT_BLOCKS);
  var style = null;

  function buildCSS() {
    var parts = [];
    var keys = Object.keys(blocks);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      if (blocks[key] && RULES[key]) {
        for (var j = 0; j < RULES[key].length; j++) {
          parts.push(RULES[key][j] + "{display:none!important}");
        }
      }
    }
    return parts.join("");
  }

  function apply() {
    if (!style) {
      style = document.createElement("style");
      style.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }
    style.textContent = buildCSS();

    if (blocks.shorts && window.location.pathname.indexOf("/shorts/") === 0) {
      var id = window.location.pathname.replace("/shorts/", "").split("?")[0];
      if (id) window.location.replace("https://www.youtube.com/watch?v=" + id);
    }

    if (blocks.theater) {
      enableTheaterMode();
    }
  }

  var THEATER_CHECK_INTERVAL = 100;
  var THEATER_MAX_ATTEMPTS = 20;

  function enableTheaterMode() {
    if (window.location.pathname !== "/watch") return;

    var attempts = 0;
    var interval = setInterval(function () {
      attempts++;

      var player = document.querySelector(".html5-video-player");

      if (player && player.classList) {
        var playerWidth = player.offsetWidth;
        var windowWidth = window.innerWidth;
        var isActuallyTheater =
          playerWidth > windowWidth * THEATER_WIDTH_THRESHOLD;

        // Check YouTube's localStorage preference
        var ytPreference = null;
        try {
          ytPreference = localStorage.getItem("yt-player-theater-mode-enabled");
        } catch (e) {
          // Ignore localStorage errors
        }

        // Force click if:
        // 1. Not visually in theater mode, OR
        // 2. YouTube saved preference as "false" (user manually disabled)
        var shouldClick = !isActuallyTheater || ytPreference === "false";

        if (shouldClick) {
          var theaterBtn =
            document.querySelector("button.ytp-size-button") ||
            document.querySelector("button[aria-label*='heater']") ||
            document.querySelector("button[title*='heater']");

          if (theaterBtn) {
            try {
              theaterBtn.click();

              // Override YouTube's localStorage preference
              try {
                localStorage.setItem("yt-player-theater-mode-enabled", "true");
              } catch (e) {
                console.warn("! [SETT] Cannot persist theater preference:", e);
              }
            } catch (e) {
              console.warn("! [SETT] Theater mode activation failed:", e);
            } finally {
              clearInterval(interval);
            }
          } else {
            // Fallback: try all size buttons
            var allSizeBtns = document.querySelectorAll(
              "button.ytp-size-button",
            );
            if (allSizeBtns.length > 0) {
              try {
                allSizeBtns[0].click();
              } catch (e) {
                console.warn("! [SETT] Fallback theater click failed:", e);
              }
              clearInterval(interval);
            }
          }
        } else {
          clearInterval(interval);
        }
      }

      if (attempts >= THEATER_MAX_ATTEMPTS) {
        clearInterval(interval);
      }
    }, THEATER_CHECK_INTERVAL);
  }

  function load() {
    chrome.storage.local.get(["ytBlocks"], function (r) {
      if (r.ytBlocks) {
        blocks = r.ytBlocks;
        apply();
      }
    });
  }

  load();

  chrome.runtime.onMessage.addListener(function (msg, _, respond) {
    if (msg.action === "ytBlocks") {
      blocks = msg.blocks;
      apply();
      respond({ ok: true });
    }
  });

  var theaterTimeout = null;

  document.addEventListener("yt-navigate-finish", function () {
    if (blocks.theater && window.location.pathname === "/watch") {
      clearTimeout(theaterTimeout);
      theaterTimeout = setTimeout(enableTheaterMode, 500);
    }
  });
})();
